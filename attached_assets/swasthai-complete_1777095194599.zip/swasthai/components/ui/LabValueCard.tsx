"use client";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import type { LabValue } from "@/lib/mock-data";

const STATUS_STYLES: Record<LabValue["status"], { bg: string; border: string; label: string; labelColor: string }> = {
  normal:   { bg: "var(--bg-surface)",  border: "var(--border)",    label: "Normal",   labelColor: "var(--forest-600)" },
  high:     { bg: "var(--amber-50)",    border: "#fcd34d",          label: "High",     labelColor: "var(--amber-600)" },
  low:      { bg: "#eff6ff",           border: "#bfdbfe",           label: "Low",      labelColor: "#2563eb" },
  critical: { bg: "var(--red-50)",     border: "#fca5a5",           label: "Critical", labelColor: "var(--red-600)" },
};

export function LabValueCard({ lab }: { lab: LabValue }) {
  const style = STATUS_STYLES[lab.status];
  const TrendIcon = lab.trend === "up" ? TrendingUp : lab.trend === "down" ? TrendingDown : Minus;
  const trendClass = lab.status === "critical" || (lab.status === "high" && lab.trend === "up")
    ? "trend-up"
    : lab.trend === "down" ? "trend-down" : "trend-flat";

  return (
    <div
      className="card"
      style={{
        background: style.bg,
        borderColor: style.border,
        padding: "16px 18px",
        transition: "box-shadow var(--dur-mid), transform var(--dur-mid)",
      }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLDivElement).style.boxShadow = "var(--shadow-md)";
        (e.currentTarget as HTMLDivElement).style.transform = "translateY(-1px)";
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLDivElement).style.boxShadow = "var(--shadow-sm)";
        (e.currentTarget as HTMLDivElement).style.transform = "translateY(0)";
      }}
    >
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
        <div>
          <div className="t-subheading">{lab.name}</div>
          <div className="t-xs c-muted" style={{ marginTop: 2 }}>{lab.date} · {lab.lab}</div>
        </div>
        <span className="badge" style={{
          background: style.bg,
          color: style.labelColor,
          border: `1px solid ${style.border}`,
          fontSize: "0.6875rem",
        }}>
          {lab.status}
        </span>
      </div>

      {/* Value */}
      <div style={{ display: "flex", alignItems: "baseline", gap: 4, marginBottom: 6 }}>
        <span className="metric-value" style={{ color: style.labelColor }}>{lab.value}</span>
        <span className="metric-unit">{lab.unit}</span>
      </div>

      {/* Trend + reference */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        {lab.trend && lab.trend !== "flat" ? (
          <span className={`metric-trend ${trendClass}`}>
            <TrendIcon size={12} />
            {lab.trendPct != null && `${lab.trendPct > 0 ? "+" : ""}${lab.trendPct}%`}
          </span>
        ) : (
          <span className="metric-trend trend-flat"><Minus size={12} /> Stable</span>
        )}
        <span className="t-xs c-muted">Ref: {lab.referenceRange}</span>
      </div>
    </div>
  );
}
