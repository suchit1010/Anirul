"use client";
import { X, AlertCircle, AlertTriangle, Info } from "lucide-react";
import type { Alert } from "@/lib/mock-data";

export function AlertStrip({
  alert,
  onDismiss,
}: {
  alert: Alert;
  onDismiss?: (id: string) => void;
}) {
  const config = {
    critical: { cls: "alert-strip-critical", Icon: AlertCircle,   iconColor: "var(--red-600)" },
    warning:  { cls: "alert-strip-warning",  Icon: AlertTriangle, iconColor: "var(--amber-600)" },
    info:     { cls: "alert-strip-info",     Icon: Info,          iconColor: "var(--forest-500)" },
  }[alert.severity];

  return (
    <div className={`alert-strip ${config.cls}`}>
      <config.Icon size={16} color={config.iconColor} style={{ flexShrink: 0, marginTop: 2 }} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div className="t-subheading" style={{ marginBottom: 2 }}>{alert.title}</div>
        <div className="t-small c-secondary">{alert.description}</div>
        {alert.action && (
          <button className="btn btn-ghost btn-sm" style={{ marginTop: 8, padding: "5px 12px", fontSize: "0.75rem" }}>
            {alert.action} →
          </button>
        )}
      </div>
      {onDismiss && (
        <button
          onClick={() => onDismiss(alert.id)}
          style={{
            padding: 4, border: "none", background: "none",
            cursor: "pointer", color: "var(--text-muted)",
            flexShrink: 0, borderRadius: "var(--r-sm)",
            transition: "background var(--dur-fast)",
          }}
          onMouseEnter={e => (e.currentTarget.style.background = "rgba(0,0,0,0.06)")}
          onMouseLeave={e => (e.currentTarget.style.background = "none")}
        >
          <X size={14} />
        </button>
      )}
    </div>
  );
}
