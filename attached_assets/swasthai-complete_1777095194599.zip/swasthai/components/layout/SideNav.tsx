"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard, Clock, Upload, Stethoscope,
  Lock, Users, Bell, Settings, ChevronRight, Activity,
} from "lucide-react";

const NAV_ITEMS = [
  { href: "/dashboard",     icon: LayoutDashboard, label: "Dashboard",     badge: null },
  { href: "/timeline",      icon: Clock,           label: "Health Timeline", badge: null },
  { href: "/upload",        icon: Upload,          label: "Upload Records",  badge: null },
  { href: "/doctor-brief",  icon: Stethoscope,     label: "Doctor Brief",    badge: null },
  { href: "/payments",      icon: Lock,            label: "Private Payments",badge: "New" },
];

const BOTTOM_ITEMS = [
  { href: "/family",    icon: Users,    label: "Family" },
  { href: "/alerts",    icon: Bell,     label: "Alerts",    badge: 3 },
  { href: "/settings",  icon: Settings, label: "Settings" },
];

export function SideNav() {
  const pathname = usePathname();

  return (
    <nav className="sidenav">
      {/* Patient card */}
      <div style={{ padding: "20px 16px 12px" }}>
        <div style={{
          background: "var(--forest-25)",
          border: "1px solid var(--forest-100)",
          borderRadius: "var(--r-lg)",
          padding: "14px",
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
            <div style={{
              width: 38, height: 38,
              background: "linear-gradient(135deg, var(--forest-300), var(--forest-500))",
              borderRadius: "50%",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: "0.875rem", fontWeight: 600, color: "white",
              flexShrink: 0,
            }}>RP</div>
            <div style={{ minWidth: 0 }}>
              <div className="t-subheading truncate">Ramesh Patel</div>
              <div className="t-xs c-muted">54M · T2DM · HTN</div>
            </div>
          </div>
          {/* Health score mini bar */}
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <Activity size={12} color="var(--forest-500)" />
            <div style={{ flex: 1 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 3 }}>
                <span className="t-xs c-muted">Health Score</span>
                <span className="t-xs c-forest" style={{ fontFamily: "var(--font-display)" }}>62</span>
              </div>
              <div className="progress-bar">
                <div className="progress-fill" style={{ width: "62%" }} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main nav */}
      <div style={{ padding: "4px 0", flex: 1 }}>
        <div className="t-xs c-muted" style={{ padding: "6px 24px 4px" }}>Main</div>
        {NAV_ITEMS.map((item) => {
          const active = pathname === item.href;
          return (
            <Link key={item.href} href={item.href} className={`sidenav-item ${active ? "active" : ""}`}>
              <item.icon size={16} className="sidenav-icon" />
              <span style={{ flex: 1 }}>{item.label}</span>
              {item.badge && (
                <span className="badge badge-forest" style={{ fontSize: "0.625rem", padding: "1px 6px" }}>
                  {item.badge}
                </span>
              )}
              {active && <ChevronRight size={13} style={{ opacity: 0.5 }} />}
            </Link>
          );
        })}

        <div className="t-xs c-muted" style={{ padding: "14px 24px 4px" }}>Account</div>
        {BOTTOM_ITEMS.map((item) => {
          const active = pathname === item.href;
          return (
            <Link key={item.href} href={item.href} className={`sidenav-item ${active ? "active" : ""}`}>
              <item.icon size={16} className="sidenav-icon" />
              <span style={{ flex: 1 }}>{item.label}</span>
              {typeof item.badge === "number" && (
                <span style={{
                  background: "var(--red-500)", color: "white",
                  borderRadius: "999px", fontSize: "0.625rem",
                  padding: "1px 6px", fontWeight: 600, minWidth: 18,
                  textAlign: "center",
                }}>{item.badge}</span>
              )}
            </Link>
          );
        })}
      </div>

      {/* Bottom trust bar */}
      <div style={{
        padding: "12px 16px",
        borderTop: "1px solid var(--border)",
        fontSize: "0.6875rem",
        color: "var(--text-muted)",
        lineHeight: 1.6,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 5, marginBottom: 4 }}>
          <span style={{ color: "var(--forest-500)" }}>🔒</span>
          <strong style={{ color: "var(--text-secondary)" }}>End-to-end encrypted</strong>
        </div>
        <div>Your data is never sold. ABHA-compliant storage.</div>
      </div>
    </nav>
  );
}
