"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Bell, Search, Shield } from "lucide-react";

export function TopNav() {
  const pathname = usePathname();
  const isApp = pathname?.startsWith("/dashboard") ||
    pathname?.startsWith("/timeline") ||
    pathname?.startsWith("/upload") ||
    pathname?.startsWith("/doctor-brief") ||
    pathname?.startsWith("/payments");

  return (
    <header className="topnav">
      <div className="container" style={{ height: "100%", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        {/* Logo */}
        <Link href="/" style={{ display: "flex", alignItems: "center", gap: 8, textDecoration: "none" }}>
          <div style={{
            width: 30, height: 30,
            background: "var(--forest-700)",
            borderRadius: "var(--r-sm)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 14, color: "white", fontWeight: 700,
          }}>S</div>
          <span style={{
            fontFamily: "var(--font-display)",
            fontSize: "1.15rem",
            color: "var(--text-primary)",
            fontWeight: 400,
            letterSpacing: "-0.02em",
          }}>
            Swasth<em>AI</em>
          </span>
        </Link>

        {/* App actions */}
        {isApp && (
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            {/* Search */}
            <button className="btn btn-ghost btn-sm hide-mobile" style={{ gap: 6 }}>
              <Search size={14} />
              <span style={{ color: "var(--text-muted)", fontSize: "0.8125rem" }}>Search records…</span>
              <span style={{
                marginLeft: 8, fontSize: "0.6875rem", color: "var(--text-muted)",
                background: "var(--cream-100)", padding: "1px 6px",
                borderRadius: 4, fontFamily: "var(--font-mono)",
              }}>⌘K</span>
            </button>

            {/* Alerts bell */}
            <button className="btn btn-ghost btn-sm" style={{ position: "relative", padding: "8px 10px" }}>
              <Bell size={16} />
              <span style={{
                position: "absolute", top: 4, right: 4,
                width: 8, height: 8,
                background: "var(--red-500)",
                borderRadius: "50%",
                border: "2px solid var(--bg)",
              }} />
            </button>

            {/* ABHA badge */}
            <div className="badge badge-green hide-mobile" style={{ gap: 5 }}>
              <Shield size={10} />
              ABHA Linked
            </div>

            {/* Avatar */}
            <div style={{
              width: 32, height: 32,
              background: "var(--forest-100)",
              borderRadius: "50%",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: "0.75rem", fontWeight: 600,
              color: "var(--forest-700)",
              cursor: "pointer",
            }}>RP</div>
          </div>
        )}

        {/* Landing CTA */}
        {!isApp && (
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <Link href="/dashboard" className="btn btn-ghost btn-sm hide-mobile">Sign In</Link>
            <Link href="/onboarding" className="btn btn-primary btn-sm">Get Started Free</Link>
          </div>
        )}
      </div>
    </header>
  );
}
