"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { LayoutDashboard, Clock, Upload, Stethoscope, Lock } from "lucide-react";

const ITEMS = [
  { href: "/dashboard",    icon: LayoutDashboard, label: "Home" },
  { href: "/timeline",     icon: Clock,           label: "Timeline" },
  { href: "/upload",       icon: Upload,          label: "Upload" },
  { href: "/doctor-brief", icon: Stethoscope,     label: "Brief" },
  { href: "/payments",     icon: Lock,            label: "Private" },
];

export function BottomNav() {
  const pathname = usePathname();
  return (
    <div className="bottom-nav">
      <div className="bottom-nav-grid">
        {ITEMS.map((item) => {
          const active = pathname === item.href;
          return (
            <Link key={item.href} href={item.href} className={`bnav-item ${active ? "active" : ""}`}>
              <item.icon strokeWidth={active ? 2.2 : 1.7} />
              <span>{item.label}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
