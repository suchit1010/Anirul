"use client";
import { TopNav } from "./TopNav";
import { SideNav } from "./SideNav";
import { BottomNav } from "./BottomNav";

export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column" }}>
      <TopNav />
      <div style={{ display: "flex", flex: 1 }}>
        <SideNav />
        <main
          className="main-with-sidenav"
          style={{
            flex: 1,
            minWidth: 0,
            padding: "28px 28px 40px",
            background: "var(--bg)",
          }}
        >
          {children}
        </main>
      </div>
      <BottomNav />
    </div>
  );
}
