"use client";
import { useState } from "react";
import Link from "next/link";
import {
  TrendingUp, TrendingDown, Activity, Clock, Upload,
  Stethoscope, Lock, Users, ChevronRight, FileText,
  AlertCircle, CheckCircle2, Calendar, Pill, Shield,
  Flame, Droplets, Heart, Eye,
} from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { AlertStrip } from "@/components/ui/AlertStrip";
import { LabValueCard } from "@/components/ui/LabValueCard";
import {
  MOCK_PATIENT, MOCK_LABS, MOCK_ALERTS, MOCK_CARE_TASKS,
  MOCK_FAMILY, MOCK_MEDICATIONS, MOCK_DOCUMENTS,
  type Alert,
} from "@/lib/mock-data";

/* ─── Health Score Ring ──────────────────────────────────────────── */
function HealthScoreRing({ score }: { score: number }) {
  const r = 42;
  const circ = 2 * Math.PI * r;
  const filled = (score / 100) * circ;
  const color = score < 50 ? "var(--red-500)" : score < 70 ? "var(--amber-500)" : "var(--forest-400)";

  return (
    <div style={{ position: "relative", width: 110, height: 110 }}>
      <svg width="110" height="110" viewBox="0 0 110 110" style={{ transform: "rotate(-90deg)" }}>
        <circle cx="55" cy="55" r={r} fill="none" stroke="var(--cream-100)" strokeWidth="8" />
        <circle
          cx="55" cy="55" r={r} fill="none"
          stroke={color} strokeWidth="8"
          strokeDasharray={`${filled} ${circ - filled}`}
          strokeLinecap="round"
          style={{ transition: "stroke-dasharray 1s var(--ease-out)" }}
        />
      </svg>
      <div style={{
        position: "absolute", inset: 0,
        display: "flex", flexDirection: "column",
        alignItems: "center", justifyContent: "center",
      }}>
        <span style={{
          fontFamily: "var(--font-display)", fontSize: "1.75rem",
          color, fontWeight: 400, lineHeight: 1,
        }}>{score}</span>
        <span className="t-xs c-muted" style={{ marginTop: 3 }}>/ 100</span>
      </div>
    </div>
  );
}

/* ─── Quick Stat Card ────────────────────────────────────────────── */
function QuickStat({ icon: Icon, label, value, href, accent = false }: {
  icon: React.ElementType; label: string; value: string | number;
  href: string; accent?: boolean;
}) {
  return (
    <Link href={href} style={{ textDecoration: "none" }}>
      <div
        className="card card-pad-sm"
        style={{
          background: accent ? "var(--forest-700)" : "var(--bg-surface)",
          color: accent ? "white" : "inherit",
          cursor: "pointer",
          transition: "all var(--dur-mid) var(--ease-out)",
          display: "flex", flexDirection: "column", gap: 8,
        }}
        onMouseEnter={e => {
          (e.currentTarget as HTMLDivElement).style.transform = "translateY(-2px)";
          (e.currentTarget as HTMLDivElement).style.boxShadow = "var(--shadow-md)";
        }}
        onMouseLeave={e => {
          (e.currentTarget as HTMLDivElement).style.transform = "none";
          (e.currentTarget as HTMLDivElement).style.boxShadow = "var(--shadow-sm)";
        }}
      >
        <Icon size={18} color={accent ? "rgba(255,255,255,0.7)" : "var(--forest-500)"} />
        <div>
          <div style={{
            fontFamily: "var(--font-display)", fontSize: "1.75rem",
            fontWeight: 400, lineHeight: 1,
            color: accent ? "white" : "var(--text-primary)",
          }}>{value}</div>
          <div style={{ fontSize: "0.75rem", marginTop: 3, opacity: accent ? 0.7 : 1, color: accent ? "white" : "var(--text-muted)" }}>
            {label}
          </div>
        </div>
        <div style={{ marginTop: "auto", fontSize: "0.75rem", opacity: 0.6 }}>
          View all →
        </div>
      </div>
    </Link>
  );
}

/* ─── Care Task Row ──────────────────────────────────────────────── */
function CareTaskRow({ task, onToggle }: {
  task: typeof MOCK_CARE_TASKS[0];
  onToggle: (id: string) => void;
}) {
  const icons: Record<string, React.ElementType> = {
    test: Droplets, appointment: Calendar,
    medication: Pill, lifestyle: Flame,
  };
  const Icon = icons[task.type] || CheckCircle2;
  const done = task.status === "done";

  return (
    <div
      style={{
        display: "flex", alignItems: "center", gap: 12,
        padding: "10px 0",
        borderBottom: "1px solid var(--border)",
        opacity: done ? 0.5 : 1,
        transition: "opacity var(--dur-mid)",
      }}
    >
      <button
        onClick={() => onToggle(task.id)}
        style={{
          width: 22, height: 22,
          borderRadius: "50%",
          border: done ? "none" : "2px solid var(--border-mid)",
          background: done ? "var(--forest-500)" : "transparent",
          display: "flex", alignItems: "center", justifyContent: "center",
          flexShrink: 0, cursor: "pointer",
          transition: "all var(--dur-mid)",
        }}
      >
        {done && <CheckCircle2 size={14} color="white" />}
      </button>
      <Icon size={14} color="var(--text-muted)" style={{ flexShrink: 0 }} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div className="t-small font-medium" style={{ textDecoration: done ? "line-through" : "none" }}>
          {task.title}
        </div>
        <div className="t-xs c-muted">Due {task.due}</div>
      </div>
      <span className={`badge ${task.priority === "high" ? "badge-red" : task.priority === "medium" ? "badge-amber" : "badge-gray"}`}>
        {task.priority}
      </span>
    </div>
  );
}

/* ─── Document Row ───────────────────────────────────────────────── */
function DocRow({ doc }: { doc: typeof MOCK_DOCUMENTS[0] }) {
  const srcIcon: Record<string, string> = {
    camera: "📷", upload: "📎", whatsapp: "💬",
  };
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 12,
      padding: "9px 0", borderBottom: "1px solid var(--border)",
    }}>
      <div style={{
        width: 34, height: 34, borderRadius: "var(--r-sm)",
        background: "var(--cream-50)", border: "1px solid var(--border)",
        display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: "0.875rem", flexShrink: 0,
      }}>{srcIcon[doc.source] ?? "📄"}</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div className="t-small font-medium truncate">{doc.name}</div>
        <div className="t-xs c-muted">{doc.uploadedAt} · {doc.extractedCount} values</div>
      </div>
      <span className="badge badge-green" style={{ fontSize: "0.625rem" }}>
        ✓ Processed
      </span>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════
   MAIN DASHBOARD
═══════════════════════════════════════════════════════════════════ */
export default function DashboardPage() {
  const [alerts, setAlerts] = useState(MOCK_ALERTS.filter((a) => !a.dismissed));
  const [tasks, setTasks] = useState(MOCK_CARE_TASKS);

  function dismissAlert(id: string) {
    setAlerts((prev) => prev.filter((a) => a.id !== id));
  }
  function toggleTask(id: string) {
    setTasks((prev) =>
      prev.map((t) => t.id === id ? { ...t, status: t.status === "done" ? "pending" : "done" } : t)
    );
  }

  const activeMeds = MOCK_MEDICATIONS.filter((m) => m.active);
  const keyLabs = MOCK_LABS.slice(0, 4);

  return (
    <AppShell>
      {/* ── Page header ── */}
      <div className="anim-fade-up" style={{ marginBottom: 28 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 12 }}>
          <div>
            <div className="t-xs c-muted" style={{ marginBottom: 4 }}>
              Good morning · Friday, 24 Jan 2025
            </div>
            <h1 className="t-display-md">
              Namaste, <em>Ramesh</em>
            </h1>
            <p className="t-small c-secondary" style={{ marginTop: 4 }}>
              Here's your health overview. 3 alerts need your attention.
            </p>
          </div>
          <Link href="/upload" className="btn btn-primary" style={{ gap: 8, flexShrink: 0 }}>
            <Upload size={15} />
            Upload Report
          </Link>
        </div>
      </div>

      {/* ── Alerts ── */}
      {alerts.length > 0 && (
        <div className="anim-fade-up delay-1" style={{ marginBottom: 24, display: "flex", flexDirection: "column", gap: 8 }}>
          {alerts.map((a) => (
            <AlertStrip key={a.id} alert={a} onDismiss={dismissAlert} />
          ))}
        </div>
      )}

      {/* ── Top row: health overview + quick stats ── */}
      <div
        className="anim-fade-up delay-2"
        style={{ display: "grid", gridTemplateColumns: "auto 1fr", gap: 20, marginBottom: 24, alignItems: "start" }}
      >
        {/* Health score card */}
        <div
          className="card card-md"
          style={{
            background: "linear-gradient(155deg, var(--forest-800) 0%, var(--forest-600) 100%)",
            border: "none", padding: "24px 28px",
            display: "flex", flexDirection: "column", alignItems: "center",
            gap: 16, minWidth: 220, position: "relative", overflow: "hidden",
          }}
        >
          {/* bg circles */}
          <div style={{
            position: "absolute", top: -30, right: -30,
            width: 120, height: 120, borderRadius: "50%",
            background: "rgba(255,255,255,0.04)",
          }} />
          <div style={{ textAlign: "center" }}>
            <div className="t-xs" style={{ color: "rgba(255,255,255,0.6)", marginBottom: 16 }}>
              HEALTH SCORE
            </div>
            <HealthScoreRing score={MOCK_PATIENT.healthScore} />
          </div>
          <div style={{ textAlign: "center" }}>
            <div style={{ color: "white", fontSize: "0.875rem", fontWeight: 500 }}>
              {MOCK_PATIENT.name}
            </div>
            <div style={{ color: "rgba(255,255,255,0.55)", fontSize: "0.75rem", marginTop: 2 }}>
              {MOCK_PATIENT.age}M · {MOCK_PATIENT.conditions[0]}
            </div>
          </div>
          {/* ABHA badge */}
          <div style={{
            display: "flex", alignItems: "center", gap: 5,
            background: "rgba(255,255,255,0.1)",
            borderRadius: 999, padding: "4px 12px",
            fontSize: "0.6875rem", color: "rgba(255,255,255,0.8)",
          }}>
            <Shield size={10} />
            ABHA {MOCK_PATIENT.abhaId}
          </div>
        </div>

        {/* Quick stats grid */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 12 }}>
          <QuickStat icon={FileText} label="Documents" value={MOCK_PATIENT.documentsCount} href="/upload" />
          <QuickStat icon={AlertCircle} label="Active Alerts" value={alerts.length} href="/alerts" accent />
          <QuickStat icon={Activity} label="Continuity Score" value={`${MOCK_PATIENT.continuityScore}%`} href="/doctor-brief" />
          <QuickStat icon={Calendar} label="Care Tasks" value={tasks.filter(t => t.status === "pending").length} href="#tasks" />
        </div>
      </div>

      {/* ── Main content grid ── */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: 20, alignItems: "start" }}>
        {/* Left column */}
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>

          {/* Key Lab Values */}
          <div className="anim-fade-up delay-2">
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
              <h2 className="t-heading">Key Lab Values</h2>
              <Link href="/timeline" className="btn btn-ghost btn-sm" style={{ gap: 5 }}>
                See all <ChevronRight size={13} />
              </Link>
            </div>
            <div className="grid-2">
              {keyLabs.map((lab, i) => (
                <div key={lab.id} className={`anim-fade-up delay-${i + 1}`}>
                  <LabValueCard lab={lab} />
                </div>
              ))}
            </div>
          </div>

          {/* HbA1c Trend Visual */}
          <div className="card card-pad anim-fade-up delay-3">
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <div>
                <h2 className="t-heading">HbA1c Trend</h2>
                <p className="t-small c-muted" style={{ marginTop: 2 }}>9-month progression</p>
              </div>
              <span className="badge badge-red">
                <TrendingUp size={10} /> Worsening
              </span>
            </div>
            {/* Sparkline bars */}
            <div style={{ display: "flex", alignItems: "flex-end", gap: 12, height: 80, marginBottom: 12 }}>
              {[
                { month: "Apr '24", val: 7.2, pct: 50 },
                { month: "Jul '24", val: 7.6, pct: 60 },
                { month: "Oct '24", val: 8.1, pct: 74 },
                { month: "Jan '25", val: 8.9, pct: 90 },
              ].map((d, i) => (
                <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
                  <div style={{
                    fontSize: "0.6875rem", fontFamily: "var(--font-display)",
                    fontWeight: 400,
                    color: i === 3 ? "var(--red-600)" : "var(--text-secondary)",
                  }}>
                    {d.val}%
                  </div>
                  <div style={{
                    width: "100%", height: `${d.pct}%`,
                    background: i === 3
                      ? "var(--red-500)"
                      : `rgba(215, 65, 65, ${0.3 + i * 0.15})`,
                    borderRadius: "var(--r-sm) var(--r-sm) 0 0",
                    transition: "height 0.8s var(--ease-out)",
                    animationDelay: `${i * 100}ms`,
                  }} />
                  <div style={{ fontSize: "0.625rem", color: "var(--text-muted)", whiteSpace: "nowrap" }}>
                    {d.month}
                  </div>
                </div>
              ))}
            </div>
            <div className="alert-strip alert-strip-critical" style={{ marginTop: 8 }}>
              <AlertCircle size={14} color="var(--red-600)" style={{ flexShrink: 0, marginTop: 1 }} />
              <span className="t-small">
                HbA1c has risen <strong>23.6%</strong> in 9 months. Medication adherence or dietary worsening likely.
                Discuss with Dr Mehta.
              </span>
            </div>
          </div>

          {/* Medications */}
          <div className="card card-pad anim-fade-up delay-3">
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
              <h2 className="t-heading">Active Medications</h2>
              <span className="badge badge-green">{activeMeds.length} active</span>
            </div>
            {activeMeds.map((med, i) => (
              <div
                key={med.id}
                style={{
                  display: "flex", alignItems: "center", gap: 12,
                  padding: "10px 0",
                  borderBottom: i < activeMeds.length - 1 ? "1px solid var(--border)" : "none",
                }}
              >
                <div style={{
                  width: 34, height: 34, borderRadius: "var(--r-sm)",
                  background: "var(--forest-50)", border: "1px solid var(--forest-100)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  flexShrink: 0,
                }}>
                  <Pill size={15} color="var(--forest-600)" />
                </div>
                <div style={{ flex: 1 }}>
                  <div className="t-small font-medium">
                    {med.name} <span style={{ fontWeight: 400, color: "var(--text-muted)" }}>{med.dose}</span>
                  </div>
                  <div className="t-xs c-muted">{med.frequency} · {med.prescribedBy}</div>
                </div>
                <span className="badge badge-green" style={{ fontSize: "0.625rem" }}>
                  Active
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Right column */}
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>

          {/* Quick actions */}
          <div className="anim-fade-up delay-2">
            <h2 className="t-heading" style={{ marginBottom: 12 }}>Quick Actions</h2>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {[
                { href: "/upload",       icon: Upload,      label: "Upload a Report",         sub: "PDF, image, or WhatsApp" },
                { href: "/doctor-brief", icon: Stethoscope, label: "Generate Doctor Brief",   sub: "Pre-consultation summary" },
                { href: "/payments",     icon: Lock,        label: "Private Health Payment",  sub: "Stealth address on Solana" },
                { href: "/timeline",     icon: Eye,         label: "Full Health Timeline",    sub: "All records in one view" },
              ].map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="card card-pad-sm"
                  style={{
                    display: "flex", alignItems: "center", gap: 12,
                    textDecoration: "none", cursor: "pointer",
                    transition: "all var(--dur-mid)",
                  }}
                  onMouseEnter={e => {
                    (e.currentTarget as HTMLAnchorElement).style.borderColor = "var(--forest-200)";
                    (e.currentTarget as HTMLAnchorElement).style.background = "var(--forest-25)";
                  }}
                  onMouseLeave={e => {
                    (e.currentTarget as HTMLAnchorElement).style.borderColor = "var(--border)";
                    (e.currentTarget as HTMLAnchorElement).style.background = "var(--bg-surface)";
                  }}
                >
                  <div style={{
                    width: 34, height: 34,
                    background: "var(--cream-50)",
                    borderRadius: "var(--r-sm)",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    flexShrink: 0,
                  }}>
                    <item.icon size={15} color="var(--forest-600)" />
                  </div>
                  <div style={{ flex: 1 }}>
                    <div className="t-small font-medium">{item.label}</div>
                    <div className="t-xs c-muted">{item.sub}</div>
                  </div>
                  <ChevronRight size={14} color="var(--text-muted)" />
                </Link>
              ))}
            </div>
          </div>

          {/* Care Tasks */}
          <div className="card card-pad anim-fade-up delay-3" id="tasks">
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
              <h2 className="t-heading">Care Tasks</h2>
              <span className="t-xs c-muted">
                {tasks.filter(t => t.status === "done").length}/{tasks.length} done
              </span>
            </div>
            <div className="progress-bar" style={{ marginBottom: 14 }}>
              <div
                className="progress-fill"
                style={{ width: `${(tasks.filter(t => t.status === "done").length / tasks.length) * 100}%` }}
              />
            </div>
            {tasks.map((task) => (
              <CareTaskRow key={task.id} task={task} onToggle={toggleTask} />
            ))}
          </div>

          {/* Family Overview */}
          <div className="card card-pad anim-fade-up delay-4">
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
              <h2 className="t-heading">Family</h2>
              <Link href="/family" className="btn btn-ghost btn-sm" style={{ gap: 4 }}>
                <Users size={13} /> Manage
              </Link>
            </div>
            {MOCK_FAMILY.map((member, i) => (
              <div
                key={member.id}
                style={{
                  display: "flex", alignItems: "center", gap: 10,
                  padding: "9px 0",
                  borderBottom: i < MOCK_FAMILY.length - 1 ? "1px solid var(--border)" : "none",
                  cursor: "pointer",
                }}
              >
                <div style={{ fontSize: "1.25rem", flexShrink: 0 }}>{member.avatar}</div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="t-small font-medium">{member.name}</div>
                  <div className="t-xs c-muted">{member.relation} · {member.conditions.join(", ")}</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{
                    fontFamily: "var(--font-display)", fontSize: "1rem",
                    color: member.healthScore < 60 ? "var(--red-600)" : member.healthScore < 75 ? "var(--amber-600)" : "var(--forest-600)",
                  }}>{member.healthScore}</div>
                  {member.alerts > 0 && (
                    <div style={{
                      fontSize: "0.6875rem", color: "var(--red-600)",
                      fontWeight: 600,
                    }}>{member.alerts} alert{member.alerts > 1 ? "s" : ""}</div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Recent Documents */}
          <div className="card card-pad anim-fade-up delay-5">
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
              <h2 className="t-heading">Recent Uploads</h2>
              <Link href="/upload" className="btn btn-ghost btn-sm" style={{ gap: 4 }}>
                <Upload size={13} /> Add
              </Link>
            </div>
            {MOCK_DOCUMENTS.map((doc) => (
              <DocRow key={doc.id} doc={doc} />
            ))}
          </div>

          {/* Trust footer */}
          <div style={{
            background: "var(--forest-25)", border: "1px solid var(--forest-100)",
            borderRadius: "var(--r-lg)", padding: "14px 16px",
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 6 }}>
              <Heart size={13} color="var(--forest-600)" />
              <span className="t-xs c-forest" style={{ fontWeight: 600 }}>DESIGNED FOR INDIA</span>
            </div>
            <p className="t-xs c-secondary" style={{ lineHeight: 1.7 }}>
              Your data is stored encrypted in Indian data centres.
              ABHA-compliant · DPDP Act 2023 compliant · Never sold.
            </p>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
