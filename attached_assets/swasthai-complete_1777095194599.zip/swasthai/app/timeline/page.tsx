"use client";
import { useState } from "react";
import Link from "next/link";
import { FlaskConical, Stethoscope, FileText, Syringe, Image, Filter, Download } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { MOCK_TIMELINE, MOCK_LABS, type TimelineEvent } from "@/lib/mock-data";

const TYPE_CONFIG: Record<TimelineEvent["type"], { Icon: React.ElementType; label: string; color: string; bg: string }> = {
  lab:          { Icon: FlaskConical, label: "Lab Report",    color: "var(--amber-600)",  bg: "var(--amber-100)" },
  prescription: { Icon: FileText,    label: "Prescription",  color: "#2563eb",            bg: "#eff6ff" },
  consultation: { Icon: Stethoscope, label: "Consultation",  color: "var(--forest-600)",  bg: "var(--forest-50)" },
  scan:         { Icon: Image,       label: "Scan / Imaging",color: "#7c3aed",             bg: "#f5f3ff" },
  vaccine:      { Icon: Syringe,     label: "Vaccine",       color: "var(--forest-400)",  bg: "var(--forest-25)" },
};

const SEV_BORDER: Record<TimelineEvent["severity"], string> = {
  critical: "var(--red-500)",
  warning:  "var(--amber-500)",
  normal:   "var(--forest-300)",
  info:     "#93c5fd",
};

const LAB_STATUS_COLOR: Record<string, string> = {
  high:   "var(--red-600)",
  low:    "#2563eb",
  normal: "var(--forest-600)",
};

function TimelineCard({ event }: { event: TimelineEvent }) {
  const [expanded, setExpanded] = useState(false);
  const cfg = TYPE_CONFIG[event.type];

  return (
    <div className="timeline-entry" style={{ marginBottom: 20 }}>
      <div
        className="timeline-node"
        style={{ background: cfg.bg, color: cfg.color, marginTop: 4 }}
      >
        <cfg.Icon size={11} />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        {/* Card */}
        <div
          className="card"
          style={{
            borderLeft: `3px solid ${SEV_BORDER[event.severity]}`,
            transition: "box-shadow var(--dur-mid)",
            cursor: "pointer",
          }}
          onClick={() => setExpanded(!expanded)}
          onMouseEnter={e => (e.currentTarget as HTMLDivElement).style.boxShadow = "var(--shadow-md)"}
          onMouseLeave={e => (e.currentTarget as HTMLDivElement).style.boxShadow = "var(--shadow-sm)"}
        >
          <div style={{ padding: "14px 16px" }}>
            {/* Header */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 8 }}>
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 4 }}>
                  <span className="badge" style={{ background: cfg.bg, color: cfg.color, border: `1px solid ${cfg.bg}`, fontSize: "0.625rem" }}>
                    {cfg.label}
                  </span>
                  {event.severity === "critical" && (
                    <span className="badge badge-red" style={{ fontSize: "0.625rem" }}>Critical</span>
                  )}
                  {event.severity === "warning" && (
                    <span className="badge badge-amber" style={{ fontSize: "0.625rem" }}>Attention</span>
                  )}
                </div>
                <h3 className="t-subheading">{event.title}</h3>
                <p className="t-xs c-muted" style={{ marginTop: 2 }}>
                  {event.date} · {event.subtitle}
                </p>
              </div>
              <span style={{
                fontSize: "0.6875rem", color: "var(--text-muted)",
                transform: expanded ? "rotate(180deg)" : "none",
                transition: "transform var(--dur-mid)",
                paddingTop: 2,
              }}>▾</span>
            </div>

            {/* Lab values preview */}
            {event.labs && (
              <div style={{ display: "flex", gap: 16, marginTop: 12, flexWrap: "wrap" }}>
                {event.labs.map((lab, i) => (
                  <div key={i} style={{ display: "flex", flexDirection: "column", gap: 1 }}>
                    <span className="t-xs c-muted">{lab.name}</span>
                    <span className="t-subheading" style={{ color: LAB_STATUS_COLOR[lab.status] }}>
                      {lab.value}
                    </span>
                  </div>
                ))}
              </div>
            )}

            {/* Meds preview */}
            {event.meds && !expanded && (
              <div style={{ display: "flex", gap: 6, marginTop: 10, flexWrap: "wrap" }}>
                {event.meds.map((m, i) => (
                  <span key={i} className="badge badge-gray" style={{ fontSize: "0.625rem" }}>{m}</span>
                ))}
              </div>
            )}
          </div>

          {/* Expanded content */}
          {expanded && (
            <div style={{
              borderTop: "1px solid var(--border)",
              padding: "14px 16px",
              background: "var(--cream-25)",
            }}>
              {event.notes && (
                <div style={{ marginBottom: 12 }}>
                  <p className="t-xs c-muted" style={{ marginBottom: 4 }}>Doctor Notes</p>
                  <p className="t-small c-secondary" style={{ lineHeight: 1.7 }}>{event.notes}</p>
                </div>
              )}
              {event.doctor && (
                <p className="t-small c-secondary">
                  <strong>Physician:</strong> {event.doctor}
                  {event.hospital && ` · ${event.hospital}`}
                </p>
              )}
              {event.meds && (
                <div style={{ marginTop: 10 }}>
                  <p className="t-xs c-muted" style={{ marginBottom: 6 }}>Medications</p>
                  <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                    {event.meds.map((m, i) => (
                      <span key={i} className="badge badge-green">{m}</span>
                    ))}
                  </div>
                </div>
              )}
              <button className="btn btn-ghost btn-sm" style={{ marginTop: 12, gap: 5 }}>
                <Download size={12} /> Download original
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function TimelinePage() {
  const [filter, setFilter] = useState<string>("all");

  const filtered = filter === "all"
    ? MOCK_TIMELINE
    : MOCK_TIMELINE.filter((e) => e.type === filter);

  return (
    <AppShell>
      {/* Header */}
      <div className="anim-fade-up" style={{ marginBottom: 28 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 12 }}>
          <div>
            <div className="t-xs c-muted" style={{ marginBottom: 4 }}>Ramesh Patel · 14 records</div>
            <h1 className="t-display-md">Health <em>Timeline</em></h1>
            <p className="t-small c-secondary" style={{ marginTop: 4 }}>
              Complete history — labs, visits, prescriptions, scans
            </p>
          </div>
          <Link href="/upload" className="btn btn-primary" style={{ gap: 7, flexShrink: 0 }}>
            + Add Record
          </Link>
        </div>
      </div>

      {/* Layout: timeline left, labs summary right */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 300px", gap: 24, alignItems: "start" }}>
        {/* Timeline */}
        <div>
          {/* Filter tabs */}
          <div className="anim-fade-up delay-1" style={{ display: "flex", gap: 6, marginBottom: 20, flexWrap: "wrap" }}>
            <Filter size={14} color="var(--text-muted)" style={{ marginTop: 6 }} />
            {[
              { key: "all", label: "All" },
              { key: "lab", label: "Lab Reports" },
              { key: "consultation", label: "Consultations" },
              { key: "prescription", label: "Prescriptions" },
            ].map((f) => (
              <button
                key={f.key}
                onClick={() => setFilter(f.key)}
                className={`badge ${filter === f.key ? "badge-forest" : "badge-gray"}`}
                style={{ cursor: "pointer", padding: "5px 14px", fontSize: "0.8125rem" }}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Events */}
          <div className="anim-fade-up delay-2">
            {filtered.map((event) => (
              <TimelineCard key={event.id} event={event} />
            ))}
          </div>
        </div>

        {/* Right: All lab values summary */}
        <div style={{ position: "sticky", top: 86 }}>
          <div className="card card-pad anim-fade-up delay-2">
            <h2 className="t-heading" style={{ marginBottom: 14 }}>All Lab Values</h2>
            {MOCK_LABS.map((lab, i) => (
              <div
                key={lab.id}
                style={{
                  display: "flex", justifyContent: "space-between", alignItems: "center",
                  padding: "9px 0",
                  borderBottom: i < MOCK_LABS.length - 1 ? "1px solid var(--border)" : "none",
                }}
              >
                <div>
                  <div className="t-small font-medium">{lab.name}</div>
                  <div className="t-xs c-muted">{lab.date}</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{
                    fontFamily: "var(--font-display)", fontSize: "1.1rem",
                    color: lab.status === "critical" ? "var(--red-600)"
                      : lab.status === "high" ? "var(--amber-600)"
                      : "var(--text-primary)",
                  }}>
                    {lab.value}
                    <span className="t-xs c-muted" style={{ fontFamily: "var(--font-body)", marginLeft: 3 }}>
                      {lab.unit}
                    </span>
                  </div>
                  <span className={`badge ${
                    lab.status === "critical" ? "badge-red"
                    : lab.status === "high" ? "badge-amber"
                    : "badge-green"
                  }`} style={{ fontSize: "0.625rem", marginTop: 2 }}>
                    {lab.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AppShell>
  );
}
