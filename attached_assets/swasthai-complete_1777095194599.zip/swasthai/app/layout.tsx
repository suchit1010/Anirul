import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "SwasthAI — Apni Health, Apne Haath",
  description:
    "India's AI-powered health memory. Upload all your reports, get a living health timeline, and share with your doctor instantly.",
  metadataBase: new URL("https://swasthai.health"),
  openGraph: {
    title: "SwasthAI — Apni Health, Apne Haath",
    description:
      "India's AI-powered health memory. Upload all your reports, get a living health timeline, and share with your doctor instantly.",
    type: "website",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#0d3d2a",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
