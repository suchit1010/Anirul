"use client";
import { useState } from "react";
import Link from "next/link";
import { ArrowRight, CheckCircle2, Shield, Phone, User, Heart, ChevronRight } from "lucide-react";
import { TopNav } from "@/components/layout/TopNav";

type Step = "welcome" | "phone" | "profile" | "conditions" | "done";

const CONDITIONS = [
  "Type 2 Diabetes", "Type 1 Diabetes", "Hypertension",
  "Heart Disease", "Thyroid (Hypothyroid)", "Thyroid (Hyperthyroid)",
  "Asthma / COPD", "CKD / Kidney Disease", "Dyslipidaemia",
  "Osteoarthritis", "Rheumatoid Arthritis", "PCOS",
  "None of the above",
];

export default function OnboardingPage() {
  const [step, setStep] = useState<Step>("welcome");
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState("");
  const [selected, setSelected] = useState<string[]>([]);

  const toggleCondition = (c: string) => {
    if (c === "None of the above") { setSelected(["None of the above"]); return; }
    setSelected(prev => {
      const without = prev.filter(x => x !== "None of the above");
      return without.includes(c) ? without.filter(x => x !== c) : [...without, c];
    });
  };

  const StepIndicator = ({ current }: { current: number }) => (
    <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 32, justifyContent: "center" }}>
      {["Account", "Profile", "Conditions", "Done"].map((label, i) => {
        const idx = i + 1;
        const done = idx < current;
        const active = idx === current;
        return (
          <div key={label} style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
              <div style={{
                width: 28, height: 28, borderRadius: "50%",
                background: done ? "var(--forest-500)" : active ? "var(--forest-700)" : "var(--cream-100)",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: "0.75rem", fontWeight: 700,
                color: done || active ? "white" : "var(--text-muted)",
                transition: "all var(--dur-mid)",
              }}>
                {done ? <CheckCircle2 size={14} /> : idx}
              </div>
              <span className="t-xs" style={{ color: active ? "var(--forest-700)" : "var(--text-muted)", whiteSpace: "nowrap" }}>
                {label}
              </span>
            </div>
            {i < 3 && (
              <div style={{
                width: 40, height: 1,
                background: done ? "var(--forest-400)" : "var(--border)",
                marginBottom: 20, transition: "background var(--dur-mid)",
              }} />
            )}
          </div>
        );
      })}
    </div>
  );

  return (
    <div style={{ minHeight: "100vh" }}>
      <TopNav />
      <div style={{
        minHeight: "calc(100vh - 58px)",
        display: "flex", alignItems: "center", justifyContent: "center",
        padding: "40px 16px",
        background: "linear-gradient(160deg, var(--forest-25) 0%, var(--cream-25) 100%)",
      }}>
        <div style={{ width: "100%", maxWidth: 480 }}>

          {/* Welcome */}
          {step === "welcome" && (
            <div className="card card-lg card-pad-lg anim-scale-in">
              <div style={{ textAlign: "center", marginBottom: 28 }}>
                <div style={{
                  width: 64, height: 64, borderRadius: "var(--r-lg)",
                  background: "var(--forest-700)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  margin: "0 auto 16px", fontSize: "1.75rem",
                }}>🏥</div>
                <h1 className="t-display-md" style={{ marginBottom: 8 }}>
                  Welcome to <em>SwasthAI</em>
                </h1>
                <p className="t-small c-muted" style={{ lineHeight: 1.7 }}>
                  Your AI health memory. Set up takes 2 minutes.
                </p>
              </div>

              <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 28 }}>
                {[
                  { icon: "📂", text: "Upload all your scattered reports — PDF, photo, WhatsApp" },
                  { icon: "🤖", text: "AI extracts and organises all data automatically" },
                  { icon: "📋", text: "Share 1-page brief with your doctor before every visit" },
                  { icon: "🔔", text: "Get WhatsApp alerts for critical trends and reminders" },
                ].map((item, i) => (
                  <div key={i} style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
                    <span style={{ fontSize: "1rem", flexShrink: 0 }}>{item.icon}</span>
                    <span className="t-small c-secondary" style={{ lineHeight: 1.6 }}>{item.text}</span>
                  </div>
                ))}
              </div>

              <button onClick={() => setStep("phone")} className="btn btn-primary btn-full btn-lg" style={{ gap: 8, marginBottom: 12 }}>
                Get Started Free <ArrowRight size={16} />
              </button>
              <p className="t-xs c-muted" style={{ textAlign: "center" }}>
                No credit card · ABHA optional · Cancel anytime
              </p>

              {/* Trust */}
              <div className="divider" />
              <div style={{ display: "flex", justifyContent: "center", gap: 20, flexWrap: "wrap" }}>
                {["🔒 Encrypted", "🇮🇳 India-native", "✅ ABHA-ready"].map((t) => (
                  <span key={t} className="t-xs c-muted">{t}</span>
                ))}
              </div>
            </div>
          )}

          {/* Phone step */}
          {step === "phone" && (
            <div className="card card-lg card-pad-lg anim-scale-in">
              <StepIndicator current={1} />
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
                <Phone size={18} color="var(--forest-600)" />
                <h2 className="t-display-md">Verify mobile</h2>
              </div>
              <p className="t-small c-muted" style={{ marginBottom: 28, lineHeight: 1.7 }}>
                We use your mobile number as your secure identity. No email required.
              </p>

              {!otpSent ? (
                <>
                  <label className="input-label">Mobile Number</label>
                  <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
                    <div style={{
                      padding: "11px 14px", background: "var(--cream-50)",
                      border: "1.5px solid var(--border-mid)", borderRadius: "var(--r-md)",
                      fontSize: "0.9375rem", color: "var(--text-secondary)", whiteSpace: "nowrap",
                    }}>🇮🇳 +91</div>
                    <input
                      className="input" placeholder="98250 12345"
                      value={phone} onChange={e => setPhone(e.target.value)}
                      maxLength={10} inputMode="numeric"
                    />
                  </div>
                  <button
                    onClick={() => setOtpSent(true)}
                    className="btn btn-primary btn-full"
                    disabled={phone.length < 10}
                    style={{ opacity: phone.length < 10 ? 0.5 : 1 }}
                  >
                    Send OTP
                  </button>
                </>
              ) : (
                <>
                  <p className="t-small c-secondary" style={{ marginBottom: 16 }}>
                    OTP sent to +91 {phone}
                  </p>
                  <label className="input-label">Enter 6-digit OTP</label>
                  <input
                    className="input" placeholder="000000"
                    value={otp} onChange={e => setOtp(e.target.value)}
                    maxLength={6} inputMode="numeric"
                    style={{ letterSpacing: "0.3em", fontSize: "1.25rem", textAlign: "center", marginBottom: 20 }}
                  />
                  <button
                    onClick={() => setStep("profile")}
                    className="btn btn-primary btn-full"
                    disabled={otp.length < 6}
                    style={{ opacity: otp.length < 6 ? 0.5 : 1 }}
                  >
                    Verify & Continue
                  </button>
                  <button className="btn btn-ghost btn-sm btn-full" style={{ marginTop: 8 }}
                    onClick={() => setOtpSent(false)}>
                    Change number
                  </button>
                </>
              )}

              <div style={{ marginTop: 20 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "10px 12px", background: "var(--forest-25)", borderRadius: "var(--r-md)" }}>
                  <Shield size={13} color="var(--forest-500)" />
                  <span className="t-xs c-muted">Your number is used only for verification and alerts. Never shared.</span>
                </div>
              </div>
            </div>
          )}

          {/* Profile step */}
          {step === "profile" && (
            <div className="card card-lg card-pad-lg anim-scale-in">
              <StepIndicator current={2} />
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
                <User size={18} color="var(--forest-600)" />
                <h2 className="t-display-md">Basic profile</h2>
              </div>
              <p className="t-small c-muted" style={{ marginBottom: 24 }}>
                This helps AI personalise health alerts and reference ranges.
              </p>

              <label className="input-label">Full Name</label>
              <input className="input" placeholder="Ramesh Patel" value={name}
                onChange={e => setName(e.target.value)} style={{ marginBottom: 16 }} />

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 16 }}>
                <div>
                  <label className="input-label">Age</label>
                  <input className="input" placeholder="54" value={age}
                    onChange={e => setAge(e.target.value)} inputMode="numeric" maxLength={3} />
                </div>
                <div>
                  <label className="input-label">Gender</label>
                  <select className="input" value={gender} onChange={e => setGender(e.target.value)}>
                    <option value="">Select</option>
                    <option>Male</option>
                    <option>Female</option>
                    <option>Other</option>
                  </select>
                </div>
              </div>

              <div style={{
                padding: "12px 14px", background: "var(--forest-25)",
                border: "1px solid var(--forest-100)", borderRadius: "var(--r-md)",
                marginBottom: 24,
              }}>
                <div className="t-xs c-forest" style={{ fontWeight: 600, marginBottom: 4 }}>Optional: Link ABHA ID</div>
                <div className="t-small c-muted" style={{ lineHeight: 1.6 }}>
                  Link your ABHA (Ayushman Bharat Health Account) for government health records integration.
                </div>
                <button className="btn btn-ghost btn-sm" style={{ marginTop: 8, gap: 5 }}>
                  Link ABHA <ChevronRight size={12} />
                </button>
              </div>

              <button
                onClick={() => setStep("conditions")}
                className="btn btn-primary btn-full"
                disabled={!name || !age || !gender}
                style={{ opacity: (!name || !age || !gender) ? 0.5 : 1 }}
              >
                Continue
              </button>
            </div>
          )}

          {/* Conditions step */}
          {step === "conditions" && (
            <div className="card card-lg card-pad-lg anim-scale-in">
              <StepIndicator current={3} />
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
                <Heart size={18} color="var(--forest-600)" />
                <h2 className="t-display-md">Health conditions</h2>
              </div>
              <p className="t-small c-muted" style={{ marginBottom: 20 }}>
                Select any known conditions. This helps AI set correct reference ranges and alerts. You can update later.
              </p>

              <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 24 }}>
                {CONDITIONS.map((c) => {
                  const active = selected.includes(c);
                  return (
                    <button
                      key={c}
                      onClick={() => toggleCondition(c)}
                      style={{
                        display: "flex", alignItems: "center", gap: 10,
                        padding: "10px 14px", borderRadius: "var(--r-md)",
                        border: active ? "1.5px solid var(--forest-400)" : "1px solid var(--border)",
                        background: active ? "var(--forest-25)" : "transparent",
                        cursor: "pointer", textAlign: "left",
                        transition: "all var(--dur-mid)",
                      }}
                    >
                      <div style={{
                        width: 18, height: 18, borderRadius: 4,
                        border: active ? "none" : "1.5px solid var(--border-mid)",
                        background: active ? "var(--forest-600)" : "transparent",
                        display: "flex", alignItems: "center", justifyContent: "center",
                        flexShrink: 0, transition: "all var(--dur-mid)",
                      }}>
                        {active && <CheckCircle2 size={12} color="white" />}
                      </div>
                      <span className="t-small" style={{ color: active ? "var(--forest-700)" : "var(--text-primary)", fontWeight: active ? 500 : 400 }}>
                        {c}
                      </span>
                    </button>
                  );
                })}
              </div>

              <button onClick={() => setStep("done")} className="btn btn-primary btn-full">
                {selected.length > 0 ? `Continue with ${selected.length} condition${selected.length > 1 ? "s" : ""}` : "Skip for now"}
              </button>
            </div>
          )}

          {/* Done */}
          {step === "done" && (
            <div className="card card-lg card-pad-lg anim-scale-in" style={{ textAlign: "center" }}>
              <div style={{
                width: 72, height: 72, borderRadius: "50%",
                background: "var(--forest-50)",
                display: "flex", alignItems: "center", justifyContent: "center",
                margin: "0 auto 20px", fontSize: "2rem",
              }}>🎉</div>
              <h2 className="t-display-md" style={{ marginBottom: 8 }}>
                You're all set,<br /><em>{name || "Namaste"}!</em>
              </h2>
              <p className="t-small c-muted" style={{ lineHeight: 1.7, marginBottom: 28 }}>
                Your health memory is ready. Start by uploading your first report — it takes 30 seconds.
              </p>
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                <Link href="/upload" className="btn btn-primary btn-full btn-lg" style={{ gap: 8 }}>
                  Upload My First Report <ArrowRight size={16} />
                </Link>
                <Link href="/dashboard" className="btn btn-ghost btn-full">
                  Go to Dashboard →
                </Link>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
