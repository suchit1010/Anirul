"use client";
import { useState } from "react";
import { Stethoscope, Copy, Share2, RefreshCw, CheckCircle2, AlertCircle, AlertTriangle, Info, Shield, Loader2, Download } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { MOCK_DOCTOR_BRIEF, MOCK_PATIENT } from "@/lib/mock-data";

function ContinuityRing({ score }: { score: number }) {
  const r = 28;
  const circ = 2 * Math.PI * r;
  const filled = (score / 100) * circ;
  return (
    <svg width="72" height="72" viewBox="0 0 72 72" style={{ transform: "rotate(-90deg)", flexShrink: 0 }}>
      <circle cx="36" cy="36" r={r} fill="none" stroke="rgba(255,255,255,0.12)" strokeWidth="5" />
      <circle cx="36" cy="36" r={r} fill="none" stroke="#4ade80" strokeWidth="5"
        strokeDasharray={`${filled} ${circ - filled}`} strokeLinecap="round" />
    </svg>
  );
}

function FlagSection({ title, icon: Icon, iconColor, items, variant }: {
  title: string; icon: React.ElementType; iconColor: string;
  items: string[]; variant: "critical" | "warning" | "info";
}) {
  const cls = variant === "critical" ? "alert-strip-critical"
    : variant === "warning" ? "alert-strip-warning" : "alert-strip-info";

  return (
    <div style={{ marginBottom: 20 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 10 }}>
        <Icon size={14} color={iconColor} />
        <span className="t-xs" style={{ color: "var(--text-muted)", letterSpacing: "0.06em", textTransform: "uppercase", fontWeight: 700 }}>
          {title}
        </span>
        <span className="badge badge-gray" style={{ fontSize: "0.625rem" }}>{items.length}</span>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {items.map((item, i) => (
          <div key={i} className={`alert-strip ${cls}`} style={{ padding: "10px 14px" }}>
            <span className="t-small" style={{ lineHeight: 1.6 }}>{item}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function DoctorBriefPage() {
  const [generating, setGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const brief = MOCK_DOCTOR_BRIEF;

  const handleRegenerate = async () => {
    setGenerating(true);
    await new Promise((r) => setTimeout(r, 2200));
    setGenerating(false);
  };

  const handleCopy = () => {
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <AppShell>
      {/* Header */}
      <div className="anim-fade-up" style={{ marginBottom: 28 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 12 }}>
          <div>
            <div className="t-xs c-muted" style={{ marginBottom: 4 }}>AI-generated · {brief.generatedAt}</div>
            <h1 className="t-display-md">Doctor <em>Brief</em></h1>
            <p className="t-small c-secondary" style={{ marginTop: 4 }}>
              Share this with your doctor before consultation — saves 8 minutes of intake.
            </p>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button onClick={handleRegenerate} className="btn btn-ghost" style={{ gap: 7 }} disabled={generating}>
              {generating ? <Loader2 size={14} style={{ animation: "spin 1s linear infinite" }} /> : <RefreshCw size={14} />}
              Regenerate
            </button>
            <button onClick={handleCopy} className="btn btn-secondary" style={{ gap: 7 }}>
              {copied ? <CheckCircle2 size={14} color="var(--forest-500)" /> : <Copy size={14} />}
              {copied ? "Copied!" : "Copy Brief"}
            </button>
            <button className="btn btn-primary" style={{ gap: 7 }}>
              <Share2 size={14} /> Share with Doctor
            </button>
          </div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 280px", gap: 24, alignItems: "start" }}>
        {/* Main brief */}
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>

          {/* Patient header card — dark */}
          <div
            className="anim-fade-up delay-1"
            style={{
              background: "linear-gradient(155deg, var(--forest-800) 0%, var(--forest-700) 100%)",
              borderRadius: "var(--r-xl)", padding: "24px 28px",
              display: "flex", alignItems: "flex-start", gap: 20,
              position: "relative", overflow: "hidden",
            }}
          >
            <div style={{ position: "absolute", top: -40, right: -40, width: 200, height: 200, borderRadius: "50%", background: "rgba(255,255,255,0.03)" }} />
            <div style={{ position: "absolute", bottom: -60, left: "30%", width: 240, height: 240, borderRadius: "50%", background: "rgba(46,143,94,0.06)" }} />

            <div style={{ flex: 1, zIndex: 1 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
                <Stethoscope size={14} color="rgba(255,255,255,0.5)" />
                <span className="t-xs" style={{ color: "rgba(255,255,255,0.5)", letterSpacing: "0.06em" }}>
                  PRE-CONSULTATION BRIEF
                </span>
              </div>
              <h2 style={{
                fontFamily: "var(--font-display)", fontSize: "1.5rem", fontWeight: 400,
                color: "white", lineHeight: 1.2, marginBottom: 8,
              }}>
                {MOCK_PATIENT.name}
              </h2>
              <p style={{ color: "rgba(255,255,255,0.65)", fontSize: "0.9375rem", lineHeight: 1.6, marginBottom: 16 }}>
                {brief.patientLine}
              </p>
              {/* Conditions */}
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                {MOCK_PATIENT.conditions.map((c) => (
                  <span key={c} style={{
                    background: "rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.8)",
                    borderRadius: 999, padding: "3px 12px", fontSize: "0.75rem", fontWeight: 500,
                  }}>{c}</span>
                ))}
              </div>
            </div>

            {/* Continuity score */}
            <div style={{ zIndex: 1, position: "relative", textAlign: "center" }}>
              <div style={{ position: "relative", display: "inline-block" }}>
                <ContinuityRing score={brief.continuityScore} />
                <div style={{
                  position: "absolute", inset: 0, display: "flex", flexDirection: "column",
                  alignItems: "center", justifyContent: "center",
                }}>
                  <span style={{ fontFamily: "var(--font-display)", fontSize: "1.1rem", color: "white" }}>
                    {brief.continuityScore}
                  </span>
                </div>
              </div>
              <div style={{ color: "rgba(255,255,255,0.5)", fontSize: "0.6875rem", marginTop: 4 }}>
                CONTINUITY
              </div>
            </div>
          </div>

          {/* Flags */}
          <div className="card card-pad anim-fade-up delay-2">
            <FlagSection
              title="Urgent Flags"
              icon={AlertCircle}
              iconColor="var(--red-600)"
              items={brief.urgentFlags}
              variant="critical"
            />
            <div className="divider" />
            <FlagSection
              title="Recent Highlights"
              icon={Info}
              iconColor="var(--forest-500)"
              items={brief.recentHighlights}
              variant="info"
            />
            <div className="divider" />
            <FlagSection
              title="Suggested Actions"
              icon={AlertTriangle}
              iconColor="var(--amber-600)"
              items={brief.suggestedActions}
              variant="warning"
            />
            <div className="divider" />
            <FlagSection
              title="Medication Flags"
              icon={AlertCircle}
              iconColor="var(--amber-600)"
              items={brief.medicationFlags}
              variant="warning"
            />
          </div>

          {/* AI disclaimer */}
          <div style={{
            background: "var(--cream-50)", border: "1px solid var(--border)",
            borderRadius: "var(--r-lg)", padding: "14px 16px",
            display: "flex", gap: 10,
          }}>
            <Shield size={15} color="var(--forest-500)" style={{ flexShrink: 0, marginTop: 1 }} />
            <p className="t-small c-muted" style={{ lineHeight: 1.7 }}>
              This brief is AI-generated from uploaded health records. It assists — it does not replace — clinical judgment.
              All decisions remain with the treating physician.
            </p>
          </div>
        </div>

        {/* Right panel */}
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {/* Share options */}
          <div className="card card-pad anim-fade-up delay-2">
            <h3 className="t-heading" style={{ marginBottom: 14 }}>Share Options</h3>
            {[
              { icon: "🔗", label: "Secure link", sub: "Valid for 24 hours" },
              { icon: "📱", label: "WhatsApp", sub: "Send to doctor's number" },
              { icon: "📄", label: "Download PDF", sub: "For physical visit" },
              { icon: "🏥", label: "ABHA share", sub: "Government health rail" },
            ].map((opt) => (
              <button key={opt.label} className="card card-pad-sm" style={{
                width: "100%", textAlign: "left", marginBottom: 8,
                display: "flex", alignItems: "center", gap: 10,
                cursor: "pointer", transition: "all var(--dur-mid)",
              }}
              onMouseEnter={e => (e.currentTarget.style.borderColor = "var(--forest-200)")}
              onMouseLeave={e => (e.currentTarget.style.borderColor = "var(--border)")}
              >
                <span style={{ fontSize: "1.1rem" }}>{opt.icon}</span>
                <div>
                  <div className="t-small font-medium">{opt.label}</div>
                  <div className="t-xs c-muted">{opt.sub}</div>
                </div>
              </button>
            ))}
          </div>

          {/* Consent on chain */}
          <div className="stealth-card anim-fade-up delay-3">
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10, position: "relative", zIndex: 1 }}>
              <Shield size={15} color="rgba(255,255,255,0.7)" />
              <span className="t-xs" style={{ color: "rgba(255,255,255,0.7)" }}>CONSENT ON SOLANA</span>
            </div>
            <p style={{ color: "rgba(255,255,255,0.75)", fontSize: "0.8125rem", lineHeight: 1.7, marginBottom: 12, position: "relative", zIndex: 1 }}>
              When you share this brief, the consent hash is written to Solana.
              Tamper-evident. Cryptographically provable.
            </p>
            <div className="stealth-chain-hash" style={{ position: "relative", zIndex: 1 }}>
              tx: 5HzS...k9Qf<br />
              block: 298,441,922<br />
              consent: 0xd4f2...7c81
            </div>
          </div>

          {/* Stats */}
          <div className="card card-pad anim-fade-up delay-3">
            <h3 className="t-heading" style={{ marginBottom: 12 }}>Brief Stats</h3>
            {[
              { label: "Records analysed", value: `${MOCK_PATIENT.documentsCount}` },
              { label: "Time span covered", value: "9 months" },
              { label: "Lab values included", value: "8" },
              { label: "Medications reviewed", value: "5" },
              { label: "Generation time", value: "1.4s" },
            ].map((s) => (
              <div key={s.label} style={{
                display: "flex", justifyContent: "space-between",
                padding: "7px 0", borderBottom: "1px solid var(--border)",
              }}>
                <span className="t-small c-muted">{s.label}</span>
                <span className="t-small font-medium">{s.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </AppShell>
  );
}
