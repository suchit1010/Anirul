"use client";
import { useState } from "react";
import { Lock, Shield, Eye, EyeOff, CheckCircle2, Copy, ExternalLink, AlertCircle, ChevronRight, Loader2 } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";

type PayCategory = "mental_health" | "reproductive_health" | "addiction_treatment" | "general" | "lab";
type PayStep = "select" | "amount" | "confirm" | "processing" | "done";

const CATEGORIES: { id: PayCategory; label: string; desc: string; icon: string; sensitive: boolean }[] = [
  { id: "mental_health",       label: "Mental Health / Therapy",     desc: "Psychiatry, therapy, counselling",  icon: "🧠", sensitive: true },
  { id: "reproductive_health", label: "Reproductive / Fertility",    desc: "Fertility clinic, gynaecology",     icon: "🌸", sensitive: true },
  { id: "addiction_treatment", label: "Addiction Treatment",         desc: "Rehabilitation, de-addiction",      icon: "💛", sensitive: true },
  { id: "general",             label: "General Consultation",        desc: "GP, specialist visit",              icon: "🏥", sensitive: false },
  { id: "lab",                 label: "Diagnostic / Lab Test",       desc: "Blood work, imaging, pathology",    icon: "🔬", sensitive: false },
];

const PROVIDERS = [
  { id: "p1", name: "Asha HIV Testing & Counselling Centre", category: "lab",               wallet: "7fG3...kP9Q", amount: 2400 },
  { id: "p2", name: "MindSpace Therapy Clinic",              category: "mental_health",      wallet: "3aR7...mK2L", amount: 1800 },
  { id: "p3", name: "Bloom Fertility Centre",                category: "reproductive_health",wallet: "9dW5...nJ4M", amount: 8500 },
  { id: "p4", name: "Sanjeevani De-Addiction Centre",        category: "addiction_treatment",wallet: "2eX8...oL6N", amount: 3200 },
];

const STEALTH_HASH = "5HzSf7r2QmPkL9vN3cWxE8bT4dAuY1jGiMnKoRs6eFhV0qZpDtCwXu";
const VIEWING_KEY  = "vk_7f3a9c2e1b8d4f6a0e5c3d9b2a7f1e4c8g5h2i9j6k3l0m7n4o1p8q5r2s9t6u3v0w7x4y1";
const TX_SIG       = "5HzSf7r2...k9Qf";

export default function PaymentsPage() {
  const [step, setStep] = useState<PayStep>("select");
  const [selectedCat, setSelectedCat] = useState<PayCategory | null>(null);
  const [selectedProvider, setSelectedProvider] = useState<typeof PROVIDERS[0] | null>(null);
  const [showKey, setShowKey] = useState(false);
  const [keyCopied, setKeyCopied] = useState(false);
  const [proofMode, setProofMode] = useState(false);

  const copyKey = () => {
    setKeyCopied(true);
    setTimeout(() => setKeyCopied(false), 2000);
  };

  const handlePay = async () => {
    setStep("processing");
    await new Promise((r) => setTimeout(r, 2800));
    setStep("done");
  };

  return (
    <AppShell>
      {/* Header */}
      <div className="anim-fade-up" style={{ marginBottom: 28 }}>
        <div className="t-xs c-muted" style={{ marginBottom: 4 }}>Zero-knowledge health privacy</div>
        <h1 className="t-display-md">Private Health <em>Payment</em></h1>
        <p className="t-small c-secondary" style={{ marginTop: 4 }}>
          Pay for sensitive healthcare privately. No one can link your payment to a provider or condition.
        </p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 300px", gap: 24, alignItems: "start" }}>
        {/* Left: payment flow */}
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>

          {/* How it works — always visible */}
          <div className="card card-pad anim-fade-up delay-1">
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 16 }}>
              <Lock size={15} color="var(--forest-600)" />
              <h3 className="t-heading">How Private Payments Work</h3>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {[
                { step: "01", title: "Choose provider & pay", desc: "We generate a stealth address — a one-time address on Solana. Your wallet sends to this address." },
                { step: "02", title: "Blockchain sees nothing sensitive", desc: "On-chain: wallet X sent SOL to address Y. No provider name. No condition. No link to your identity." },
                { step: "03", title: "You receive a Viewing Key", desc: "Your proof of payment. Show this to your insurer to get reimbursed — without revealing the provider." },
              ].map((s) => (
                <div key={s.step} style={{ display: "flex", gap: 14 }}>
                  <div style={{
                    width: 32, height: 32, borderRadius: "50%",
                    background: "var(--forest-700)", color: "white",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: "0.6875rem", fontWeight: 700, flexShrink: 0,
                  }}>{s.step}</div>
                  <div>
                    <div className="t-small font-medium" style={{ marginBottom: 2 }}>{s.title}</div>
                    <div className="t-small c-muted" style={{ lineHeight: 1.6 }}>{s.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Step: Select category */}
          {step === "select" && (
            <div className="anim-fade-up delay-2">
              <h3 className="t-heading" style={{ marginBottom: 14 }}>Select Category</h3>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat.id}
                    className="card card-pad-sm"
                    style={{
                      display: "flex", alignItems: "center", gap: 12,
                      cursor: "pointer", textAlign: "left",
                      border: selectedCat === cat.id ? "1.5px solid var(--forest-400)" : "1px solid var(--border)",
                      background: selectedCat === cat.id ? "var(--forest-25)" : "var(--bg-surface)",
                      transition: "all var(--dur-mid)",
                      width: "100%",
                    }}
                    onClick={() => setSelectedCat(cat.id)}
                  >
                    <span style={{ fontSize: "1.5rem" }}>{cat.icon}</span>
                    <div style={{ flex: 1 }}>
                      <div className="t-small font-medium">{cat.label}</div>
                      <div className="t-xs c-muted">{cat.desc}</div>
                    </div>
                    {cat.sensitive && (
                      <span className="badge badge-forest" style={{ fontSize: "0.625rem", gap: 3 }}>
                        <Shield size={8} /> Private
                      </span>
                    )}
                    {selectedCat === cat.id && <CheckCircle2 size={16} color="var(--forest-500)" />}
                  </button>
                ))}
              </div>

              {selectedCat && (
                <div style={{ marginTop: 20 }}>
                  <h3 className="t-heading" style={{ marginBottom: 12 }}>Select Provider</h3>
                  {PROVIDERS.filter(p => p.category === selectedCat || selectedCat === "general" || selectedCat === "lab").slice(0, 3).map((prov) => (
                    <button
                      key={prov.id}
                      className="card card-pad-sm"
                      style={{
                        width: "100%", display: "flex", alignItems: "center", gap: 12,
                        cursor: "pointer", textAlign: "left", marginBottom: 8,
                        border: selectedProvider?.id === prov.id ? "1.5px solid var(--forest-400)" : "1px solid var(--border)",
                        transition: "all var(--dur-mid)",
                      }}
                      onClick={() => setSelectedProvider(prov)}
                    >
                      <div style={{ flex: 1 }}>
                        <div className="t-small font-medium">{prov.name}</div>
                        <div className="t-xs c-muted">Wallet: {prov.wallet}</div>
                      </div>
                      <div style={{ textAlign: "right" }}>
                        <div className="t-subheading">₹{prov.amount.toLocaleString()}</div>
                        {selectedProvider?.id === prov.id && <CheckCircle2 size={14} color="var(--forest-500)" style={{ marginTop: 2 }} />}
                      </div>
                    </button>
                  ))}

                  {selectedProvider && (
                    <button
                      className="btn btn-primary btn-full btn-lg"
                      style={{ marginTop: 8, gap: 8 }}
                      onClick={() => setStep("confirm")}
                    >
                      <Lock size={16} /> Continue to Payment
                    </button>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Step: Confirm */}
          {step === "confirm" && selectedProvider && (
            <div className="anim-scale-in">
              <div className="card card-pad" style={{ marginBottom: 16 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 16 }}>
                  <Lock size={15} color="var(--forest-600)" />
                  <h3 className="t-heading">Payment Summary</h3>
                </div>

                {[
                  { label: "Provider", value: selectedProvider.name },
                  { label: "Amount", value: `₹${selectedProvider.amount.toLocaleString()}` },
                  { label: "On-chain record", value: "Anonymous SOL transfer — no provider link" },
                  { label: "Insurance proof", value: '"Healthcare Service" (not provider name)' },
                ].map((row) => (
                  <div key={row.label} style={{
                    display: "flex", justifyContent: "space-between",
                    padding: "9px 0", borderBottom: "1px solid var(--border)",
                  }}>
                    <span className="t-small c-muted">{row.label}</span>
                    <span className="t-small font-medium" style={{ textAlign: "right", maxWidth: "55%" }}>{row.value}</span>
                  </div>
                ))}

                <div className="alert-strip alert-strip-info" style={{ marginTop: 14 }}>
                  <Shield size={14} color="var(--forest-500)" />
                  <div className="t-small">
                    A stealth address will be generated for this payment. Only you (with the viewing key) can link it back to this provider.
                  </div>
                </div>
              </div>

              <div style={{ display: "flex", gap: 10 }}>
                <button onClick={() => setStep("select")} className="btn btn-ghost" style={{ gap: 7 }}>
                  ← Back
                </button>
                <button onClick={handlePay} className="btn btn-primary" style={{ flex: 1, gap: 8 }}>
                  <Lock size={15} /> Pay Privately — ₹{selectedProvider.amount.toLocaleString()}
                </button>
              </div>
            </div>
          )}

          {/* Step: Processing */}
          {step === "processing" && (
            <div className="card card-pad anim-scale-in" style={{ textAlign: "center", padding: "40px 32px" }}>
              <div style={{
                width: 60, height: 60, borderRadius: "50%",
                background: "var(--forest-50)", display: "flex", alignItems: "center", justifyContent: "center",
                margin: "0 auto 20px",
              }}>
                <Loader2 size={26} color="var(--forest-600)" style={{ animation: "spin 1s linear infinite" }} />
              </div>
              <h3 className="t-heading" style={{ marginBottom: 8 }}>Processing Private Payment</h3>
              <div style={{ display: "flex", flexDirection: "column", gap: 8, marginTop: 20, textAlign: "left" }}>
                {[
                  "Generating ephemeral keypair…",
                  "Computing stealth address via ECDH…",
                  "Broadcasting transaction to Solana…",
                  "Writing consent hash to chain…",
                  "Generating viewing key…",
                ].map((s, i) => (
                  <div key={i} style={{ display: "flex", gap: 8, alignItems: "center", fontSize: "0.8125rem", color: "var(--text-muted)" }}>
                    <Loader2 size={12} style={{ animation: "spin 1s linear infinite", animationDelay: `${i * 100}ms`, flexShrink: 0 }} />
                    {s}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Step: Done */}
          {step === "done" && (
            <div className="anim-scale-in">
              {/* Success */}
              <div className="card card-pad" style={{
                background: "var(--forest-700)", border: "none", marginBottom: 16,
              }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
                  <CheckCircle2 size={20} color="#4ade80" />
                  <h3 style={{ color: "white", fontFamily: "var(--font-body)", fontWeight: 600 }}>
                    Payment confirmed privately
                  </h3>
                </div>
                <p style={{ color: "rgba(255,255,255,0.65)", fontSize: "0.8125rem", lineHeight: 1.7, marginBottom: 14 }}>
                  Transaction written to Solana. On-chain observers see only an anonymous SOL transfer — no provider name, no condition, no identity link.
                </p>
                <div className="stealth-chain-hash">
                  tx: {TX_SIG}<br />
                  block: 298,441,922 · {new Date().toLocaleString("en-IN")}<br />
                  stealth addr: 9mK3...pL7R
                </div>
                <a href="#" className="btn btn-ghost btn-sm" style={{ marginTop: 12, color: "rgba(255,255,255,0.6)", gap: 5 }}>
                  <ExternalLink size={12} /> View on Solana Explorer
                </a>
              </div>

              {/* Viewing key */}
              <div className="card card-pad" style={{ background: "var(--amber-50)", borderColor: "#fcd34d" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
                  <Shield size={15} color="var(--amber-600)" />
                  <h3 className="t-heading" style={{ color: "var(--amber-700)" }}>Save Your Viewing Key</h3>
                </div>
                <p className="t-small c-secondary" style={{ lineHeight: 1.7, marginBottom: 12 }}>
                  This key is your proof of payment. Use it to generate a redacted insurance proof
                  — shows "Healthcare Service + Amount" but never the provider name.
                  <strong> We never store this key. Save it now.</strong>
                </p>

                <div style={{
                  background: "white", borderRadius: "var(--r-md)", padding: "10px 12px",
                  border: "1px solid #fcd34d", marginBottom: 10,
                  fontFamily: "var(--font-mono)", fontSize: "0.6875rem",
                  wordBreak: "break-all", lineHeight: 1.7,
                  color: showKey ? "var(--text-primary)" : "transparent",
                  textShadow: showKey ? "none" : "0 0 8px rgba(0,0,0,0.6)",
                  userSelect: showKey ? "text" : "none",
                  transition: "all var(--dur-mid)",
                }}>
                  {VIEWING_KEY}
                </div>

                <div style={{ display: "flex", gap: 8 }}>
                  <button
                    onClick={() => setShowKey(!showKey)}
                    className="btn btn-ghost btn-sm"
                    style={{ gap: 6 }}
                  >
                    {showKey ? <EyeOff size={13} /> : <Eye size={13} />}
                    {showKey ? "Hide" : "Reveal Key"}
                  </button>
                  <button onClick={copyKey} className="btn btn-secondary btn-sm" style={{ gap: 6 }}>
                    {keyCopied ? <CheckCircle2 size={13} color="var(--forest-500)" /> : <Copy size={13} />}
                    {keyCopied ? "Copied!" : "Copy Key"}
                  </button>
                </div>
              </div>

              {/* Insurance proof */}
              {!proofMode ? (
                <button
                  className="btn btn-secondary btn-full"
                  style={{ marginTop: 14, gap: 8 }}
                  onClick={() => setProofMode(true)}
                >
                  Generate Insurance Proof →
                </button>
              ) : (
                <div className="card card-pad" style={{ marginTop: 14, background: "var(--forest-25)", borderColor: "var(--forest-100)" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
                    <CheckCircle2 size={15} color="var(--forest-600)" />
                    <h3 className="t-heading">Insurance Proof Generated</h3>
                  </div>
                  <p className="t-small c-muted" style={{ marginBottom: 12, lineHeight: 1.7 }}>
                    This proof reveals only what your insurer needs. Provider name and condition are redacted.
                  </p>
                  {[
                    { label: "Amount",        value: `₹${selectedProvider?.amount.toLocaleString() ?? "2,400"}` },
                    { label: "Category",      value: "Healthcare Service" },
                    { label: "Date",          value: new Date().toLocaleDateString("en-IN") },
                    { label: "Provider Name", value: "✗ Redacted" },
                    { label: "Condition",     value: "✗ Redacted" },
                    { label: "Verified by",   value: "Solana blockchain (view tx)" },
                  ].map((row) => (
                    <div key={row.label} style={{
                      display: "flex", justifyContent: "space-between",
                      padding: "7px 0", borderBottom: "1px solid var(--forest-100)",
                    }}>
                      <span className="t-small c-muted">{row.label}</span>
                      <span className="t-small font-medium" style={{
                        color: row.value.startsWith("✗") ? "var(--text-muted)" : "var(--text-primary)",
                      }}>{row.value}</span>
                    </div>
                  ))}
                  <button className="btn btn-primary btn-sm" style={{ marginTop: 12, gap: 6 }}>
                    <CheckCircle2 size={13} /> Download Proof PDF
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right: trust + why panel */}
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {/* Why private payments */}
          <div className="card card-pad anim-fade-up delay-1">
            <h3 className="t-heading" style={{ marginBottom: 12 }}>Why Privacy Matters</h3>
            {[
              { emoji: "🏢", text: "Your employer could see UPI transactions if they access expense claims" },
              { emoji: "👨‍👩‍👧", text: "Family members see shared bank statements" },
              { emoji: "📋", text: "Insurers use payment history for premium calculation" },
              { emoji: "🔓", text: "Standard crypto payments are fully public on-chain" },
            ].map((item, i) => (
              <div key={i} style={{ display: "flex", gap: 10, marginBottom: 10, alignItems: "flex-start" }}>
                <span style={{ flexShrink: 0, fontSize: "1rem" }}>{item.emoji}</span>
                <p className="t-small c-secondary" style={{ lineHeight: 1.6 }}>{item.text}</p>
              </div>
            ))}
          </div>

          {/* Technical */}
          <div className="stealth-card anim-fade-up delay-2">
            <div style={{ position: "relative", zIndex: 1 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
                <Lock size={14} color="rgba(255,255,255,0.7)" />
                <span className="t-xs" style={{ color: "rgba(255,255,255,0.6)" }}>TECHNICAL DESIGN</span>
              </div>
              {[
                ["Protocol", "Solana stealth addresses"],
                ["Privacy", "One-time ephemeral keypair per tx"],
                ["On-chain", "Anonymous SOL transfer only"],
                ["Proof", "ECDH-derived viewing key"],
                ["Insurer", "Redacted category + amount"],
              ].map(([k, v]) => (
                <div key={k} style={{
                  display: "flex", justifyContent: "space-between",
                  padding: "6px 0", borderBottom: "1px solid rgba(255,255,255,0.06)",
                  fontSize: "0.75rem",
                }}>
                  <span style={{ color: "rgba(255,255,255,0.5)" }}>{k}</span>
                  <span style={{ color: "rgba(255,255,255,0.8)", fontWeight: 500 }}>{v}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Supported wallets */}
          <div className="card card-pad anim-fade-up delay-3">
            <h3 className="t-subheading" style={{ marginBottom: 10 }}>Supported</h3>
            {["Phantom Wallet", "Solflare", "Backpack", "Coinbase Wallet", "Direct SOL / USDC"].map((w) => (
              <div key={w} style={{
                display: "flex", alignItems: "center", gap: 8,
                padding: "7px 0", borderBottom: "1px solid var(--border)",
                fontSize: "0.8125rem", color: "var(--text-secondary)",
              }}>
                <CheckCircle2 size={12} color="var(--forest-400)" />
                {w}
              </div>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </AppShell>
  );
}
