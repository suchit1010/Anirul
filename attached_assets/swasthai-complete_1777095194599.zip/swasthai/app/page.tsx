"use client";
import { useState } from "react";
import Link from "next/link";
import {
  Shield, Upload, TrendingUp, Bell, Users, Lock,
  CheckCircle2, ArrowRight, Star, Heart, Stethoscope,
  ChevronDown,
} from "lucide-react";
import { TopNav } from "@/components/layout/TopNav";

function TrustBadge({ icon, label }: { icon: string; label: string }) {
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 6,
      padding: "6px 14px",
      background: "rgba(255,255,255,0.08)",
      borderRadius: 999,
      border: "1px solid rgba(255,255,255,0.12)",
      fontSize: "0.75rem",
      color: "rgba(255,255,255,0.85)",
    }}>
      <span>{icon}</span> {label}
    </div>
  );
}

function FeatureCard({ icon: Icon, title, desc, accent = false }: {
  icon: React.ElementType; title: string; desc: string; accent?: boolean;
}) {
  return (
    <div className="card card-pad" style={{
      background: accent ? "var(--forest-700)" : "var(--bg-surface)",
      border: accent ? "none" : "1px solid var(--border)",
      transition: "all var(--dur-mid)",
      height: "100%",
    }}
    onMouseEnter={e => {
      (e.currentTarget as HTMLDivElement).style.transform = "translateY(-3px)";
      (e.currentTarget as HTMLDivElement).style.boxShadow = "var(--shadow-lg)";
    }}
    onMouseLeave={e => {
      (e.currentTarget as HTMLDivElement).style.transform = "none";
      (e.currentTarget as HTMLDivElement).style.boxShadow = "var(--shadow-sm)";
    }}
    >
      <div style={{
        width: 44, height: 44, borderRadius: "var(--r-md)",
        background: accent ? "rgba(255,255,255,0.1)" : "var(--forest-50)",
        display: "flex", alignItems: "center", justifyContent: "center",
        marginBottom: 14,
      }}>
        <Icon size={20} color={accent ? "white" : "var(--forest-600)"} />
      </div>
      <h3 className="t-heading" style={{ marginBottom: 6, color: accent ? "white" : "inherit" }}>
        {title}
      </h3>
      <p className="t-small" style={{ color: accent ? "rgba(255,255,255,0.65)" : "var(--text-secondary)", lineHeight: 1.7 }}>
        {desc}
      </p>
    </div>
  );
}

function PricingCard({ plan, price, period, features, cta, highlight = false }: {
  plan: string; price: string; period: string;
  features: string[]; cta: string; highlight?: boolean;
}) {
  return (
    <div className="card" style={{
      padding: "28px 24px",
      background: highlight ? "var(--forest-700)" : "var(--bg-surface)",
      border: highlight ? "none" : "1px solid var(--border)",
      position: "relative",
      transition: "all var(--dur-mid)",
    }}
    onMouseEnter={e => {
      (e.currentTarget as HTMLDivElement).style.transform = "translateY(-4px)";
      (e.currentTarget as HTMLDivElement).style.boxShadow = "var(--shadow-lg)";
    }}
    onMouseLeave={e => {
      (e.currentTarget as HTMLDivElement).style.transform = "none";
      (e.currentTarget as HTMLDivElement).style.boxShadow = "var(--shadow-sm)";
    }}
    >
      {highlight && (
        <div style={{
          position: "absolute", top: -12, left: "50%", transform: "translateX(-50%)",
          background: "#4ade80", color: "var(--forest-900)",
          borderRadius: 999, padding: "3px 14px",
          fontSize: "0.6875rem", fontWeight: 700, whiteSpace: "nowrap",
        }}>Most Popular</div>
      )}
      <div className="t-xs" style={{ color: highlight ? "rgba(255,255,255,0.5)" : "var(--text-muted)", marginBottom: 8 }}>
        {plan}
      </div>
      <div style={{ display: "flex", alignItems: "baseline", gap: 4, marginBottom: 4 }}>
        <span style={{
          fontFamily: "var(--font-display)", fontSize: "2.5rem", fontWeight: 300,
          color: highlight ? "white" : "var(--text-primary)",
        }}>{price}</span>
        <span style={{ color: highlight ? "rgba(255,255,255,0.5)" : "var(--text-muted)", fontSize: "0.875rem" }}>
          {period}
        </span>
      </div>
      <div className="divider" style={{ borderColor: highlight ? "rgba(255,255,255,0.1)" : "var(--border)" }} />
      <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 24 }}>
        {features.map((f, i) => (
          <div key={i} style={{ display: "flex", gap: 8, alignItems: "flex-start" }}>
            <CheckCircle2 size={14} color={highlight ? "#4ade80" : "var(--forest-500)"}
              style={{ flexShrink: 0, marginTop: 2 }} />
            <span className="t-small" style={{ color: highlight ? "rgba(255,255,255,0.75)" : "var(--text-secondary)" }}>
              {f}
            </span>
          </div>
        ))}
      </div>
      <Link
        href="/onboarding"
        className={`btn btn-full ${highlight ? "" : "btn-secondary"}`}
        style={{
          background: highlight ? "rgba(255,255,255,0.12)" : undefined,
          color: highlight ? "white" : undefined,
          border: highlight ? "1px solid rgba(255,255,255,0.2)" : undefined,
        }}
      >
        {cta}
      </Link>
    </div>
  );
}

export default function LandingPage() {
  const [faqOpen, setFaqOpen] = useState<number | null>(null);

  return (
    <div style={{ minHeight: "100vh" }}>
      <TopNav />

      {/* ─── Hero ───────────────────────────────────────────── */}
      <section className="hero-gradient" style={{ padding: "72px 0 80px", position: "relative" }}>
        <div className="grain-overlay" />
        <div className="container" style={{ position: "relative", zIndex: 1 }}>
          {/* Trust badges row */}
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 36 }}>
            <TrustBadge icon="🇮🇳" label="India-native" />
            <TrustBadge icon="🔒" label="End-to-end encrypted" />
            <TrustBadge icon="✅" label="ABHA / ABDM ready" />
            <TrustBadge icon="⚡" label="AI in 30 seconds" />
          </div>

          <div style={{ maxWidth: 680 }}>
            <h1 className="t-display-xl" style={{ color: "white", marginBottom: 20, lineHeight: 1.08 }}>
              Apni Health,<br />
              <em style={{ color: "#4ade80" }}>Apne Haath.</em>
            </h1>
            <p className="t-body" style={{
              color: "rgba(255,255,255,0.72)", marginBottom: 36,
              maxWidth: 520, lineHeight: 1.75,
            }}>
              India's AI health memory. Upload all your scattered reports —
              WhatsApp, PDF, paper. Get a living timeline. Share with your
              doctor in one tap. Never lose a test result again.
            </p>

            <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 40 }}>
              <Link href="/dashboard" className="btn btn-lg" style={{
                background: "white", color: "var(--forest-800)",
                fontWeight: 600, gap: 8,
              }}>
                Start Free — No card needed <ArrowRight size={16} />
              </Link>
              <Link href="/dashboard" className="btn btn-lg btn-secondary" style={{
                background: "transparent", color: "rgba(255,255,255,0.85)",
                border: "1.5px solid rgba(255,255,255,0.2)",
              }}>
                See Demo Dashboard
              </Link>
            </div>

            {/* Social proof */}
            <div style={{ display: "flex", alignItems: "center", gap: 14, flexWrap: "wrap" }}>
              <div style={{ display: "flex" }}>
                {["👴", "👩", "🧑", "👵", "👨"].map((e, i) => (
                  <div key={i} style={{
                    width: 30, height: 30, borderRadius: "50%",
                    background: "rgba(255,255,255,0.15)",
                    border: "2px solid rgba(255,255,255,0.3)",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: "0.875rem", marginLeft: i ? -8 : 0,
                  }}>{e}</div>
                ))}
              </div>
              <div>
                <div style={{ display: "flex", gap: 2, marginBottom: 2 }}>
                  {[1,2,3,4,5].map(s => <Star key={s} size={12} color="#fbbf24" fill="#fbbf24" />)}
                </div>
                <p style={{ color: "rgba(255,255,255,0.6)", fontSize: "0.75rem" }}>
                  Trusted by 10,000+ patients across India
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ─── Problem / Stats ─────────────────────────────────── */}
      <section style={{ padding: "72px 0", background: "var(--cream-50)" }}>
        <div className="container">
          <div style={{ textAlign: "center", marginBottom: 48 }}>
            <div className="t-xs c-muted" style={{ marginBottom: 10 }}>THE PROBLEM WE SOLVE</div>
            <h2 className="t-display-lg" style={{ marginBottom: 14 }}>
              India's healthcare continuity<br /><em>is broken.</em>
            </h2>
            <p className="t-body c-secondary" style={{ maxWidth: 520, margin: "0 auto" }}>
              63 million Indians go bankrupt from healthcare costs every year.
              Not because care is bad — because no one can see the full picture.
            </p>
          </div>

          <div className="grid-4" style={{ gap: 20, marginBottom: 40 }}>
            {[
              { num: "63M",  label: "Indians bankrupt from healthcare each year", color: "var(--red-600)" },
              { num: "54M",  label: "Diabetics — most with scattered, lost records", color: "var(--amber-600)" },
              { num: "₹800", label: "Avg cost of a duplicate lab test (avoidable)", color: "var(--forest-600)" },
              { num: "8min", label: "Doctor time wasted on history intake per visit", color: "#7c3aed" },
            ].map((s) => (
              <div key={s.num} className="card card-pad" style={{ textAlign: "center" }}>
                <div style={{
                  fontFamily: "var(--font-display)", fontSize: "2.2rem", fontWeight: 300,
                  color: s.color, marginBottom: 6,
                }}>{s.num}</div>
                <p className="t-small c-secondary" style={{ lineHeight: 1.6 }}>{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Features ────────────────────────────────────────── */}
      <section style={{ padding: "72px 0" }}>
        <div className="container">
          <div style={{ textAlign: "center", marginBottom: 48 }}>
            <div className="t-xs c-muted" style={{ marginBottom: 10 }}>WHAT WE BUILD</div>
            <h2 className="t-display-lg" style={{ marginBottom: 14 }}>
              Everything your health<br /><em>memory needs.</em>
            </h2>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 }}>
            <FeatureCard
              icon={Upload}
              title="Upload Anything"
              desc="PDF, JPG, WhatsApp forward, voice note. AI extracts all clinical data — in Hindi, Gujarati, English — in 30 seconds."
            />
            <FeatureCard
              icon={TrendingUp}
              title="Living Health Timeline"
              desc="All your reports, prescriptions, visits in one chronological view. Trends detected automatically. HbA1c worsening? You'll know."
              accent
            />
            <FeatureCard
              icon={Stethoscope}
              title="Doctor Brief"
              desc="AI-generated 1-page summary of your health history. Share before consultation. Doctor sees everything. Intake time: 0 minutes."
            />
            <FeatureCard
              icon={Bell}
              title="Smart Alerts"
              desc="WhatsApp and in-app alerts for worsening trends, overdue tests, medication refills. Never miss a critical value again."
            />
            <FeatureCard
              icon={Users}
              title="Family Care"
              desc="Manage your parents, children, spouse from one account. Caregiver in Mumbai can monitor patient in Vadodara in real time."
            />
            <FeatureCard
              icon={Lock}
              title="Private Payments"
              desc="Pay sensitive healthcare providers — therapists, HIV clinics, fertility centres — privately via Solana stealth addresses. Blockchain shows nothing sensitive."
              accent
            />
          </div>
        </div>
      </section>

      {/* ─── How it works ────────────────────────────────────── */}
      <section style={{ padding: "72px 0", background: "var(--cream-50)" }}>
        <div className="container">
          <div style={{ textAlign: "center", marginBottom: 48 }}>
            <div className="t-xs c-muted" style={{ marginBottom: 10 }}>HOW IT WORKS</div>
            <h2 className="t-display-lg">
              Up and running<br /><em>in 3 steps.</em>
            </h2>
          </div>

          <div className="grid-3" style={{ gap: 32 }}>
            {[
              {
                num: "01", title: "Sign up & upload",
                desc: "Register with your phone number. Upload any old reports — WhatsApp photos, PDF files, paper scans. Takes 2 minutes.",
                icon: "📱",
              },
              {
                num: "02", title: "AI extracts everything",
                desc: "Our AI reads every value, every date, every medication. Builds your health timeline automatically. Works in Hindi & Gujarati.",
                icon: "🤖",
              },
              {
                num: "03", title: "Share, monitor, act",
                desc: "Get alerts for critical trends. Share your doctor brief. Monitor family health. Never lose a report again.",
                icon: "✅",
              },
            ].map((step, i) => (
              <div key={i} style={{ textAlign: "center" }}>
                <div style={{
                  width: 72, height: 72, borderRadius: "50%",
                  background: "var(--forest-700)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  margin: "0 auto 20px", fontSize: "1.75rem",
                  boxShadow: "0 4px 20px rgba(13,61,42,0.2)",
                }}>{step.icon}</div>
                <div className="t-xs c-muted" style={{ marginBottom: 6 }}>{step.num}</div>
                <h3 className="t-heading" style={{ marginBottom: 8 }}>{step.title}</h3>
                <p className="t-small c-secondary" style={{ lineHeight: 1.7, maxWidth: 280, margin: "0 auto" }}>
                  {step.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Testimonials ────────────────────────────────────── */}
      <section style={{ padding: "72px 0" }}>
        <div className="container">
          <div style={{ textAlign: "center", marginBottom: 48 }}>
            <div className="t-xs c-muted" style={{ marginBottom: 10 }}>REAL STORIES</div>
            <h2 className="t-display-lg">
              Patients who got<br /><em>their health back.</em>
            </h2>
          </div>

          <div className="grid-3" style={{ gap: 20 }}>
            {[
              {
                quote: "Maine ek saal ke reports ek jagah dekhe pehli baar. HbA1c ka trend dikhaya toh doctor ne turant medicine change ki.",
                name: "Ramesh Patel", role: "T2DM patient, Vadodara", avatar: "👴",
              },
              {
                quote: "My mother's reports were scattered across 3 cities. SwasthAI put everything together. I can now monitor her from Mumbai without panicking.",
                name: "Priya Shah", role: "Caregiver, Mumbai", avatar: "👩‍💼",
              },
              {
                quote: "As a doctor, patients now come prepared. One page brief before consultation. I see the full history in 30 seconds instead of 10 minutes.",
                name: "Dr. Snehal Mehta", role: "General Physician, Vadodara", avatar: "🩺",
              },
            ].map((t, i) => (
              <div key={i} className="card card-pad" style={{ position: "relative" }}>
                <div style={{
                  fontSize: "3rem", lineHeight: 1, color: "var(--forest-100)",
                  fontFamily: "Georgia", position: "absolute", top: 12, left: 16,
                }}>"</div>
                <p className="t-small c-secondary" style={{
                  lineHeight: 1.75, marginBottom: 18, marginTop: 24,
                  fontStyle: "italic",
                }}>{t.quote}</p>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <div style={{
                    width: 36, height: 36, borderRadius: "50%",
                    background: "var(--forest-50)", fontSize: "1.1rem",
                    display: "flex", alignItems: "center", justifyContent: "center",
                  }}>{t.avatar}</div>
                  <div>
                    <div className="t-small font-medium">{t.name}</div>
                    <div className="t-xs c-muted">{t.role}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Pricing ─────────────────────────────────────────── */}
      <section style={{ padding: "72px 0", background: "var(--cream-50)" }}>
        <div className="container">
          <div style={{ textAlign: "center", marginBottom: 48 }}>
            <div className="t-xs c-muted" style={{ marginBottom: 10 }}>PRICING</div>
            <h2 className="t-display-lg" style={{ marginBottom: 12 }}>
              Priced for <em>India.</em>
            </h2>
            <p className="t-body c-secondary">
              Less than one lab test per month. Cancel anytime.
            </p>
          </div>

          <div className="grid-3" style={{ gap: 20, maxWidth: 860, margin: "0 auto" }}>
            <PricingCard
              plan="FREE"
              price="₹0"
              period="forever"
              features={[
                "1 patient profile",
                "10 document uploads",
                "Basic health timeline",
                "AI extraction",
                "2 family members",
              ]}
              cta="Get Started"
            />
            <PricingCard
              plan="FAMILY"
              price="₹299"
              period="/month"
              features={[
                "10 patient profiles",
                "Unlimited uploads",
                "Full health timeline",
                "Doctor brief generator",
                "WhatsApp alerts",
                "Private payments",
                "ABHA integration",
              ]}
              cta="Start Free Trial"
              highlight
            />
            <PricingCard
              plan="CLINIC"
              price="₹5,000"
              period="/month"
              features={[
                "Unlimited patients",
                "Doctor-facing dashboard",
                "Bulk AI extraction",
                "Follow-up automation",
                "WhatsApp reminders",
                "API access",
                "Priority support",
              ]}
              cta="Contact Sales"
            />
          </div>
        </div>
      </section>

      {/* ─── FAQ ─────────────────────────────────────────────── */}
      <section style={{ padding: "72px 0" }}>
        <div className="container container-sm">
          <div style={{ textAlign: "center", marginBottom: 40 }}>
            <h2 className="t-display-lg">Common questions</h2>
          </div>

          {[
            { q: "Is my health data safe?", a: "Yes. All data is stored AES-256 encrypted in Indian data centres. We are ABHA-compliant and DPDP Act 2023 compliant. We never sell your data. You can delete everything at any time." },
            { q: "Does it work for Hindi and Gujarati reports?", a: "Yes — our AI handles Hindi, Gujarati, and English reports. It converts Indic numerals automatically and understands Indian medical terminology." },
            { q: "Can my family members access my records?", a: "Only if you explicitly invite them and grant access. You control exactly who sees what. Family sharing requires consent from all members." },
            { q: "How accurate is the AI extraction?", a: "Typically 95%+ on clear documents. Every extraction can be reviewed and corrected before saving. The AI flags its own confidence level." },
            { q: "What is a private health payment?", a: "A way to pay sensitive healthcare providers (therapists, HIV clinics, fertility centres) on Solana blockchain without revealing the provider or your condition publicly. You get a Viewing Key for insurance reimbursement." },
          ].map((faq, i) => (
            <div key={i} style={{
              borderBottom: "1px solid var(--border)",
              overflow: "hidden",
            }}>
              <button
                onClick={() => setFaqOpen(faqOpen === i ? null : i)}
                style={{
                  width: "100%", display: "flex", justifyContent: "space-between",
                  alignItems: "center", padding: "18px 0", background: "none",
                  border: "none", cursor: "pointer", textAlign: "left",
                  gap: 12,
                }}
              >
                <span className="t-subheading">{faq.q}</span>
                <ChevronDown
                  size={16}
                  color="var(--text-muted)"
                  style={{
                    transform: faqOpen === i ? "rotate(180deg)" : "none",
                    transition: "transform var(--dur-mid)",
                    flexShrink: 0,
                  }}
                />
              </button>
              {faqOpen === i && (
                <p className="t-body c-secondary" style={{ paddingBottom: 18, lineHeight: 1.75 }}>
                  {faq.a}
                </p>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* ─── CTA ─────────────────────────────────────────────── */}
      <section className="hero-gradient" style={{ padding: "72px 0" }}>
        <div className="grain-overlay" />
        <div className="container" style={{ textAlign: "center", position: "relative", zIndex: 1 }}>
          <div style={{
            width: 56, height: 56, borderRadius: "50%",
            background: "rgba(255,255,255,0.1)",
            display: "flex", alignItems: "center", justifyContent: "center",
            margin: "0 auto 20px",
          }}>
            <Heart size={24} color="white" />
          </div>
          <h2 className="t-display-lg" style={{ color: "white", marginBottom: 16 }}>
            Your health history<br /><em style={{ color: "#4ade80" }}>deserves to be remembered.</em>
          </h2>
          <p className="t-body" style={{ color: "rgba(255,255,255,0.65)", marginBottom: 32, maxWidth: 480, margin: "0 auto 32px" }}>
            Join 10,000+ patients who never lose a report, never repeat a test, and walk into every consultation prepared.
          </p>
          <Link href="/dashboard" className="btn btn-lg" style={{
            background: "white", color: "var(--forest-800)", fontWeight: 600, gap: 8,
          }}>
            Start Free Today <ArrowRight size={16} />
          </Link>
        </div>
      </section>

      {/* ─── Footer ──────────────────────────────────────────── */}
      <footer style={{
        borderTop: "1px solid var(--border)",
        padding: "40px 0 24px",
        background: "var(--bg-surface)",
      }}>
        <div className="container">
          <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr", gap: 32, marginBottom: 40 }}>
            <div>
              <div style={{
                fontFamily: "var(--font-display)", fontSize: "1.25rem",
                color: "var(--text-primary)", marginBottom: 10,
              }}>Swasth<em>AI</em></div>
              <p className="t-small c-muted" style={{ lineHeight: 1.7, maxWidth: 260 }}>
                India's AI-powered health memory. Apni health, apne haath.
              </p>
              <div className="trust-bar" style={{ marginTop: 16 }}>
                <div className="trust-item"><Shield size={11} /><span>Encrypted</span></div>
                <div className="trust-item"><CheckCircle2 size={11} /><span>ABHA-linked</span></div>
              </div>
            </div>
            {[
              { title: "Product", links: ["Dashboard", "Timeline", "Upload", "Doctor Brief", "Private Payments"] },
              { title: "Company", links: ["About", "Blog", "Careers", "Press", "Contact"] },
              { title: "Legal", links: ["Privacy Policy", "Terms", "DPDP Compliance", "Security", "Cookie Policy"] },
            ].map((col) => (
              <div key={col.title}>
                <div className="t-xs c-muted" style={{ marginBottom: 14 }}>{col.title}</div>
                {col.links.map((link) => (
                  <div key={link} style={{ marginBottom: 10 }}>
                    <a href="#" className="t-small c-secondary" style={{ textDecoration: "none" }}
                      onMouseEnter={e => (e.currentTarget.style.color = "var(--forest-600)")}
                      onMouseLeave={e => (e.currentTarget.style.color = "")}
                    >{link}</a>
                  </div>
                ))}
              </div>
            ))}
          </div>
          <div className="divider" />
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12 }}>
            <p className="t-xs c-muted">© 2025 SwasthAI. Made with ♥ in India.</p>
            <p className="t-xs c-muted">ABHA-compliant · DPDP Act 2023 · Data stored in India</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
