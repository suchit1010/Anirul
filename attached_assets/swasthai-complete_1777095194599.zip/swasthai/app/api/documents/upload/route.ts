// app/api/documents/upload/route.ts
// Real document upload: validates → R2 → Claude AI extraction → Supabase
import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { uploadDocument } from "@/lib/storage/r2";
import { extractClinicalData } from "@/lib/ai/extraction";
import { notifyExtractionComplete } from "@/lib/notifications/twilio";

const MAX_SIZE_BYTES = 10 * 1024 * 1024; // 10MB
const ALLOWED_TYPES = [
  "application/pdf",
  "image/jpeg", "image/jpg", "image/png", "image/webp",
];

export async function POST(req: Request) {
  try {
    // Auth
    const supabase = await createClient();
    const { data: { user }, error: authErr } = await supabase.auth.getUser();
    if (authErr || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Parse multipart form
    const formData = await req.formData();
    const file = formData.get("file") as File | null;
    const workspaceId = formData.get("workspaceId") as string | null;

    if (!file) return NextResponse.json({ error: "No file provided" }, { status: 400 });
    if (!workspaceId) return NextResponse.json({ error: "workspaceId required" }, { status: 400 });

    // Validate ownership
    const { data: workspace, error: wsErr } = await supabase
      .from("workspaces")
      .select("id, owner_id")
      .eq("id", workspaceId)
      .eq("owner_id", user.id)
      .single();
    if (wsErr || !workspace) {
      return NextResponse.json({ error: "Workspace not found" }, { status: 404 });
    }

    // Validate file
    if (file.size > MAX_SIZE_BYTES) {
      return NextResponse.json({ error: "File exceeds 10MB limit" }, { status: 413 });
    }
    if (!ALLOWED_TYPES.includes(file.type)) {
      return NextResponse.json({ error: `Unsupported type: ${file.type}` }, { status: 415 });
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    const documentId = crypto.randomUUID();

    // 1. Create DB record
    const { data: doc, error: docErr } = await supabase
      .from("documents")
      .insert({
        id: documentId,
        workspace_id: workspaceId,
        uploaded_by: user.id,
        file_name: file.name,
        mime_type: file.type,
        size_bytes: file.size,
        status: "uploaded",
        source: "upload",
      })
      .select()
      .single();
    if (docErr) throw new Error(`DB insert failed: ${docErr.message}`);

    // 2. Upload to R2
    const { storageKey } = await uploadDocument({
      workspaceId,
      documentId,
      fileName: file.name,
      buffer,
      mimeType: file.type,
    });

    // 3. Update DB with storage key
    await supabase.from("documents")
      .update({ storage_key: storageKey, status: "processing" })
      .eq("id", documentId);

    // 4. AI extraction (async — return early for large files)
    // For hackathon demo: run synchronously; production: use BullMQ queue
    let extractionResult = null;
    try {
      extractionResult = await extractClinicalData(file.type, buffer);

      // 5. Persist extraction results
      await supabase.from("documents").update({
        status: "processed",
        extracted_text: extractionResult.rawText ?? "",
        extracted_data: extractionResult as unknown as Record<string, unknown>,
        document_type: extractionResult.documentType,
        ai_confidence: extractionResult.confidence,
        document_date: extractionResult.documentDate ?? null,
      }).eq("id", documentId);

      // 6. Save normalised lab values
      if (extractionResult.labValues.length > 0) {
        await supabase.from("lab_values").insert(
          extractionResult.labValues.map((lv) => ({
            workspace_id: workspaceId,
            document_id: documentId,
            lab_name: lv.name,
            value: lv.value,
            unit: lv.unit,
            status: lv.status,
            reference_min: lv.referenceMin ?? null,
            reference_max: lv.referenceMax ?? null,
            reference_text: lv.referenceRange ?? null,
            observed_at: lv.date
              ? new Date(lv.date).toISOString()
              : new Date().toISOString(),
            lab_facility: lv.lab ?? null,
          }))
        );
      }

      // 7. Save medications
      if (extractionResult.medications.length > 0) {
        await supabase.from("medications").insert(
          extractionResult.medications.map((m) => ({
            workspace_id: workspaceId,
            document_id: documentId,
            name: m.name,
            dose: m.dose ?? null,
            frequency: m.frequency ?? null,
            route: m.route ?? "oral",
            prescribed_by: m.prescribedBy ?? null,
            start_date: m.startDate ?? null,
            is_active: true,
          }))
        );
      }

      // 8. Create critical alerts for high/critical lab values
      const criticals = extractionResult.labValues.filter(
        (lv) => lv.status === "critical" || lv.status === "high"
      );
      if (criticals.length > 0) {
        await supabase.from("alerts").insert(
          criticals.slice(0, 3).map((lv) => ({
            workspace_id: workspaceId,
            severity: lv.status === "critical" ? "critical" : "warning",
            title: `${lv.name} ${lv.status === "critical" ? "critical" : "elevated"}`,
            description: `${lv.name} is ${lv.value} ${lv.unit} — ${lv.status === "critical" ? "requires immediate attention" : "above normal range"}. Reference: ${lv.referenceRange ?? "N/A"}`,
            action: "Review with your doctor",
            source: "ai",
          }))
        );
      }

      // 9. WhatsApp notification
      const { data: profile } = await supabase
        .from("profiles")
        .select("phone, full_name, whatsapp_opt")
        .eq("id", user.id)
        .single();

      if (profile?.phone && profile.whatsapp_opt) {
        await notifyExtractionComplete({
          phone: profile.phone,
          patientName: profile.full_name ?? "there",
          labCount: extractionResult.labValues.length,
          medCount: extractionResult.medications.length,
          appUrl: process.env.NEXT_PUBLIC_APP_URL ?? "https://swasthai.health",
        }).catch((e) => console.warn("[upload] WhatsApp notify failed:", e));
      }

    } catch (extractionErr) {
      console.error("[upload] Extraction failed:", extractionErr);
      await supabase.from("documents")
        .update({ status: "failed" })
        .eq("id", documentId);
    }

    return NextResponse.json({
      success: true,
      documentId,
      storageKey,
      extraction: extractionResult
        ? {
            labCount: extractionResult.labValues.length,
            medCount: extractionResult.medications.length,
            diagnosisCount: extractionResult.diagnoses.length,
            documentType: extractionResult.documentType,
            confidence: extractionResult.confidence,
            language: extractionResult.language,
            labValues: extractionResult.labValues,
            medications: extractionResult.medications,
            diagnoses: extractionResult.diagnoses,
            followUpInstructions: extractionResult.followUpInstructions,
          }
        : null,
    });

  } catch (err) {
    console.error("[upload] Fatal error:", err);
    return NextResponse.json(
      { error: "Upload failed. Please try again." },
      { status: 500 }
    );
  }
}
