// app/api/notifications/send/route.ts
// Internal API for sending WhatsApp notifications
// Called by workers and other API routes

import { NextResponse } from "next/server";
import { z } from "zod";
import {
  notifyCriticalAlert,
  notifyCareReminder,
  notifyBriefShared,
} from "@/lib/notifications/twilio";

const schema = z.discriminatedUnion("type", [
  z.object({
    type: z.literal("critical_alert"),
    phone: z.string(),
    patientName: z.string(),
    alertTitle: z.string(),
    description: z.string(),
    appUrl: z.string(),
  }),
  z.object({
    type: z.literal("care_reminder"),
    phone: z.string(),
    patientName: z.string(),
    taskTitle: z.string(),
    dueDate: z.string(),
    priority: z.string(),
    appUrl: z.string(),
  }),
  z.object({
    type: z.literal("brief_shared"),
    doctorPhone: z.string(),
    patientName: z.string(),
    briefUrl: z.string(),
  }),
]);

// Internal auth — callers must provide a shared secret header
function isAuthorized(req: Request): boolean {
  const secret = req.headers.get("x-internal-secret");
  return secret === process.env.INTERNAL_API_SECRET;
}

export async function POST(req: Request) {
  if (!isAuthorized(req)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = schema.parse(await req.json());

    switch (body.type) {
      case "critical_alert":
        await notifyCriticalAlert(body);
        break;
      case "care_reminder":
        await notifyCareReminder(body);
        break;
      case "brief_shared":
        await notifyBriefShared(body);
        break;
    }

    return NextResponse.json({ sent: true });

  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
    }
    console.error("[notifications/send]", err);
    return NextResponse.json({ error: "Notification failed" }, { status: 500 });
  }
}
