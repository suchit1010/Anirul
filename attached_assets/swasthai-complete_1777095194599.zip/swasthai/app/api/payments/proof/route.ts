// app/api/payments/proof/route.ts
// Generates redacted insurance proof using viewing key
// Reveals: amount + "Healthcare Service" only — never provider or condition

import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { generateInsuranceProof } from "@/lib/blockchain/solana";

const schema = z.object({
  paymentId: z.string().uuid(),
  viewingKey: z.string().min(10),
});

export async function POST(req: Request) {
  try {
    const supabase = await createClient();
    const { data: { user }, error: authErr } = await supabase.auth.getUser();
    if (authErr || !user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { paymentId, viewingKey } = schema.parse(await req.json());

    const { data: payment } = await supabase
      .from("private_payments")
      .select("*")
      .eq("id", paymentId)
      .single();

    if (!payment) return NextResponse.json({ error: "Payment not found" }, { status: 404 });
    if (payment.status !== "confirmed") {
      return NextResponse.json({ error: "Payment not yet confirmed" }, { status: 422 });
    }

    const proof = generateInsuranceProof({
      paymentId,
      viewingKey,
      viewingKeyHash: payment.viewing_key_hash,
      amountInr: payment.amount_inr,
      category: payment.category,
      txSignature: payment.tx_signature,
      confirmedAt: payment.confirmed_at,
    });

    return NextResponse.json({
      proof,
      message: "Insurance proof generated. This document reveals only amount, date, and generic category.",
    });

  } catch (err) {
    if (err instanceof Error && err.message.includes("Invalid viewing key")) {
      return NextResponse.json({ error: "Invalid viewing key" }, { status: 401 });
    }
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: "Invalid input" }, { status: 400 });
    }
    console.error("[payments/proof]", err);
    return NextResponse.json({ error: "Proof generation failed" }, { status: 500 });
  }
}
