// app/api/payments/initiate/route.ts
// Generates stealth address for private healthcare payment
// NOTHING sensitive goes on-chain — only anonymous SOL transfer

import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { initiatePrivatePayment, CATEGORY_MAP } from "@/lib/blockchain/solana";

const schema = z.object({
  workspaceId: z.string().uuid(),
  providerWalletAddress: z.string().min(32).max(44),
  amountInr: z.number().positive(),
  amountSol: z.number().positive(),
  category: z.enum([
    "mental_health", "reproductive_health", "addiction_treatment",
    "general", "lab", "pharmacy", "imaging", "surgery", "emergency",
  ]),
  providerName: z.string().optional(), // stored encrypted, never on-chain
});

export async function POST(req: Request) {
  try {
    const supabase = await createClient();
    const { data: { user }, error: authErr } = await supabase.auth.getUser();
    if (authErr || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const parsed = schema.parse(body);

    // Verify workspace ownership
    const { data: workspace } = await supabase
      .from("workspaces")
      .select("id")
      .eq("id", parsed.workspaceId)
      .eq("owner_id", user.id)
      .single();
    if (!workspace) {
      return NextResponse.json({ error: "Workspace not found" }, { status: 404 });
    }

    const paymentId = crypto.randomUUID();

    // Generate stealth address via ECDH
    const initiation = await initiatePrivatePayment({
      paymentId,
      providerWalletAddress: parsed.providerWalletAddress,
      amountSol: parsed.amountSol,
      category: parsed.category,
    });

    // Store in DB — viewing key NEVER stored, only its hash
    const { error: dbErr } = await supabase.from("private_payments").insert({
      id: paymentId,
      workspace_id: parsed.workspaceId,
      category: parsed.category,
      provider_type: CATEGORY_MAP[parsed.category] ?? "Healthcare Service",
      amount_inr: parsed.amountInr,
      amount_sol: parsed.amountSol,
      stealth_address: initiation.stealthAddress,
      ephemeral_pub_key: initiation.ephemeralPublicKey,
      viewing_key_hash: initiation.viewingKeyHash,
      status: "pending",
    });

    if (dbErr) throw new Error(`DB error: ${dbErr.message}`);

    // Return to client — viewing key sent ONCE, never stored server-side
    return NextResponse.json({
      paymentId,
      stealthAddress: initiation.stealthAddress,
      amountSol: parsed.amountSol,
      amountLamports: initiation.amountLamports,
      viewingKey: initiation.viewingKey,   // CLIENT MUST SAVE THIS
      expiresAt: initiation.expiresAt,
      privacyNote: "Your viewing key has been returned. Store it securely — it is not saved on our servers.",
    });

  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: "Invalid input", details: err.issues }, { status: 400 });
    }
    console.error("[payments/initiate]", err);
    return NextResponse.json({ error: "Payment initiation failed" }, { status: 500 });
  }
}
