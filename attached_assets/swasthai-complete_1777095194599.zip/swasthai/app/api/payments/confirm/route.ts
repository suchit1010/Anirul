// app/api/payments/confirm/route.ts
// Verifies Solana transaction and marks payment confirmed

import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { verifyConsentOnChain } from "@/lib/blockchain/solana";
import { notifyPrivatePaymentConfirmed } from "@/lib/notifications/twilio";

const confirmSchema = z.object({
  paymentId: z.string().uuid(),
  txSignature: z.string().min(44).max(90),
});

export async function POST(req: Request) {
  try {
    const supabase = await createClient();
    const { data: { user }, error: authErr } = await supabase.auth.getUser();
    if (authErr || !user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { paymentId, txSignature } = confirmSchema.parse(await req.json());

    // Fetch payment record
    const { data: payment } = await supabase
      .from("private_payments")
      .select("*, workspaces(owner_id)")
      .eq("id", paymentId)
      .single();

    if (!payment) return NextResponse.json({ error: "Payment not found" }, { status: 404 });

    // Verify on-chain
    const verification = await verifyConsentOnChain(txSignature);
    if (!verification.verified) {
      return NextResponse.json({ error: "Transaction not found on chain" }, { status: 422 });
    }

    // Update DB
    await supabase.from("private_payments").update({
      status: "confirmed",
      tx_signature: txSignature,
      on_chain_hash: txSignature,
      confirmed_at: new Date(
        (verification.blockTime ?? Math.floor(Date.now() / 1000)) * 1000
      ).toISOString(),
    }).eq("id", paymentId);

    // WhatsApp notification
    const { data: profile } = await supabase
      .from("profiles")
      .select("phone, whatsapp_opt")
      .eq("id", user.id)
      .single();

    if (profile?.phone && profile.whatsapp_opt) {
      await notifyPrivatePaymentConfirmed({
        phone: profile.phone,
        amountInr: payment.amount_inr,
        txSig: txSignature,
      }).catch((e) => console.warn("[confirm] WhatsApp notify failed:", e));
    }

    return NextResponse.json({
      confirmed: true,
      txSignature,
      blockTime: verification.blockTime,
      message: "Payment confirmed on Solana. Store your viewing key to claim insurance reimbursement.",
    });

  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: "Invalid input" }, { status: 400 });
    }
    console.error("[payments/confirm]", err);
    return NextResponse.json({ error: "Confirmation failed" }, { status: 500 });
  }
}
