// app/api/consent/route.ts
// Writes consent hash to Solana Memo program
// PHI never touches blockchain — only SHA-256 hash of consent metadata

import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { writeConsentToChain, verifyConsentOnChain } from "@/lib/blockchain/solana";

const createSchema = z.object({
  workspaceId: z.string().uuid(),
  sharedWith: z.string(),
  scope: z.array(z.string()),
  expiresInHours: z.number().min(1).max(168).default(24),
});

// POST: create new consent + write to chain
export async function POST(req: Request) {
  try {
    const supabase = await createClient();
    const { data: { user }, error: authErr } = await supabase.auth.getUser();
    if (authErr || !user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = createSchema.parse(await req.json());
    const consentId = crypto.randomUUID();
    const expiresAt = new Date(Date.now() + body.expiresInHours * 60 * 60 * 1000);

    // Write to Solana
    const { txSignature, consentHash } = await writeConsentToChain({
      consentId,
      workspaceId: body.workspaceId,
      scope: body.scope,
      expiresAt: expiresAt.toISOString(),
    });

    // Persist in DB
    const { error: dbErr } = await supabase.from("consent_receipts").insert({
      id: consentId,
      workspace_id: body.workspaceId,
      shared_with: body.sharedWith,
      scope: body.scope,
      expires_at: expiresAt.toISOString(),
      on_chain_hash: consentHash,
      solana_sig: txSignature,
    });

    if (dbErr) throw new Error(dbErr.message);

    return NextResponse.json({
      consentId,
      txSignature,
      consentHash,
      expiresAt: expiresAt.toISOString(),
      explorerUrl: `https://explorer.solana.com/tx/${txSignature}?cluster=${process.env.NEXT_PUBLIC_SOLANA_NETWORK ?? "devnet"}`,
      message: "Consent written to Solana blockchain. Tamper-evident and cryptographically verifiable.",
    });

  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: "Invalid input" }, { status: 400 });
    }
    console.error("[consent POST]", err);
    return NextResponse.json({ error: "Consent creation failed" }, { status: 500 });
  }
}

// GET: verify consent is still valid on-chain
export async function GET(req: Request) {
  try {
    const supabase = await createClient();
    const { data: { user }, error: authErr } = await supabase.auth.getUser();
    if (authErr || !user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { searchParams } = new URL(req.url);
    const consentId = searchParams.get("consentId");
    if (!consentId) return NextResponse.json({ error: "consentId required" }, { status: 400 });

    const { data: consent } = await supabase
      .from("consent_receipts")
      .select("*")
      .eq("id", consentId)
      .single();

    if (!consent) return NextResponse.json({ error: "Consent not found" }, { status: 404 });

    const onChain = await verifyConsentOnChain(consent.solana_sig);
    const isExpired = consent.expires_at && new Date(consent.expires_at) < new Date();
    const isRevoked = consent.revoked;

    return NextResponse.json({
      consentId,
      valid: onChain.verified && !isExpired && !isRevoked,
      onChainVerified: onChain.verified,
      expired: isExpired,
      revoked: isRevoked,
      expiresAt: consent.expires_at,
      txSignature: consent.solana_sig,
      blockTime: onChain.blockTime,
    });

  } catch (err) {
    console.error("[consent GET]", err);
    return NextResponse.json({ error: "Verification failed" }, { status: 500 });
  }
}
