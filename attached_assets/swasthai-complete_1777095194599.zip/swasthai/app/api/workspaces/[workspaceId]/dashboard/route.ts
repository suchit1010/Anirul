// app/api/workspaces/[workspaceId]/dashboard/route.ts
// Single endpoint for dashboard — all data in one round trip

import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function GET(
  req: Request,
  context: { params: Promise<{ workspaceId: string }> }
) {
  const { workspaceId } = await context.params;
  try {
    const supabase = await createClient();
    const { data: { user }, error: authErr } = await supabase.auth.getUser();
    if (authErr || !user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    // Verify ownership
    const { data: workspace } = await supabase
      .from("workspaces")
      .select("*")
      .eq("id", workspaceId)
      .eq("owner_id", user.id)
      .single();
    if (!workspace) return NextResponse.json({ error: "Not found" }, { status: 404 });

    // Fetch all dashboard data in parallel
    const [
      profileResult,
      latestLabsResult,
      activeMedsResult,
      activeAlertsResult,
      careTasksResult,
      recentDocsResult,
      familyResult,
    ] = await Promise.all([
      supabase.from("profiles").select("*").eq("id", user.id).single(),
      supabase.from("lab_values")
        .select("*")
        .eq("workspace_id", workspaceId)
        .order("observed_at", { ascending: false })
        .limit(8),
      supabase.from("medications")
        .select("*")
        .eq("workspace_id", workspaceId)
        .eq("is_active", true),
      supabase.from("alerts")
        .select("*")
        .eq("workspace_id", workspaceId)
        .eq("dismissed", false)
        .order("created_at", { ascending: false })
        .limit(5),
      supabase.from("care_tasks")
        .select("*")
        .eq("workspace_id", workspaceId)
        .neq("status", "done")
        .order("due_date", { ascending: true })
        .limit(6),
      supabase.from("documents")
        .select("id, file_name, mime_type, status, created_at, document_type, ai_confidence")
        .eq("workspace_id", workspaceId)
        .order("created_at", { ascending: false })
        .limit(5),
      // Other workspaces for family view
      supabase.from("workspaces")
        .select("id, name, relation, health_score")
        .eq("owner_id", user.id)
        .neq("id", workspaceId)
        .limit(5),
    ]);

    // Compute health score (simplified — full logic in risk-scoring.ts)
    const labs = latestLabsResult.data ?? [];
    const alerts = activeAlertsResult.data ?? [];
    const criticalCount = labs.filter((l) => l.status === "critical").length;
    const highCount = labs.filter((l) => l.status === "high").length;
    let healthScore = workspace.health_score ?? 75;
    if (criticalCount > 0) healthScore = Math.min(healthScore, 40);
    else if (highCount > 1) healthScore = Math.min(healthScore, 60);

    // HbA1c trend (last 4 readings)
    const hba1c = labs.filter((l) => l.lab_name.toLowerCase().includes("hba1c"));
    const hba1cTrend = hba1c.length >= 2
      ? hba1c[0].value > hba1c[1].value ? "worsening"
        : hba1c[0].value < hba1c[1].value ? "improving"
        : "stable"
      : "unknown";

    return NextResponse.json({
      workspace: {
        id: workspace.id,
        name: workspace.name,
        healthScore,
        continuity: workspace.continuity,
        documentCount: recentDocsResult.data?.length ?? 0,
      },
      profile: profileResult.data,
      keyLabs: labs.slice(0, 4),
      allLabs: labs,
      activeMedications: activeMedsResult.data ?? [],
      alerts: alerts,
      careTasks: careTasksResult.data ?? [],
      recentDocuments: recentDocsResult.data ?? [],
      familyWorkspaces: familyResult.data ?? [],
      insights: {
        hba1cTrend,
        criticalAlertCount: criticalCount,
        pendingTaskCount: careTasksResult.data?.length ?? 0,
      },
    });

  } catch (err) {
    console.error("[dashboard]", err);
    return NextResponse.json({ error: "Failed to load dashboard" }, { status: 500 });
  }
}
