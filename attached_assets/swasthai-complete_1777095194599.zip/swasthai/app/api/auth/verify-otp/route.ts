// app/api/auth/verify-otp/route.ts
// Verifies OTP and creates Supabase auth session
// Uses Supabase's built-in phone OTP when configured

import { NextResponse } from "next/server";
import { z } from "zod";
import { createServiceClient } from "@/lib/supabase/server";
import crypto from "crypto";

const schema = z.object({
  phone: z.string().min(10),
  otp: z.string().length(6),
  fullName: z.string().optional(),
});

function hashOtp(otp: string, phone: string): string {
  return crypto
    .createHmac("sha256", process.env.TWILIO_AUTH_TOKEN ?? "fallback_secret")
    .update(`${phone}:${otp}`)
    .digest("hex");
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { phone, otp, fullName } = schema.parse(body);

    const normalized = phone.startsWith("+") ? phone : `+91${phone.replace(/\s/g, "")}`;
    const otpHash = hashOtp(otp, normalized);
    const supabase = createServiceClient();

    // Verify OTP hash
    const { data: attempt, error: fetchError } = await supabase
      .from("otp_attempts")
      .select("*")
      .eq("phone", normalized)
      .eq("otp_hash", otpHash)
      .gt("expires_at", new Date().toISOString())
      .single();

    // Dev bypass: accept "000000" in development
    const isDevBypass =
      process.env.NODE_ENV === "development" && otp === "000000";

    if (!isDevBypass && (fetchError || !attempt)) {
      return NextResponse.json(
        { error: "Invalid or expired OTP" },
        { status: 401 }
      );
    }

    // Check attempt limit (max 5 tries)
    if (!isDevBypass && attempt && attempt.attempts >= 5) {
      return NextResponse.json(
        { error: "Too many attempts. Request a new OTP." },
        { status: 429 }
      );
    }

    // Increment attempt counter
    if (!isDevBypass && attempt) {
      await supabase
        .from("otp_attempts")
        .update({ attempts: (attempt.attempts ?? 0) + 1 })
        .eq("phone", normalized);
    }

    // Create or get Supabase user
    // Try to find existing user by phone
    const { data: existingUsers } = await supabase.auth.admin.listUsers();
    const existingUser = existingUsers?.users.find(
      (u: { phone?: string; user_metadata?: Record<string, unknown> }) =>
        u.phone === normalized || u.user_metadata?.phone === normalized
    );

    let userId: string;

    if (existingUser) {
      userId = existingUser.id;
    } else {
      // Create new user
      const { data: newUser, error: createError } = await supabase.auth.admin.createUser({
        phone: normalized,
        phone_confirm: true,
        user_metadata: {
          phone: normalized,
          full_name: fullName ?? "",
        },
      });

      if (createError || !newUser.user) {
        console.error("[verify-otp] Create user error:", createError);
        return NextResponse.json(
          { error: "Failed to create account" },
          { status: 500 }
        );
      }
      userId = newUser.user.id;
    }

    // Create session token
    const { data: session, error: sessionError } =
      await supabase.auth.admin.createSession({ userId });

    if (sessionError || !session) {
      return NextResponse.json(
        { error: "Failed to create session" },
        { status: 500 }
      );
    }

    // Clean up used OTP
    await supabase.from("otp_attempts").delete().eq("phone", normalized);

    return NextResponse.json({
      success: true,
      session: {
        access_token: session.access_token,
        refresh_token: session.refresh_token,
        user: { id: userId, phone: normalized },
      },
    });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: "Invalid input" }, { status: 400 });
    }
    console.error("[verify-otp]", err);
    return NextResponse.json({ error: "Verification failed" }, { status: 500 });
  }
}
