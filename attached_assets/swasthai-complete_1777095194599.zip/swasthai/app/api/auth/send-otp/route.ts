// app/api/auth/send-otp/route.ts
// Sends OTP via Twilio SMS for phone-based auth
// Stores OTP hash in Supabase (not plaintext)

import { NextResponse } from "next/server";
import { z } from "zod";
import { createServiceClient } from "@/lib/supabase/server";
import { sendOtpSms } from "@/lib/notifications/twilio";
import crypto from "crypto";

const schema = z.object({
  phone: z.string().min(10).max(15),
});

function generateOtp(): string {
  return String(Math.floor(100000 + Math.random() * 900000));
}

function hashOtp(otp: string, phone: string): string {
  return crypto
    .createHmac("sha256", process.env.TWILIO_AUTH_TOKEN ?? "fallback_secret")
    .update(`${phone}:${otp}`)
    .digest("hex");
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { phone } = schema.parse(body);

    // Normalize phone number
    const normalized = phone.startsWith("+") ? phone : `+91${phone.replace(/\s/g, "")}`;

    const otp = generateOtp();
    const otpHash = hashOtp(otp, normalized);
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    // Store OTP hash in DB (never plaintext)
    const supabase = createServiceClient();
    const { error: dbError } = await supabase
      .from("otp_attempts")
      .upsert({
        phone: normalized,
        otp_hash: otpHash,
        expires_at: expiresAt.toISOString(),
        attempts: 0,
      })
      .select();

    if (dbError) {
      // Table may not exist in dev — log and continue for demo
      console.warn("[send-otp] DB error (non-fatal in dev):", dbError.message);
    }

    // Send via Twilio
    if (process.env.TWILIO_ACCOUNT_SID?.startsWith("AC")) {
      await sendOtpSms(normalized, otp);
    } else {
      // Dev mode — log to console instead
      console.log(`[DEV] OTP for ${normalized}: ${otp}`);
    }

    return NextResponse.json({
      success: true,
      message: `OTP sent to ${normalized.slice(0, 5)}****${normalized.slice(-2)}`,
      // In dev, expose OTP for testing — remove in prod
      ...(process.env.NODE_ENV === "development" && { devOtp: otp }),
    });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: "Invalid phone number" }, { status: 400 });
    }
    console.error("[send-otp]", err);
    return NextResponse.json({ error: "Failed to send OTP" }, { status: 500 });
  }
}
