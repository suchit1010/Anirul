// app/api/ai/doctor-brief/route.ts
// Generates AI pre-consultation brief using Claude
// Cached for 6 hours per workspace - invalidated on new document upload

import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { generateDoctorBrief, type DoctorBriefResult } from "@/lib/ai/extraction";

const CACHE_TTL_HOURS = 6;

export async function GET(req: Request) {
  try {
    const supabase = await createClient();
    const { data: { user }, error: authErr } = await supabase.auth.getUser();
    if (authErr || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const workspaceId = searchParams.get("workspaceId");
    if (!workspaceId) {
      return NextResponse.json({ error: "workspaceId required" }, { status: 400 });
    }

    // Verify ownership
    const { data: workspace } = await supabase
      .from("workspaces")
      .select("id, owner_id")
      .eq("id", workspaceId)
      .eq("owner_id", user.id)
      .single();
    if (!workspace) {
      return NextResponse.json({ error: "Workspace not found" }, { status: 404 });
    }

    // Check cache
    const cacheThreshold = new Date(Date.now() - CACHE_TTL_HOURS * 60 * 60 * 1000).toISOString();
    const { data: cached } = await supabase
      .from("doctor_briefs")
      .select("*")
      .eq("workspace_id", workspaceId)
      .gte("generated_at", cacheThreshold)
      .single();

    if (cached) {
      return NextResponse.json({
        ...(cached.brief_data as object),
        cached: true,
        cachedAt: cached.generated_at,
      });
    }

    // Gather context for AI
    const [profileResult, labsResult, medsResult, alertsResult, docsResult] =
      await Promise.all([
        supabase.from("profiles").select("full_name, age, gender, conditions").eq("id", user.id).single(),
        supabase.from("lab_values").select("*").eq("workspace_id", workspaceId).order("observed_at", { ascending: false }).limit(50),
        supabase.from("medications").select("*").eq("workspace_id", workspaceId).eq("is_active", true),
        supabase.from("alerts").select("*").eq("workspace_id", workspaceId).eq("dismissed", false).order("created_at", { ascending: false }).limit(10),
        supabase.from("documents").select("id").eq("workspace_id", workspaceId).eq("status", "processed"),
      ]);

    const profile = profileResult.data;
    const labs = labsResult.data ?? [];
    const meds = medsResult.data ?? [];
    const alerts = alertsResult.data ?? [];
    const docCount = docsResult.data?.length ?? 0;

    // Generate with Claude
    const brief = await generateDoctorBrief({
      patientName: profile?.full_name ?? "Patient",
      age: profile?.age ?? 0,
      gender: profile?.gender ?? "Unknown",
      conditions: profile?.conditions ?? [],
      labValues: labs.map((l) => ({
        name: l.lab_name,
        value: Number(l.value),
        unit: l.unit ?? "",
        status: l.status ?? "normal",
        date: l.observed_at?.split("T")[0] ?? "",
      })),
      medications: meds.map((m) => ({
        name: m.name,
        dose: m.dose ?? undefined,
        frequency: m.frequency ?? undefined,
      })),
      alerts: alerts.map((a) => ({
        severity: a.severity,
        title: a.title,
      })),
      documentCount: docCount,
    });

    // Cache result
    await supabase.from("doctor_briefs").upsert({
      workspace_id: workspaceId,
      brief_data: brief as unknown as Record<string, unknown>,
      generated_at: new Date().toISOString(),
    });

    return NextResponse.json({ ...brief, cached: false });

  } catch (err) {
    console.error("[doctor-brief]", err);
    return NextResponse.json({ error: "Brief generation failed" }, { status: 500 });
  }
}

// POST: force regenerate (invalidate cache)
export async function POST(req: Request) {
  try {
    const supabase = await createClient();
    const { data: { user }, error: authErr } = await supabase.auth.getUser();
    if (authErr || !user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { workspaceId } = await req.json();

    // Delete cached brief to force regeneration
    await supabase.from("doctor_briefs").delete().eq("workspace_id", workspaceId);

    // Redirect to GET for fresh generation
    const url = new URL(req.url);
    url.pathname = url.pathname.replace("/ai/doctor-brief", "/ai/doctor-brief");
    url.searchParams.set("workspaceId", workspaceId);

    return NextResponse.redirect(url, 307);
  } catch (err) {
    return NextResponse.json({ error: "Failed to regenerate" }, { status: 500 });
  }
}
