// app/api/ai/symptom-check/route.ts
// Hindi + English symptom checker using Claude
// Context-aware: includes patient conditions and medications
// NEVER diagnoses — always defers to doctor

import { NextResponse } from "next/server";
import { z } from "zod";
import Anthropic from "@anthropic-ai/sdk";
import { createClient } from "@/lib/supabase/server";

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY! });

const schema = z.object({
  workspaceId: z.string().uuid(),
  symptom: z.string().min(3).max(1000),
  language: z.enum(["hindi", "english", "auto"]).default("auto"),
});

const SYSTEM_PROMPT = `You are SwasthAI's health information assistant — a trusted, caring guide for Indian patients.

STRICT RULES:
1. NEVER provide a medical diagnosis.
2. NEVER replace professional medical advice.
3. ALWAYS end with: "Please consult your doctor if symptoms persist or worsen."
4. Respond in the SAME LANGUAGE the patient used (Hindi → Hindi, English → English, mixed → mixed).
5. Be warm, clear, simple. Not clinical. Like a knowledgeable friend.
6. Keep responses SHORT (under 150 words). Patients are usually on mobile.

STRUCTURE your response as:
- What this might be about (1-2 possibilities, not diagnoses)
- When to see a doctor urgently (red flags)
- What to monitor at home
- Close with: [in patient's language] "Please consult your doctor if these symptoms continue."`;

export async function POST(req: Request) {
  try {
    const supabase = await createClient();
    const { data: { user }, error: authErr } = await supabase.auth.getUser();
    if (authErr || !user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { workspaceId, symptom } = schema.parse(await req.json());

    // Get patient context for personalized response
    const [profileResult, labsResult, medsResult] = await Promise.all([
      supabase.from("profiles").select("age, gender, conditions").eq("id", user.id).single(),
      supabase.from("lab_values")
        .select("lab_name, value, unit, status")
        .eq("workspace_id", workspaceId)
        .order("observed_at", { ascending: false })
        .limit(10),
      supabase.from("medications")
        .select("name, dose, frequency")
        .eq("workspace_id", workspaceId)
        .eq("is_active", true),
    ]);

    const profile = profileResult.data;
    const labs = labsResult.data ?? [];
    const meds = medsResult.data ?? [];

    const contextBlock = `
PATIENT CONTEXT (use this to personalize your response):
- Age: ${profile?.age ?? "unknown"}, Gender: ${profile?.gender ?? "unknown"}
- Known conditions: ${profile?.conditions?.join(", ") || "none recorded"}
- Current medications: ${meds.map((m) => `${m.name} ${m.dose ?? ""}`).join(", ") || "none"}
- Recent lab flags: ${labs.filter((l) => l.status !== "normal").map((l) => `${l.lab_name} ${l.value} ${l.unit} (${l.status})`).join(", ") || "none"}

Patient's symptom: "${symptom}"`;

    const message = await anthropic.messages.create({
      model: "claude-opus-4-5",
      max_tokens: 400,
      system: SYSTEM_PROMPT,
      messages: [{ role: "user", content: contextBlock }],
    });

    const response = (message.content[0] as { text: string }).text;

    // Log for safety audit (no PHI in logs)
    console.log(`[symptom-check] workspace:${workspaceId} symptom_length:${symptom.length}`);

    return NextResponse.json({
      response,
      disclaimer: "This is health information only — not a medical diagnosis. Always consult your doctor.",
      model: "claude-opus-4-5",
    });

  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: "Invalid input" }, { status: 400 });
    }
    console.error("[symptom-check]", err);
    return NextResponse.json({ error: "Failed to process symptom" }, { status: 500 });
  }
}
