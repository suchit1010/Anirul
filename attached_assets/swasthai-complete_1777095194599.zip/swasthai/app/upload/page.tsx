"use client";
import { useState, useRef, useCallback } from "react";
import { Upload, Camera, MessageCircle, FileText, CheckCircle2, Loader2, X, AlertCircle, FlaskConical, Pill } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { MOCK_DOCUMENTS } from "@/lib/mock-data";

type UploadState = "idle" | "uploading" | "extracting" | "done" | "error";

type ExtractionResult = {
  labValues: { name: string; value: string; status: "high" | "normal" | "low" }[];
  medications: string[];
  documentType: string;
  date: string;
  lab: string;
  confidence: number;
};

const FAKE_RESULT: ExtractionResult = {
  labValues: [
    { name: "HbA1c", value: "8.9%", status: "high" },
    { name: "Fasting Glucose", value: "186 mg/dL", status: "high" },
    { name: "Total Cholesterol", value: "218 mg/dL", status: "high" },
    { name: "Creatinine", value: "1.2 mg/dL", status: "normal" },
    { name: "Haemoglobin", value: "13.4 g/dL", status: "normal" },
  ],
  medications: ["Metformin 500mg", "Telmisartan 40mg"],
  documentType: "Lab Report",
  date: "15 Jan 2025",
  lab: "Dr Lal PathLabs, Vadodara",
  confidence: 0.96,
};

const STEPS = [
  "Reading document structure…",
  "Identifying lab values and units…",
  "Extracting dates and lab names…",
  "Checking reference ranges (ICMR)…",
  "Detecting medications and doses…",
  "Analysing trends against history…",
];

function UploadChannel({
  icon: Icon, label, sub, onClick, accent = false,
}: {
  icon: React.ElementType; label: string; sub: string;
  onClick: () => void; accent?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className="card"
      style={{
        padding: "20px 16px", textAlign: "center",
        background: accent ? "var(--forest-700)" : "var(--bg-surface)",
        border: accent ? "none" : "1px solid var(--border)",
        cursor: "pointer",
        transition: "all var(--dur-mid) var(--ease-out)",
        width: "100%",
      }}
      onMouseEnter={e => {
        (e.currentTarget as HTMLButtonElement).style.transform = "translateY(-3px)";
        (e.currentTarget as HTMLButtonElement).style.boxShadow = "var(--shadow-lg)";
      }}
      onMouseLeave={e => {
        (e.currentTarget as HTMLButtonElement).style.transform = "none";
        (e.currentTarget as HTMLButtonElement).style.boxShadow = "var(--shadow-sm)";
      }}
    >
      <div style={{
        width: 48, height: 48, borderRadius: "var(--r-md)",
        background: accent ? "rgba(255,255,255,0.12)" : "var(--forest-50)",
        display: "flex", alignItems: "center", justifyContent: "center",
        margin: "0 auto 12px",
      }}>
        <Icon size={22} color={accent ? "white" : "var(--forest-600)"} />
      </div>
      <div className="t-subheading" style={{ color: accent ? "white" : "var(--text-primary)", marginBottom: 4 }}>
        {label}
      </div>
      <div className="t-xs" style={{ color: accent ? "rgba(255,255,255,0.6)" : "var(--text-muted)" }}>
        {sub}
      </div>
    </button>
  );
}

export default function UploadPage() {
  const [state, setState] = useState<UploadState>("idle");
  const [progress, setProgress] = useState(0);
  const [step, setStep] = useState(0);
  const [fileName, setFileName] = useState("");
  const [dragOver, setDragOver] = useState(false);
  const [result, setResult] = useState<ExtractionResult | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const runExtraction = useCallback(async (name: string) => {
    setFileName(name);
    setState("uploading");
    setProgress(0);

    // Simulate upload
    for (let i = 0; i <= 100; i += 5) {
      await new Promise((r) => setTimeout(r, 30));
      setProgress(i);
    }

    setState("extracting");
    setProgress(0);
    for (let i = 0; i < STEPS.length; i++) {
      setStep(i);
      await new Promise((r) => setTimeout(r, 500 + Math.random() * 300));
      setProgress(Math.round(((i + 1) / STEPS.length) * 100));
    }

    setState("done");
    setResult(FAKE_RESULT);
  }, []);

  const handleFile = useCallback((file: File) => {
    runExtraction(file.name);
  }, [runExtraction]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  }, [handleFile]);

  const reset = () => {
    setState("idle");
    setProgress(0);
    setResult(null);
    setFileName("");
  };

  return (
    <AppShell>
      {/* Header */}
      <div className="anim-fade-up" style={{ marginBottom: 28 }}>
        <div className="t-xs c-muted" style={{ marginBottom: 4 }}>Add to your health memory</div>
        <h1 className="t-display-md">Upload <em>Health Record</em></h1>
        <p className="t-small c-secondary" style={{ marginTop: 4 }}>
          AI extracts all clinical data in seconds. Supports Hindi, Gujarati, and English reports.
        </p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: 24, alignItems: "start" }}>
        {/* Main upload area */}
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>

          {/* Upload channels */}
          {state === "idle" && (
            <div className="anim-fade-up delay-1">
              <div className="grid-4" style={{ marginBottom: 20 }}>
                <UploadChannel icon={Upload}         label="Upload File" sub="PDF or image" onClick={() => fileRef.current?.click()} />
                <UploadChannel icon={Camera}         label="Take Photo" sub="Camera on phone" onClick={() => fileRef.current?.click()} />
                <UploadChannel icon={MessageCircle}  label="WhatsApp" sub="Forward report" onClick={() => {}} accent />
                <UploadChannel icon={FileText}       label="Paste Text" sub="Type or paste" onClick={() => {}} />
              </div>
              <input ref={fileRef} type="file" accept="image/*,application/pdf" style={{ display: "none" }}
                onChange={e => { const f = e.target.files?.[0]; if (f) handleFile(f); }}
              />

              {/* Drop zone */}
              <div
                className={`upload-zone ${dragOver ? "drag-over" : ""}`}
                onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                onDragLeave={() => setDragOver(false)}
                onDrop={handleDrop}
                onClick={() => fileRef.current?.click()}
              >
                <div className="upload-icon-ring">
                  <Upload size={28} />
                </div>
                <h3 className="t-heading" style={{ marginBottom: 6, color: "var(--forest-700)" }}>
                  Drop your report here
                </h3>
                <p className="t-small c-muted" style={{ marginBottom: 16 }}>
                  or click to browse files on your device
                </p>
                <div style={{ display: "flex", justifyContent: "center", gap: 8, flexWrap: "wrap" }}>
                  {["📄 PDF", "📷 JPG / PNG", "🗂 WEBP", "💬 WhatsApp image"].map((t) => (
                    <span key={t} className="badge badge-gray" style={{ fontSize: "0.75rem" }}>{t}</span>
                  ))}
                </div>
                <p className="t-xs c-muted" style={{ marginTop: 16 }}>
                  Hindi, Gujarati, English reports supported · Max 10MB
                </p>
              </div>
            </div>
          )}

          {/* Upload + Extraction progress */}
          {(state === "uploading" || state === "extracting") && (
            <div className="card card-pad anim-scale-in">
              <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20 }}>
                <div style={{
                  width: 40, height: 40, background: "var(--forest-50)",
                  borderRadius: "var(--r-sm)", display: "flex", alignItems: "center", justifyContent: "center",
                }}>
                  <FileText size={18} color="var(--forest-600)" />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="t-subheading truncate">{fileName}</div>
                  <div className="t-xs c-muted">
                    {state === "uploading" ? "Uploading securely…" : "AI extracting clinical data…"}
                  </div>
                </div>
                <Loader2 size={18} color="var(--forest-500)" style={{ animation: "spin 1s linear infinite" }} />
              </div>

              <div className="progress-bar" style={{ marginBottom: 8, height: 6 }}>
                <div className="progress-fill" style={{ width: `${progress}%` }} />
              </div>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span className="t-xs c-muted">
                  {state === "extracting" ? STEPS[step] : "Uploading to encrypted storage…"}
                </span>
                <span className="t-xs c-forest" style={{ fontFamily: "var(--font-display)" }}>{progress}%</span>
              </div>

              {state === "extracting" && (
                <div style={{ marginTop: 20 }}>
                  {STEPS.map((s, i) => (
                    <div key={i} style={{
                      display: "flex", alignItems: "center", gap: 8,
                      padding: "6px 0", opacity: i <= step ? 1 : 0.3,
                      transition: "opacity var(--dur-mid)",
                    }}>
                      {i < step
                        ? <CheckCircle2 size={14} color="var(--forest-500)" />
                        : i === step
                          ? <Loader2 size={14} color="var(--forest-500)" style={{ animation: "spin 1s linear infinite" }} />
                          : <div style={{ width: 14, height: 14, borderRadius: "50%", border: "1.5px solid var(--border-mid)" }} />
                      }
                      <span className="t-small" style={{ color: i <= step ? "var(--text-primary)" : "var(--text-muted)" }}>
                        {s}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Results */}
          {state === "done" && result && (
            <div className="anim-scale-in">
              {/* Success header */}
              <div className="alert-strip alert-strip-info" style={{ marginBottom: 16, borderLeft: "3px solid var(--forest-400)" }}>
                <CheckCircle2 size={16} color="var(--forest-500)" />
                <div style={{ flex: 1 }}>
                  <div className="t-subheading">Extracted successfully</div>
                  <div className="t-small c-secondary">
                    {fileName} · {result.documentType} · {result.lab} · {result.date}
                  </div>
                  <div className="t-xs" style={{ color: "var(--forest-600)", marginTop: 4 }}>
                    AI confidence: {(result.confidence * 100).toFixed(0)}%
                  </div>
                </div>
                <button onClick={reset} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--text-muted)" }}>
                  <X size={14} />
                </button>
              </div>

              {/* Lab values extracted */}
              <div className="card card-pad" style={{ marginBottom: 16 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
                  <FlaskConical size={16} color="var(--forest-600)" />
                  <h3 className="t-heading">Lab Values Extracted</h3>
                  <span className="badge badge-green">{result.labValues.length} found</span>
                </div>
                <div className="grid-2">
                  {result.labValues.map((lab, i) => (
                    <div key={i} style={{
                      padding: "10px 12px", background: "var(--bg-subtle)",
                      borderRadius: "var(--r-md)", border: "1px solid var(--border)",
                    }}>
                      <div className="t-xs c-muted" style={{ marginBottom: 3 }}>{lab.name}</div>
                      <div style={{
                        fontFamily: "var(--font-display)", fontSize: "1.25rem",
                        color: lab.status === "high" ? "var(--amber-600)"
                          : lab.status === "low" ? "#2563eb" : "var(--text-primary)",
                      }}>
                        {lab.value}
                      </div>
                      <span className={`badge ${
                        lab.status === "high" ? "badge-amber"
                        : lab.status === "low" ? "" : "badge-green"
                      }`} style={{ marginTop: 4, fontSize: "0.625rem" }}>
                        {lab.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Medications */}
              {result.medications.length > 0 && (
                <div className="card card-pad" style={{ marginBottom: 16 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
                    <Pill size={16} color="var(--forest-600)" />
                    <h3 className="t-heading">Medications Found</h3>
                  </div>
                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                    {result.medications.map((m, i) => (
                      <span key={i} className="badge badge-green">{m}</span>
                    ))}
                  </div>
                </div>
              )}

              {/* Correction prompt */}
              <div style={{
                background: "var(--amber-50)", border: "1px solid #fcd34d",
                borderRadius: "var(--r-lg)", padding: "14px 16px",
                display: "flex", gap: 10,
              }}>
                <AlertCircle size={16} color="var(--amber-600)" style={{ flexShrink: 0, marginTop: 1 }} />
                <div>
                  <div className="t-small font-medium" style={{ color: "var(--amber-700)", marginBottom: 3 }}>
                    Review extracted data
                  </div>
                  <div className="t-small c-secondary">
                    AI extraction can make mistakes. Please review and correct any values before saving.
                  </div>
                </div>
              </div>

              <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
                <button className="btn btn-primary" style={{ flex: 1, gap: 8 }}>
                  <CheckCircle2 size={15} /> Save to Timeline
                </button>
                <button onClick={reset} className="btn btn-ghost" style={{ gap: 8 }}>
                  <X size={15} /> Discard
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right: Upload history + tips */}
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div className="card card-pad anim-fade-up delay-1">
            <h3 className="t-heading" style={{ marginBottom: 14 }}>Recent Uploads</h3>
            {MOCK_DOCUMENTS.map((doc, i) => (
              <div key={doc.id} style={{
                display: "flex", alignItems: "center", gap: 10,
                padding: "9px 0",
                borderBottom: i < MOCK_DOCUMENTS.length - 1 ? "1px solid var(--border)" : "none",
              }}>
                <div style={{ fontSize: "1.1rem" }}>
                  {doc.source === "camera" ? "📷" : doc.source === "whatsapp" ? "💬" : "📄"}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="t-small font-medium truncate">{doc.name}</div>
                  <div className="t-xs c-muted">{doc.uploadedAt}</div>
                </div>
                <span className="badge badge-green" style={{ fontSize: "0.625rem" }}>✓</span>
              </div>
            ))}
          </div>

          {/* Tips */}
          <div className="card card-pad" style={{ background: "var(--forest-25)", borderColor: "var(--forest-100)" }}>
            <h3 className="t-subheading c-forest" style={{ marginBottom: 10 }}>📋 Tips for best results</h3>
            {[
              "Ensure the full report is visible, not cut off",
              "Good lighting — avoid shadows over text",
              "Hindi and Gujarati reports work perfectly",
              "WhatsApp PDFs extract better than forwarded images",
              "For prescriptions, ensure handwriting is legible",
            ].map((tip, i) => (
              <div key={i} style={{ display: "flex", gap: 7, marginBottom: 8, fontSize: "0.8125rem", color: "var(--text-secondary)" }}>
                <span style={{ color: "var(--forest-400)", fontWeight: 600 }}>·</span>
                <span>{tip}</span>
              </div>
            ))}
          </div>

          {/* WhatsApp integration note */}
          <div className="card card-pad" style={{ background: "var(--forest-700)", border: "none" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
              <MessageCircle size={16} color="rgba(255,255,255,0.8)" />
              <span className="t-subheading" style={{ color: "white" }}>WhatsApp Integration</span>
            </div>
            <p className="t-small" style={{ color: "rgba(255,255,255,0.65)", lineHeight: 1.7, marginBottom: 12 }}>
              Forward any lab report directly to our WhatsApp number. AI auto-extracts and adds it to your timeline.
            </p>
            <div style={{
              background: "rgba(255,255,255,0.1)", borderRadius: "var(--r-sm)",
              padding: "8px 12px", fontFamily: "var(--font-mono)", fontSize: "0.8125rem",
              color: "white",
            }}>
              +91 98000 12345
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </AppShell>
  );
}
