// lib/mock-data.ts
// Realistic Indian patient data for demo/development

export type LabValue = {
  id: string;
  name: string;
  value: number;
  unit: string;
  status: "normal" | "high" | "low" | "critical";
  referenceRange: string;
  date: string;
  lab: string;
  trend?: "up" | "down" | "flat";
  trendPct?: number;
};

export type Medication = {
  id: string;
  name: string;
  dose: string;
  frequency: string;
  prescribedBy: string;
  startDate: string;
  active: boolean;
};

export type TimelineEvent = {
  id: string;
  date: string;
  type: "lab" | "prescription" | "consultation" | "scan" | "vaccine";
  title: string;
  subtitle: string;
  severity: "critical" | "warning" | "normal" | "info";
  labs?: { name: string; value: string; status: "high" | "low" | "normal" }[];
  meds?: string[];
  doctor?: string;
  hospital?: string;
  notes?: string;
};

export type Alert = {
  id: string;
  severity: "critical" | "warning" | "info";
  title: string;
  description: string;
  action: string;
  createdAt: string;
  dismissed: boolean;
};

export type CareTask = {
  id: string;
  title: string;
  due: string;
  priority: "high" | "medium" | "low";
  status: "pending" | "done" | "snoozed";
  type: "test" | "appointment" | "medication" | "lifestyle";
};

export type FamilyMember = {
  id: string;
  name: string;
  relation: string;
  age: number;
  avatar: string;
  conditions: string[];
  lastActivity: string;
  healthScore: number;
  alerts: number;
};

export type Patient = {
  id: string;
  name: string;
  age: number;
  gender: string;
  bloodGroup: string;
  abhaId: string;
  phone: string;
  conditions: string[];
  healthScore: number;
  continuityScore: number;
  lastVisit: string;
  documentsCount: number;
};

// ─── Patient Profile ───────────────────────────────────────────────
export const MOCK_PATIENT: Patient = {
  id: "ws_ramesh_001",
  name: "Ramesh Patel",
  age: 54,
  gender: "Male",
  bloodGroup: "B+",
  abhaId: "43-2891-7456-0023",
  phone: "+91 98250 12345",
  conditions: ["Type 2 Diabetes", "Hypertension", "Dyslipidaemia"],
  healthScore: 62,
  continuityScore: 74,
  lastVisit: "15 Jan 2025",
  documentsCount: 14,
};

// ─── Lab Values ────────────────────────────────────────────────────
export const MOCK_LABS: LabValue[] = [
  {
    id: "l1",
    name: "HbA1c",
    value: 8.9,
    unit: "%",
    status: "critical",
    referenceRange: "4.0–5.6%",
    date: "15 Jan 2025",
    lab: "Dr Lal PathLabs",
    trend: "up",
    trendPct: 23.6,
  },
  {
    id: "l2",
    name: "Fasting Glucose",
    value: 186,
    unit: "mg/dL",
    status: "high",
    referenceRange: "70–100 mg/dL",
    date: "15 Jan 2025",
    lab: "Dr Lal PathLabs",
    trend: "up",
    trendPct: 12,
  },
  {
    id: "l3",
    name: "Blood Pressure",
    value: 128,
    unit: "/84 mmHg",
    status: "normal",
    referenceRange: "<120/80 mmHg",
    date: "10 Jan 2025",
    lab: "Apollo Clinic",
    trend: "flat",
    trendPct: 0,
  },
  {
    id: "l4",
    name: "Total Cholesterol",
    value: 218,
    unit: "mg/dL",
    status: "high",
    referenceRange: "<200 mg/dL",
    date: "15 Jan 2025",
    lab: "Dr Lal PathLabs",
    trend: "down",
    trendPct: 5,
  },
  {
    id: "l5",
    name: "Creatinine",
    value: 1.2,
    unit: "mg/dL",
    status: "normal",
    referenceRange: "0.7–1.3 mg/dL",
    date: "15 Jan 2025",
    lab: "Dr Lal PathLabs",
    trend: "flat",
    trendPct: 0,
  },
  {
    id: "l6",
    name: "Haemoglobin",
    value: 13.4,
    unit: "g/dL",
    status: "normal",
    referenceRange: "13.0–17.0 g/dL",
    date: "15 Jan 2025",
    lab: "Dr Lal PathLabs",
    trend: "down",
    trendPct: 3,
  },
  {
    id: "l7",
    name: "TSH",
    value: 2.8,
    unit: "mIU/L",
    status: "normal",
    referenceRange: "0.4–4.0 mIU/L",
    date: "Oct 2024",
    lab: "Metropolis",
    trend: "flat",
    trendPct: 0,
  },
  {
    id: "l8",
    name: "LDL Cholesterol",
    value: 142,
    unit: "mg/dL",
    status: "high",
    referenceRange: "<100 mg/dL",
    date: "15 Jan 2025",
    lab: "Dr Lal PathLabs",
    trend: "down",
    trendPct: 8,
  },
];

// ─── Medications ───────────────────────────────────────────────────
export const MOCK_MEDICATIONS: Medication[] = [
  {
    id: "m1",
    name: "Metformin",
    dose: "500mg",
    frequency: "Twice daily",
    prescribedBy: "Dr S. Mehta",
    startDate: "Jan 2023",
    active: true,
  },
  {
    id: "m2",
    name: "Telmisartan",
    dose: "40mg",
    frequency: "Once daily (morning)",
    prescribedBy: "Dr S. Mehta",
    startDate: "Mar 2023",
    active: true,
  },
  {
    id: "m3",
    name: "Atorvastatin",
    dose: "10mg",
    frequency: "Once daily (night)",
    prescribedBy: "Dr S. Mehta",
    startDate: "Mar 2023",
    active: true,
  },
  {
    id: "m4",
    name: "Aspirin",
    dose: "75mg",
    frequency: "Once daily",
    prescribedBy: "Dr S. Mehta",
    startDate: "Jan 2024",
    active: true,
  },
  {
    id: "m5",
    name: "Glipizide",
    dose: "5mg",
    frequency: "Twice daily (before meals)",
    prescribedBy: "Dr K. Sharma",
    startDate: "Oct 2022",
    active: false,
  },
];

// ─── Timeline ─────────────────────────────────────────────────────
export const MOCK_TIMELINE: TimelineEvent[] = [
  {
    id: "t1",
    date: "15 Jan 2025",
    type: "lab",
    title: "Quarterly HbA1c Panel",
    subtitle: "Dr Lal PathLabs, Vadodara",
    severity: "critical",
    labs: [
      { name: "HbA1c", value: "8.9%", status: "high" },
      { name: "Fasting Glucose", value: "186 mg/dL", status: "high" },
      { name: "Creatinine", value: "1.2 mg/dL", status: "normal" },
    ],
  },
  {
    id: "t2",
    date: "10 Jan 2025",
    type: "consultation",
    title: "Follow-up Consultation",
    subtitle: "Apollo Clinic, Vadodara",
    severity: "warning",
    doctor: "Dr S. Mehta",
    hospital: "Apollo Clinic",
    notes:
      "BP 128/84 — stable. HbA1c expected to worsen. Discussed lifestyle changes. Metformin dose to be reviewed at next visit.",
    meds: ["Metformin 500mg", "Telmisartan 40mg"],
  },
  {
    id: "t3",
    date: "Oct 2024",
    type: "lab",
    title: "Quarterly HbA1c Panel",
    subtitle: "Metropolis Labs, Vadodara",
    severity: "warning",
    labs: [
      { name: "HbA1c", value: "8.1%", status: "high" },
      { name: "Cholesterol", value: "224 mg/dL", status: "high" },
    ],
  },
  {
    id: "t4",
    date: "Jul 2024",
    type: "lab",
    title: "Quarterly HbA1c Panel",
    subtitle: "Thyrocare, Vadodara",
    severity: "warning",
    labs: [
      { name: "HbA1c", value: "7.6%", status: "high" },
      { name: "Fasting Glucose", value: "158 mg/dL", status: "high" },
    ],
  },
  {
    id: "t5",
    date: "Apr 2024",
    type: "lab",
    title: "Annual Health Checkup",
    subtitle: "Dr Lal PathLabs, Vadodara",
    severity: "normal",
    labs: [
      { name: "HbA1c", value: "7.2%", status: "high" },
      { name: "TSH", value: "2.8 mIU/L", status: "normal" },
      { name: "Haemoglobin", value: "13.8 g/dL", status: "normal" },
    ],
  },
  {
    id: "t6",
    date: "Mar 2024",
    type: "prescription",
    title: "Prescription Updated",
    subtitle: "Apollo Clinic",
    severity: "info",
    doctor: "Dr S. Mehta",
    meds: ["Aspirin 75mg added", "Atorvastatin 10mg"],
  },
];

// ─── Alerts ────────────────────────────────────────────────────────
export const MOCK_ALERTS: Alert[] = [
  {
    id: "a1",
    severity: "critical",
    title: "HbA1c worsening trend detected",
    description:
      "HbA1c has risen from 7.2% to 8.9% over 9 months. This sustained worsening requires immediate medical attention.",
    action: "Book appointment with Dr S. Mehta",
    createdAt: "15 Jan 2025",
    dismissed: false,
  },
  {
    id: "a2",
    severity: "warning",
    title: "LDL Cholesterol elevated",
    description:
      "LDL at 142 mg/dL is above the recommended 100 mg/dL for diabetic patients. Discuss statin dose with your doctor.",
    action: "Review at next consultation",
    createdAt: "15 Jan 2025",
    dismissed: false,
  },
  {
    id: "a3",
    severity: "info",
    title: "HbA1c retest due",
    description:
      "Diabetic patients should test HbA1c every 3 months. Your last test was 15 Jan 2025 — next is due 15 Apr 2025.",
    action: "Schedule lab test",
    createdAt: "16 Jan 2025",
    dismissed: false,
  },
];

// ─── Care Tasks ────────────────────────────────────────────────────
export const MOCK_CARE_TASKS: CareTask[] = [
  {
    id: "ct1",
    title: "Retest HbA1c",
    due: "15 Apr 2025",
    priority: "high",
    status: "pending",
    type: "test",
  },
  {
    id: "ct2",
    title: "Follow-up with Dr Mehta",
    due: "20 Feb 2025",
    priority: "high",
    status: "pending",
    type: "appointment",
  },
  {
    id: "ct3",
    title: "Refill Metformin prescription",
    due: "5 Feb 2025",
    priority: "medium",
    status: "pending",
    type: "medication",
  },
  {
    id: "ct4",
    title: "30-min walk daily",
    due: "Ongoing",
    priority: "medium",
    status: "pending",
    type: "lifestyle",
  },
  {
    id: "ct5",
    title: "Annual eye exam (diabetic retinopathy check)",
    due: "Apr 2025",
    priority: "medium",
    status: "pending",
    type: "appointment",
  },
];

// ─── Family Members ────────────────────────────────────────────────
export const MOCK_FAMILY: FamilyMember[] = [
  {
    id: "f1",
    name: "Ramesh Patel",
    relation: "You",
    age: 54,
    avatar: "👴",
    conditions: ["T2DM", "HTN"],
    lastActivity: "Today",
    healthScore: 62,
    alerts: 3,
  },
  {
    id: "f2",
    name: "Geeta Patel",
    relation: "Wife",
    age: 50,
    avatar: "👩",
    conditions: ["Hypothyroid"],
    lastActivity: "3 days ago",
    healthScore: 78,
    alerts: 1,
  },
  {
    id: "f3",
    name: "Kiran Patel",
    relation: "Mother",
    age: 78,
    avatar: "👵",
    conditions: ["HTN", "Osteoporosis"],
    lastActivity: "1 week ago",
    healthScore: 55,
    alerts: 2,
  },
];

// ─── Doctor Brief ──────────────────────────────────────────────────
export const MOCK_DOCTOR_BRIEF = {
  patientLine:
    "54M with T2DM (poorly controlled, HbA1c 8.9%) + HTN (stable on Telmisartan). 9-month worsening trend in glycaemic control.",
  continuityScore: 74,
  generatedAt: "15 Jan 2025, 09:14 AM",
  urgentFlags: [
    "[URGENT] HbA1c 8.9% — worsened from 7.2% (Apr) → 7.6% (Jul) → 8.1% (Oct) → 8.9% (Jan). Possible medication non-adherence or dietary worsening.",
    "LDL 142 mg/dL — above target (<100) for diabetic patient on Atorvastatin 10mg. Consider dose escalation.",
  ],
  recentHighlights: [
    "BP 128/84 on 10 Jan — stable across last 3 visits",
    "Creatinine 1.2 mg/dL — kidney function normal, within safe range for Metformin",
    "Haemoglobin 13.4 g/dL — borderline, down from 13.8 in Apr 2024",
  ],
  suggestedActions: [
    "Review Metformin dose — consider titration to 1000mg twice daily if tolerated",
    "Consider adding SGLT2 inhibitor (Dapagliflozin) for cardiovascular + glycaemic benefit",
    "Repeat HbA1c in 6 weeks after intervention",
    "Atorvastatin dose review — escalate to 20mg",
    "Foot exam — not documented in last 12 months",
  ],
  medicationFlags: [
    "Metformin 500mg twice daily — suboptimal dose for current HbA1c level",
    "No documented medication adherence check in last 2 visits",
  ],
};

// ─── Upload history ────────────────────────────────────────────────
export const MOCK_DOCUMENTS = [
  {
    id: "d1",
    name: "HbA1c_Jan2025.jpg",
    type: "lab_report",
    status: "processed",
    uploadedAt: "15 Jan 2025",
    extractedCount: 5,
    source: "camera",
    fileSize: "1.2 MB",
  },
  {
    id: "d2",
    name: "Prescription_Mehta_Jan2025.pdf",
    type: "prescription",
    status: "processed",
    uploadedAt: "11 Jan 2025",
    extractedCount: 4,
    source: "upload",
    fileSize: "340 KB",
  },
  {
    id: "d3",
    name: "WhatsApp_Report_Oct2024.jpg",
    type: "lab_report",
    status: "processed",
    uploadedAt: "8 Oct 2024",
    extractedCount: 3,
    source: "whatsapp",
    fileSize: "892 KB",
  },
  {
    id: "d4",
    name: "Annual_Checkup_Apr2024.pdf",
    type: "lab_report",
    status: "processed",
    uploadedAt: "2 Apr 2024",
    extractedCount: 12,
    source: "upload",
    fileSize: "2.1 MB",
  },
];
