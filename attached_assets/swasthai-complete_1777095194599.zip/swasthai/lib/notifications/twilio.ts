// lib/notifications/twilio.ts
// WhatsApp and SMS notifications via Twilio
// WhatsApp requires: Twilio WhatsApp sandbox or approved sender
// SMS OTP: standard Twilio SMS

import twilio from "twilio";

function getClient() {
  return twilio(
    process.env.TWILIO_ACCOUNT_SID!,
    process.env.TWILIO_AUTH_TOKEN!
  );
}

const WA_FROM = `whatsapp:${process.env.TWILIO_WHATSAPP_NUMBER}`;
const SMS_FROM = process.env.TWILIO_PHONE_NUMBER!;

// ── OTP via SMS ─────────────────────────────────────────────────────
export async function sendOtpSms(phone: string, otp: string): Promise<void> {
  await getClient().messages.create({
    from: SMS_FROM,
    to: phone.startsWith("+") ? phone : `+91${phone}`,
    body: `${otp} is your SwasthAI verification code. Valid for 10 minutes. Do not share this with anyone.`,
  });
}

// ── WhatsApp: Extraction complete ───────────────────────────────────
export async function notifyExtractionComplete(params: {
  phone: string;
  patientName: string;
  labCount: number;
  medCount: number;
  appUrl: string;
}): Promise<void> {
  const { phone, patientName, labCount, medCount, appUrl } = params;
  const message = `✅ *SwasthAI: Report Processed*

Hi ${patientName}, your health document has been analysed.

📊 Lab values extracted: *${labCount}*
💊 Medications found: *${medCount}*

View your updated health timeline:
${appUrl}/timeline

—SwasthAI 🏥`;

  await getClient().messages.create({
    from: WA_FROM,
    to: `whatsapp:${phone.startsWith("+") ? phone : "+91" + phone}`,
    body: message,
  });
}

// ── WhatsApp: Critical alert ─────────────────────────────────────────
export async function notifyCriticalAlert(params: {
  phone: string;
  patientName: string;
  alertTitle: string;
  description: string;
  appUrl: string;
}): Promise<void> {
  const { phone, patientName, alertTitle, description, appUrl } = params;
  const message = `🚨 *SwasthAI Critical Alert*

Patient: *${patientName}*
Alert: *${alertTitle}*

${description}

This requires prompt medical attention.

View details: ${appUrl}/dashboard

—SwasthAI 🏥
_Reply STOP to unsubscribe_`;

  await getClient().messages.create({
    from: WA_FROM,
    to: `whatsapp:${phone.startsWith("+") ? phone : "+91" + phone}`,
    body: message,
  });
}

// ── WhatsApp: Care task reminder ─────────────────────────────────────
export async function notifyCareReminder(params: {
  phone: string;
  patientName: string;
  taskTitle: string;
  dueDate: string;
  priority: string;
  appUrl: string;
}): Promise<void> {
  const { phone, patientName, taskTitle, dueDate, priority, appUrl } = params;
  const emoji = priority === "high" ? "⚠️" : priority === "medium" ? "📋" : "💡";

  const message = `${emoji} *SwasthAI Health Reminder*

Hi ${patientName},

${taskTitle}
Due: *${dueDate}*

Stay on track with your health plan.
View tasks: ${appUrl}/dashboard

—SwasthAI 🏥
_Reply STOP to unsubscribe_`;

  await getClient().messages.create({
    from: WA_FROM,
    to: `whatsapp:${phone.startsWith("+") ? phone : "+91" + phone}`,
    body: message,
  });
}

// ── WhatsApp: Doctor brief shared ───────────────────────────────────
export async function notifyBriefShared(params: {
  doctorPhone: string;
  patientName: string;
  briefUrl: string;
}): Promise<void> {
  const { doctorPhone, patientName, briefUrl } = params;
  const message = `🩺 *Pre-Consultation Brief Available*

Patient *${patientName}* has shared their health brief with you for the upcoming consultation.

View brief (valid 24 hours):
${briefUrl}

_Powered by SwasthAI_`;

  await getClient().messages.create({
    from: WA_FROM,
    to: `whatsapp:${doctorPhone.startsWith("+") ? doctorPhone : "+91" + doctorPhone}`,
    body: message,
  });
}

// ── WhatsApp: Payment confirmed ──────────────────────────────────────
export async function notifyPrivatePaymentConfirmed(params: {
  phone: string;
  amountInr: number;
  txSig: string;
}): Promise<void> {
  const { phone, amountInr, txSig } = params;
  const message = `🔐 *SwasthAI Private Payment Confirmed*

Amount: ₹${amountInr.toLocaleString("en-IN")}
Status: *Confirmed on Solana*
Tx: ${txSig.slice(0, 20)}...

Your viewing key has been saved in the app.
Use it to generate insurance proof anytime.

—SwasthAI 🏥`;

  await getClient().messages.create({
    from: WA_FROM,
    to: `whatsapp:${phone.startsWith("+") ? phone : "+91" + phone}`,
    body: message,
  });
}
