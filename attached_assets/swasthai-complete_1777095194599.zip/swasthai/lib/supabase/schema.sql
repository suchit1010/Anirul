-- ═══════════════════════════════════════════════════════
-- SWASTHAI — SUPABASE SCHEMA
-- Run this in your Supabase SQL editor:
-- Dashboard → SQL Editor → New Query → paste → Run
-- ═══════════════════════════════════════════════════════

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- ── Users (extends Supabase auth.users) ─────────────────
create table if not exists public.profiles (
  id            uuid references auth.users(id) on delete cascade primary key,
  full_name     text,
  phone         text unique,
  age           integer,
  gender        text check (gender in ('Male','Female','Other')),
  blood_group   text,
  abha_id       text unique,
  conditions    text[] default '{}',
  plan          text default 'free' check (plan in ('free','individual','family','clinic')),
  plan_expires  timestamptz,
  whatsapp_opt  boolean default true,
  created_at    timestamptz default now(),
  updated_at    timestamptz default now()
);

-- ── Workspaces (patient health accounts) ────────────────
create table if not exists public.workspaces (
  id            uuid default uuid_generate_v4() primary key,
  owner_id      uuid references public.profiles(id) on delete cascade not null,
  name          text not null,
  relation      text default 'self',
  health_score  integer default 0 check (health_score between 0 and 100),
  continuity    integer default 0 check (continuity between 0 and 100),
  is_default    boolean default false,
  created_at    timestamptz default now(),
  updated_at    timestamptz default now()
);

-- ── Documents ────────────────────────────────────────────
create table if not exists public.documents (
  id              uuid default uuid_generate_v4() primary key,
  workspace_id    uuid references public.workspaces(id) on delete cascade not null,
  uploaded_by     uuid references public.profiles(id) not null,
  file_name       text not null,
  mime_type       text not null,
  size_bytes      bigint,
  storage_key     text,                        -- R2 object key
  source          text default 'upload'
                  check (source in ('upload','camera','whatsapp','voice','api')),
  status          text default 'uploaded'
                  check (status in ('uploaded','processing','processed','failed')),
  extracted_text  text,
  extracted_data  jsonb default '{}',          -- full AI extraction output
  document_type   text,                        -- lab_report | prescription | ...
  ai_confidence   numeric(4,3),
  document_date   date,
  created_at      timestamptz default now(),
  updated_at      timestamptz default now()
);

-- ── Lab Values (normalised from documents) ───────────────
create table if not exists public.lab_values (
  id              uuid default uuid_generate_v4() primary key,
  workspace_id    uuid references public.workspaces(id) on delete cascade not null,
  document_id     uuid references public.documents(id) on delete cascade,
  lab_name        text not null,               -- "HbA1c"
  value           numeric not null,
  unit            text,
  status          text check (status in ('normal','high','low','critical')),
  reference_min   numeric,
  reference_max   numeric,
  reference_text  text,
  observed_at     timestamptz not null,
  lab_facility    text,
  ordered_by      text,
  created_at      timestamptz default now()
);

-- ── Medications ──────────────────────────────────────────
create table if not exists public.medications (
  id            uuid default uuid_generate_v4() primary key,
  workspace_id  uuid references public.workspaces(id) on delete cascade not null,
  document_id   uuid references public.documents(id) on delete set null,
  name          text not null,
  dose          text,
  frequency     text,
  route         text default 'oral',
  prescribed_by text,
  start_date    date,
  end_date      date,
  is_active     boolean default true,
  notes         text,
  created_at    timestamptz default now()
);

-- ── Clinical Alerts ───────────────────────────────────────
create table if not exists public.alerts (
  id            uuid default uuid_generate_v4() primary key,
  workspace_id  uuid references public.workspaces(id) on delete cascade not null,
  severity      text not null check (severity in ('critical','warning','info')),
  title         text not null,
  description   text,
  action        text,
  source        text default 'ai',
  dismissed     boolean default false,
  notified_at   timestamptz,
  created_at    timestamptz default now()
);

-- ── Care Tasks ────────────────────────────────────────────
create table if not exists public.care_tasks (
  id            uuid default uuid_generate_v4() primary key,
  workspace_id  uuid references public.workspaces(id) on delete cascade not null,
  title         text not null,
  task_type     text check (task_type in ('test','appointment','medication','lifestyle')),
  priority      text default 'medium' check (priority in ('high','medium','low')),
  status        text default 'pending' check (status in ('pending','done','snoozed')),
  due_date      timestamptz,
  source        text default 'manual',
  created_at    timestamptz default now()
);

-- ── Doctor Brief Cache ────────────────────────────────────
create table if not exists public.doctor_briefs (
  id            uuid default uuid_generate_v4() primary key,
  workspace_id  uuid references public.workspaces(id) on delete cascade unique not null,
  brief_data    jsonb not null,
  generated_at  timestamptz default now(),
  updated_at    timestamptz default now()
);

-- ── Private Payments ─────────────────────────────────────
create table if not exists public.private_payments (
  id                  uuid default uuid_generate_v4() primary key,
  workspace_id        uuid references public.workspaces(id) on delete cascade not null,
  category            text not null,
  provider_type       text not null,           -- desensitized for insurance
  amount_inr          numeric not null,
  amount_sol          numeric,
  stealth_address     text unique,
  ephemeral_pub_key   text,
  viewing_key_hash    text,                    -- sha256 of viewing key, NEVER the key itself
  status              text default 'pending'
                      check (status in ('pending','confirmed','failed','refunded')),
  tx_signature        text,
  on_chain_hash       text,
  confirmed_at        timestamptz,
  created_at          timestamptz default now()
);

-- ── Consent Records (on-chain receipts) ──────────────────
create table if not exists public.consent_receipts (
  id              uuid default uuid_generate_v4() primary key,
  workspace_id    uuid references public.workspaces(id) on delete cascade not null,
  shared_with     text,                        -- doctor/clinic identifier
  scope           text[] default '{}',
  expires_at      timestamptz,
  on_chain_hash   text,
  solana_sig      text,
  revoked         boolean default false,
  created_at      timestamptz default now()
);

-- ── Notifications Log ─────────────────────────────────────
create table if not exists public.notifications (
  id          uuid default uuid_generate_v4() primary key,
  profile_id  uuid references public.profiles(id) on delete cascade not null,
  channel     text check (channel in ('whatsapp','sms','push','email')),
  type        text,
  content     text,
  status      text default 'sent' check (status in ('sent','delivered','failed')),
  sent_at     timestamptz default now()
);

-- ═══════════════════════════════════════════════════════
-- ROW LEVEL SECURITY
-- ═══════════════════════════════════════════════════════

alter table public.profiles         enable row level security;
alter table public.workspaces        enable row level security;
alter table public.documents         enable row level security;
alter table public.lab_values        enable row level security;
alter table public.medications       enable row level security;
alter table public.alerts            enable row level security;
alter table public.care_tasks        enable row level security;
alter table public.doctor_briefs     enable row level security;
alter table public.private_payments  enable row level security;
alter table public.consent_receipts  enable row level security;
alter table public.notifications     enable row level security;

-- Profiles: user can only see and edit their own profile
create policy "profiles_self" on public.profiles
  for all using (auth.uid() = id);

-- Workspaces: owner sees all their workspaces
create policy "workspaces_owner" on public.workspaces
  for all using (auth.uid() = owner_id);

-- Documents: owner of workspace
create policy "documents_workspace_owner" on public.documents
  for all using (
    workspace_id in (
      select id from public.workspaces where owner_id = auth.uid()
    )
  );

-- Lab values: same pattern
create policy "lab_values_workspace_owner" on public.lab_values
  for all using (
    workspace_id in (
      select id from public.workspaces where owner_id = auth.uid()
    )
  );

create policy "medications_workspace_owner" on public.medications
  for all using (
    workspace_id in (
      select id from public.workspaces where owner_id = auth.uid()
    )
  );

create policy "alerts_workspace_owner" on public.alerts
  for all using (
    workspace_id in (
      select id from public.workspaces where owner_id = auth.uid()
    )
  );

create policy "care_tasks_workspace_owner" on public.care_tasks
  for all using (
    workspace_id in (
      select id from public.workspaces where owner_id = auth.uid()
    )
  );

create policy "doctor_briefs_workspace_owner" on public.doctor_briefs
  for all using (
    workspace_id in (
      select id from public.workspaces where owner_id = auth.uid()
    )
  );

create policy "payments_workspace_owner" on public.private_payments
  for all using (
    workspace_id in (
      select id from public.workspaces where owner_id = auth.uid()
    )
  );

create policy "consent_workspace_owner" on public.consent_receipts
  for all using (
    workspace_id in (
      select id from public.workspaces where owner_id = auth.uid()
    )
  );

create policy "notifications_self" on public.notifications
  for all using (auth.uid() = profile_id);

-- ═══════════════════════════════════════════════════════
-- INDEXES (performance)
-- ═══════════════════════════════════════════════════════

create index if not exists idx_workspaces_owner     on public.workspaces(owner_id);
create index if not exists idx_documents_workspace  on public.documents(workspace_id);
create index if not exists idx_documents_status     on public.documents(status);
create index if not exists idx_lab_values_workspace on public.lab_values(workspace_id);
create index if not exists idx_lab_values_name      on public.lab_values(lab_name);
create index if not exists idx_lab_values_date      on public.lab_values(observed_at desc);
create index if not exists idx_alerts_workspace     on public.alerts(workspace_id);
create index if not exists idx_alerts_severity      on public.alerts(severity) where dismissed = false;
create index if not exists idx_medications_active   on public.medications(workspace_id) where is_active = true;

-- ═══════════════════════════════════════════════════════
-- FUNCTIONS
-- ═══════════════════════════════════════════════════════

-- Auto-create profile + default workspace on signup
create or replace function public.handle_new_user()
returns trigger as $$
declare
  ws_id uuid;
begin
  insert into public.profiles (id, phone, full_name)
  values (
    new.id,
    new.phone,
    coalesce(new.raw_user_meta_data->>'full_name', 'My Profile')
  );

  insert into public.workspaces (owner_id, name, relation, is_default)
  values (new.id, 'My Health', 'self', true)
  returning id into ws_id;

  return new;
end;
$$ language plpgsql security definer;

create or replace trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Update updated_at timestamps
create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger set_profiles_updated_at before update on public.profiles
  for each row execute function public.set_updated_at();
create trigger set_workspaces_updated_at before update on public.workspaces
  for each row execute function public.set_updated_at();
create trigger set_documents_updated_at before update on public.documents
  for each row execute function public.set_updated_at();
