// lib/storage/r2.ts
// Cloudflare R2 — S3-compatible, zero egress cost, India-region friendly
// Docs: https://developers.cloudflare.com/r2/api/s3/

import {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
  DeleteObjectCommand,
  HeadObjectCommand,
} from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { Readable } from "stream";

// ── Client ─────────────────────────────────────────────────────────
function getR2Client() {
  return new S3Client({
    region: "auto",
    endpoint: `https://${process.env.CLOUDFLARE_ACCOUNT_ID!}.r2.cloudflarestorage.com`,
    credentials: {
      accessKeyId: process.env.R2_ACCESS_KEY_ID!,
      secretAccessKey: process.env.R2_SECRET_ACCESS_KEY!,
    },
  });
}

const BUCKET = () => process.env.R2_BUCKET_NAME!;

// ── Key helpers ─────────────────────────────────────────────────────
export function buildStorageKey(
  workspaceId: string,
  documentId: string,
  fileName: string
): string {
  // e.g. workspaces/ws_abc123/documents/doc_xyz789/HbA1c_Jan2025.jpg
  const safe = fileName.replace(/[^a-zA-Z0-9._-]/g, "_");
  return `workspaces/${workspaceId}/documents/${documentId}/${safe}`;
}

// ── Upload document ─────────────────────────────────────────────────
export async function uploadDocument(params: {
  workspaceId: string;
  documentId: string;
  fileName: string;
  buffer: Buffer;
  mimeType: string;
}): Promise<{ storageKey: string; sizeBytes: number }> {
  const { workspaceId, documentId, fileName, buffer, mimeType } = params;
  const storageKey = buildStorageKey(workspaceId, documentId, fileName);

  await getR2Client().send(
    new PutObjectCommand({
      Bucket: BUCKET(),
      Key: storageKey,
      Body: buffer,
      ContentType: mimeType,
      ContentLength: buffer.length,
      // Server-side encryption
      ServerSideEncryption: "AES256",
      // Metadata — no PHI, just identifiers
      Metadata: {
        workspaceId,
        documentId,
        uploadedAt: new Date().toISOString(),
      },
    })
  );

  return { storageKey, sizeBytes: buffer.length };
}

// ── Download document buffer ────────────────────────────────────────
export async function downloadDocument(storageKey: string): Promise<Buffer> {
  const response = await getR2Client().send(
    new GetObjectCommand({ Bucket: BUCKET(), Key: storageKey })
  );

  const stream = response.Body as Readable;
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    stream.on("data", (chunk: Buffer) => chunks.push(chunk));
    stream.on("end", () => resolve(Buffer.concat(chunks)));
    stream.on("error", reject);
  });
}

// ── Presigned URL for browser direct upload ─────────────────────────
// Client uploads directly to R2 — bypasses server memory limit
export async function getPresignedUploadUrl(params: {
  workspaceId: string;
  documentId: string;
  fileName: string;
  mimeType: string;
  expiresInSeconds?: number;
}): Promise<{ uploadUrl: string; storageKey: string }> {
  const {
    workspaceId,
    documentId,
    fileName,
    mimeType,
    expiresInSeconds = 600,
  } = params;

  const storageKey = buildStorageKey(workspaceId, documentId, fileName);

  const uploadUrl = await getSignedUrl(
    getR2Client(),
    new PutObjectCommand({
      Bucket: BUCKET(),
      Key: storageKey,
      ContentType: mimeType,
    }),
    { expiresIn: expiresInSeconds }
  );

  return { uploadUrl, storageKey };
}

// ── Presigned URL for browser download (time-limited) ───────────────
export async function getSignedDownloadUrl(
  storageKey: string,
  expiresInSeconds = 3600
): Promise<string> {
  return getSignedUrl(
    getR2Client(),
    new GetObjectCommand({ Bucket: BUCKET(), Key: storageKey }),
    { expiresIn: expiresInSeconds }
  );
}

// ── Delete document ─────────────────────────────────────────────────
export async function deleteDocument(storageKey: string): Promise<void> {
  await getR2Client().send(
    new DeleteObjectCommand({ Bucket: BUCKET(), Key: storageKey })
  );
}

// ── Check if object exists ──────────────────────────────────────────
export async function objectExists(storageKey: string): Promise<boolean> {
  try {
    await getR2Client().send(
      new HeadObjectCommand({ Bucket: BUCKET(), Key: storageKey })
    );
    return true;
  } catch {
    return false;
  }
}
