// lib/blockchain/solana.ts
// Private healthcare payments via Solana stealth addresses
// Consent hash written to chain via Memo program
// Zero PHI on-chain — only hashes and anonymous transfers

import {
  Connection,
  Keypair,
  PublicKey,
  Transaction,
  TransactionInstruction,
  SystemProgram,
  LAMPORTS_PER_SOL,
  sendAndConfirmTransaction,
} from "@solana/web3.js";
import crypto from "crypto";

// ── Connection ─────────────────────────────────────────────────────
function getConnection(): Connection {
  return new Connection(
    process.env.SOLANA_RPC_URL ?? "https://api.devnet.solana.com",
    "confirmed"
  );
}

function getPayerKeypair(): Keypair {
  const raw = process.env.SOLANA_PAYER_PRIVATE_KEY!;
  const bytes = JSON.parse(raw) as number[];
  return Keypair.fromSecretKey(Uint8Array.from(bytes));
}

// Solana Memo program — for writing arbitrary UTF-8 data to chain
const MEMO_PROGRAM_ID = new PublicKey(
  "MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr"
);

// ── Types ──────────────────────────────────────────────────────────
export type StealthPaymentInit = {
  paymentId: string;
  stealthAddress: string;
  ephemeralPublicKey: string;
  viewingKey: string;       // NEVER store this — return to client only
  viewingKeyHash: string;   // Store this in DB
  amountLamports: number;
  expiresAt: string;
};

export type PaymentConfirmation = {
  txSignature: string;
  onChainHash: string;
  confirmedAt: string;
  blockTime: number;
};

export type InsuranceProof = {
  proofId: string;
  paymentVerified: boolean;
  amount: number;
  currency: string;
  category: string;           // desensitized
  date: string;
  providerType: string;       // desensitized — never actual name
  txSignature: string;
};

// Maps sensitive categories → desensitized strings for insurance proofs
export const CATEGORY_MAP: Record<string, string> = {
  mental_health:        "Healthcare Service",
  reproductive_health:  "Healthcare Service",
  addiction_treatment:  "Healthcare Service",
  general:              "Medical Consultation",
  lab:                  "Diagnostic Testing",
  pharmacy:             "Pharmaceutical",
  imaging:              "Diagnostic Imaging",
  surgery:              "Surgical Service",
  emergency:            "Emergency Medical Service",
};

// ── Hash helpers ───────────────────────────────────────────────────
function hashViewingKey(viewingKey: string): string {
  return crypto.createHash("sha256").update(viewingKey).digest("hex");
}

async function sha256(data: string): Promise<string> {
  const buf = await crypto.subtle.digest("SHA-256", Buffer.from(data));
  return Buffer.from(buf).toString("hex");
}

// ── Generate stealth address ────────────────────────────────────────
// Stealth address = deterministic keypair derived from shared secret
// Shared secret = ECDH(ephemeral_private, provider_public)
// On-chain: payer sends SOL to stealthAddress — no link to provider
async function generateStealthAddress(
  providerPublicKeyB58: string,
  ephemeralKeypair: Keypair
): Promise<{ stealthAddress: PublicKey; stealthKeypair: Keypair }> {
  const providerPubBytes = new PublicKey(providerPublicKeyB58).toBytes();
  const ephemeralPrivBytes = ephemeralKeypair.secretKey.slice(0, 32);

  // Approximate ECDH: combine provider pub + ephemeral priv via SHA-256
  // Production: replace with @noble/curves ed25519 for proper ECDH
  const combined = Buffer.concat([ephemeralPrivBytes, providerPubBytes]);
  const hash = await crypto.subtle.digest("SHA-256", combined);
  const seed = Buffer.from(hash);

  const stealthKeypair = Keypair.fromSeed(seed);
  return { stealthAddress: stealthKeypair.publicKey, stealthKeypair };
}

// ── Initiate payment ────────────────────────────────────────────────
export async function initiatePrivatePayment(params: {
  paymentId: string;
  providerWalletAddress: string;
  amountSol: number;
  category: string;
}): Promise<StealthPaymentInit> {
  const { paymentId, providerWalletAddress, amountSol, category } = params;

  // One-time ephemeral keypair — discarded after this function
  const ephemeralKeypair = Keypair.generate();

  const { stealthAddress } = await generateStealthAddress(
    providerWalletAddress,
    ephemeralKeypair
  );

  // Viewing key = base64(ephemeral_private[0:16] || category_bytes)
  const viewingKeyRaw = Buffer.concat([
    ephemeralKeypair.secretKey.slice(0, 24),
    Buffer.from(category.padEnd(16, "\0").slice(0, 16)),
  ]).toString("base64url");

  const amountLamports = Math.round(amountSol * LAMPORTS_PER_SOL);

  return {
    paymentId,
    stealthAddress: stealthAddress.toBase58(),
    ephemeralPublicKey: ephemeralKeypair.publicKey.toBase58(),
    viewingKey: viewingKeyRaw,          // return to client, NEVER store
    viewingKeyHash: hashViewingKey(viewingKeyRaw),  // store this
    amountLamports,
    expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
  };
}

// ── Execute payment ─────────────────────────────────────────────────
export async function executePayment(params: {
  stealthAddress: string;
  amountLamports: number;
}): Promise<PaymentConfirmation> {
  const connection = getConnection();
  const payer = getPayerKeypair();
  const recipient = new PublicKey(params.stealthAddress);

  const transaction = new Transaction().add(
    SystemProgram.transfer({
      fromPubkey: payer.publicKey,
      toPubkey: recipient,
      lamports: params.amountLamports,
    })
  );

  const { blockhash } = await connection.getLatestBlockhash();
  transaction.recentBlockhash = blockhash;
  transaction.feePayer = payer.publicKey;

  const txSignature = await sendAndConfirmTransaction(
    connection,
    transaction,
    [payer],
    { commitment: "confirmed" }
  );

  const txDetails = await connection.getTransaction(txSignature);
  const blockTime = txDetails?.blockTime ?? Math.floor(Date.now() / 1000);

  return {
    txSignature,
    onChainHash: txSignature, // Solana tx sig IS the hash
    confirmedAt: new Date(blockTime * 1000).toISOString(),
    blockTime,
  };
}

// ── Generate insurance proof ─────────────────────────────────────────
export function generateInsuranceProof(params: {
  paymentId: string;
  viewingKey: string;
  viewingKeyHash: string;
  amountInr: number;
  category: string;
  txSignature: string;
  confirmedAt: string;
}): InsuranceProof {
  const {
    paymentId,
    viewingKey,
    viewingKeyHash,
    amountInr,
    category,
    txSignature,
    confirmedAt,
  } = params;

  // Verify the patient owns this payment
  if (hashViewingKey(viewingKey) !== viewingKeyHash) {
    throw new Error("Invalid viewing key — cannot generate proof");
  }

  return {
    proofId: `proof_${paymentId.slice(0, 8)}_${Date.now()}`,
    paymentVerified: true,
    amount: amountInr,
    currency: "INR",
    category: CATEGORY_MAP[category] ?? "Healthcare Service",
    date: confirmedAt,
    providerType: CATEGORY_MAP[category] ?? "Healthcare Service",
    txSignature,
    // providerName: deliberately omitted
    // providerAddress: deliberately omitted
    // condition: deliberately omitted
  };
}

// ── Write consent to chain ────────────────────────────────────────────
export async function writeConsentToChain(params: {
  consentId: string;
  workspaceId: string;
  scope: string[];
  expiresAt: string;
}): Promise<{ txSignature: string; consentHash: string }> {
  const { consentId, workspaceId, scope, expiresAt } = params;
  const connection = getConnection();
  const payer = getPayerKeypair();

  // Hash of consent data — PHI never touches blockchain
  const consentData = JSON.stringify({
    consentId,
    workspaceId,
    scope: scope.sort(),
    expiresAt,
    ts: Date.now(),
  });
  const consentHash = await sha256(consentData);

  // Memo payload — only hash on-chain
  const memoPayload = JSON.stringify({
    app: "SWASTHAI_V1",
    type: "CONSENT",
    hash: consentHash,
    // No PHI
  });

  const memoInstruction = new TransactionInstruction({
    keys: [{ pubkey: payer.publicKey, isSigner: true, isWritable: false }],
    programId: MEMO_PROGRAM_ID,
    data: Buffer.from(memoPayload, "utf-8"),
  });

  const transaction = new Transaction().add(memoInstruction);
  const { blockhash } = await connection.getLatestBlockhash();
  transaction.recentBlockhash = blockhash;
  transaction.feePayer = payer.publicKey;

  const txSignature = await sendAndConfirmTransaction(
    connection,
    transaction,
    [payer],
    { commitment: "confirmed" }
  );

  return { txSignature, consentHash };
}

// ── Verify consent on chain ──────────────────────────────────────────
export async function verifyConsentOnChain(
  txSignature: string
): Promise<{ verified: boolean; blockTime?: number }> {
  try {
    const connection = getConnection();
    const tx = await connection.getTransaction(txSignature);
    if (!tx) return { verified: false };
    return { verified: true, blockTime: tx.blockTime ?? undefined };
  } catch {
    return { verified: false };
  }
}

// ── Get SOL balance of payer wallet ─────────────────────────────────
export async function getPayerBalance(): Promise<{
  sol: number;
  lamports: number;
}> {
  const connection = getConnection();
  const payer = getPayerKeypair();
  const lamports = await connection.getBalance(payer.publicKey);
  return { sol: lamports / LAMPORTS_PER_SOL, lamports };
}
