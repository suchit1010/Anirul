// lib/ai/extraction.ts
// Real AI extraction using Claude claude-opus-4-5 vision + text
// Handles: PDF text, JPG/PNG photos, WhatsApp forwards, Hindi/Gujarati reports

import Anthropic from "@anthropic-ai/sdk";

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY!,
});

// ── Types ──────────────────────────────────────────────────────────
export type ExtractedLabValue = {
  name: string;
  value: number;
  unit: string;
  status: "normal" | "high" | "low" | "critical";
  referenceRange?: string;
  referenceMin?: number;
  referenceMax?: number;
  date?: string;
  lab?: string;
};

export type ExtractedMedication = {
  name: string;
  dose?: string;
  frequency?: string;
  route?: string;
  prescribedBy?: string;
  startDate?: string;
};

export type ExtractionResult = {
  labValues: ExtractedLabValue[];
  medications: ExtractedMedication[];
  diagnoses: string[];
  vitals: {
    bp?: string;
    weight?: string;
    height?: string;
    pulse?: string;
    spo2?: string;
    temp?: string;
  };
  documentType:
    | "lab_report"
    | "prescription"
    | "discharge_summary"
    | "consultation_note"
    | "scan_report"
    | "vaccine_record"
    | "unknown";
  documentDate?: string;
  labFacility?: string;
  doctorName?: string;
  hospitalName?: string;
  followUpInstructions: string[];
  language: "english" | "hindi" | "gujarati" | "mixed";
  confidence: number;
  rawText?: string;
};

// ── System prompt ──────────────────────────────────────────────────
const SYSTEM_PROMPT = `You are a senior clinical data extraction specialist for Indian healthcare records.
Your job: extract ALL clinical data from medical documents with maximum accuracy.

CRITICAL RULES:
1. Output ONLY valid JSON. Zero prose. Zero markdown. Zero explanation.
2. Extract EVERY lab value visible — do not skip any.
3. Convert Indic numerals to Arabic (७.२ → 7.2, ८.९ → 8.9).
4. Handle Hindi medical terms: शुगर/रक्त शर्करा=glucose, रक्तचाप=blood pressure, हीमोग्लोबिन=hemoglobin, क्रिएटिनिन=creatinine, थायरॉइड=thyroid.
5. Handle Gujarati: ખાંડ=sugar, લોહી=blood, ક્રિએટિનાઇન=creatinine.
6. For STATUS: normal=within range, high=above max, low=below min, critical=dangerously high/low.
7. If a value is missing, omit its field — never use null or "unknown".
8. For dates: use ISO format YYYY-MM-DD. Estimate from context if not explicit.
9. Confidence: 0.0-1.0 based on document clarity and completeness.`;

const USER_PROMPT = `Extract ALL clinical information from this medical document.

Return ONLY this JSON structure (omit fields you cannot find):
{
  "labValues": [
    {
      "name": "HbA1c",
      "value": 8.9,
      "unit": "%",
      "status": "critical",
      "referenceRange": "4.0-5.6%",
      "referenceMin": 4.0,
      "referenceMax": 5.6,
      "date": "2025-01-15",
      "lab": "Dr Lal PathLabs"
    }
  ],
  "medications": [
    {
      "name": "Metformin",
      "dose": "500mg",
      "frequency": "twice daily",
      "route": "oral",
      "prescribedBy": "Dr S. Mehta",
      "startDate": "2025-01-15"
    }
  ],
  "diagnoses": ["Type 2 Diabetes Mellitus", "Essential Hypertension"],
  "vitals": {
    "bp": "128/84",
    "weight": "78kg",
    "height": "170cm",
    "pulse": "82",
    "spo2": "98%",
    "temp": "98.6F"
  },
  "documentType": "lab_report",
  "documentDate": "2025-01-15",
  "labFacility": "Dr Lal PathLabs, Vadodara",
  "doctorName": "Dr S. Mehta",
  "hospitalName": "Apollo Clinic",
  "followUpInstructions": ["Repeat HbA1c in 3 months", "Check BP weekly"],
  "language": "english",
  "confidence": 0.96
}`;

// ── Main extraction function ────────────────────────────────────────
export async function extractClinicalData(
  mimeType: string,
  buffer: Buffer,
  plaintextOverride?: string
): Promise<ExtractionResult> {
  let content: Anthropic.MessageParam["content"];

  // Choose extraction path
  if (plaintextOverride) {
    // WhatsApp text, typed input, voice transcript
    content = [
      {
        type: "text",
        text: USER_PROMPT + "\n\nDOCUMENT TEXT:\n" + plaintextOverride,
      },
    ];
  } else if (mimeType === "application/pdf") {
    // Extract text from PDF, fall back to text
    const rawText = await extractPdfText(buffer);
    if (!rawText.trim()) {
      return emptyResult("Scanned PDF — please upload as JPG/PNG image for best results");
    }
    content = [
      {
        type: "text",
        text: USER_PROMPT + "\n\nDOCUMENT TEXT:\n" + rawText,
      },
    ];
  } else if (
    mimeType === "image/jpeg" ||
    mimeType === "image/jpg" ||
    mimeType === "image/png" ||
    mimeType === "image/webp"
  ) {
    // Vision path — handles photos of lab reports, prescriptions
    const base64 = buffer.toString("base64");
    const imgMime = mimeType as
      | "image/jpeg"
      | "image/png"
      | "image/gif"
      | "image/webp";

    content = [
      {
        type: "image",
        source: { type: "base64", media_type: imgMime, data: base64 },
      },
      { type: "text", text: USER_PROMPT },
    ];
  } else {
    return emptyResult(`Unsupported file type: ${mimeType}`);
  }

  // Call Claude
  const message = await anthropic.messages.create({
    model: "claude-opus-4-5",
    max_tokens: 2048,
    system: SYSTEM_PROMPT,
    messages: [{ role: "user", content }],
  });

  const responseText = (message.content[0] as { type: "text"; text: string })
    .text;
  const cleaned = responseText
    .replace(/```json\n?|```\n?/g, "")
    .trim();

  let parsed: Partial<ExtractionResult>;
  try {
    parsed = JSON.parse(cleaned);
  } catch {
    console.error("[extraction] JSON parse failed:", cleaned.slice(0, 300));
    return emptyResult("AI extraction failed — document may be unclear");
  }

  return {
    labValues: parsed.labValues ?? [],
    medications: parsed.medications ?? [],
    diagnoses: parsed.diagnoses ?? [],
    vitals: parsed.vitals ?? {},
    documentType: parsed.documentType ?? "unknown",
    documentDate: parsed.documentDate,
    labFacility: parsed.labFacility,
    doctorName: parsed.doctorName,
    hospitalName: parsed.hospitalName,
    followUpInstructions: parsed.followUpInstructions ?? [],
    language: parsed.language ?? "english",
    confidence: parsed.confidence ?? 0.5,
    rawText: plaintextOverride,
  };
}

// ── Helpers ─────────────────────────────────────────────────────────
async function extractPdfText(buffer: Buffer): Promise<string> {
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const pdfParse = require("pdf-parse");
    const data = await pdfParse(buffer);
    return data.text ?? "";
  } catch (err) {
    console.error("[extraction] PDF parse error:", err);
    return "";
  }
}

function emptyResult(note: string): ExtractionResult {
  return {
    labValues: [],
    medications: [],
    diagnoses: [],
    vitals: {},
    documentType: "unknown",
    followUpInstructions: [note],
    language: "english",
    confidence: 0,
  };
}

// ── Generate AI Doctor Brief ─────────────────────────────────────────
export type DoctorBriefResult = {
  patientLine: string;
  continuityScore: number;
  urgentFlags: string[];
  recentHighlights: string[];
  riskFlags: string[];
  suggestedActions: string[];
  medicationFlags: string[];
  generatedAt: string;
};

export async function generateDoctorBrief(context: {
  patientName: string;
  age: number;
  gender: string;
  conditions: string[];
  labValues: Array<{
    name: string;
    value: number;
    unit: string;
    status: string;
    date: string;
  }>;
  medications: Array<{ name: string; dose?: string; frequency?: string }>;
  alerts: Array<{ severity: string; title: string }>;
  documentCount: number;
}): Promise<DoctorBriefResult> {
  const prompt = `You are a senior physician's clinical assistant at a top Indian hospital.
Generate a concise, accurate pre-consultation brief for a doctor who has 3 minutes.
Output ONLY valid JSON — no preamble, no markdown.

PATIENT:
Name: ${context.patientName}, ${context.age}${context.gender.charAt(0)}, Conditions: ${context.conditions.join(", ")}

RECENT LAB VALUES (newest first):
${context.labValues.map((l) => `- ${l.name}: ${l.value} ${l.unit} [${l.status}] on ${l.date}`).join("\n")}

ACTIVE MEDICATIONS:
${context.medications.map((m) => `- ${m.name} ${m.dose ?? ""} ${m.frequency ?? ""}`).join("\n")}

ACTIVE ALERTS:
${context.alerts.map((a) => `- [${a.severity}] ${a.title}`).join("\n") || "None"}

RECORDS: ${context.documentCount} documents

Generate brief:
{
  "patientLine": "One-line clinical snapshot with age, conditions, control status",
  "continuityScore": 74,
  "urgentFlags": ["[URGENT] ... (flag critical issues)"],
  "recentHighlights": ["... (top 3-5 clinical events last 90 days)"],
  "riskFlags": ["... (worsening trends, borderline values)"],
  "suggestedActions": ["... (specific tests, referrals, med changes)"],
  "medicationFlags": ["... (interactions, overdue refills, dose concerns)"]
}

Rules:
- Never diagnose — flag patterns for doctor judgment
- Cite specific values and dates
- Use [URGENT] prefix for anything needing same-visit attention
- If data sparse, say so — never fabricate
- Be direct, not verbose`;

  const message = await anthropic.messages.create({
    model: "claude-opus-4-5",
    max_tokens: 1000,
    system:
      "You are a clinical documentation specialist. Output only valid JSON, no preamble.",
    messages: [{ role: "user", content: prompt }],
  });

  const raw = (message.content[0] as { text: string }).text;
  const cleaned = raw.replace(/```json\n?|```\n?/g, "").trim();
  const parsed = JSON.parse(cleaned);

  return {
    ...parsed,
    generatedAt: new Date().toISOString(),
  };
}
