#!/bin/bash

# SwasthAI Quick Start Testing Script
# Sets up dev environment and enables admin bypass for testing

set -e

echo "🏥 SwasthAI Quick Start"
echo "======================="
echo ""

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
  echo "❌ Error: package.json not found. Please run from project root."
  exit 1
fi

echo "✓ Found project root"
echo ""

# Step 1: Setup .env.local
echo "1️⃣  Setting up environment..."

if [ -f ".env.local" ]; then
  echo "   ⚠️  .env.local already exists"
  read -p "   Overwrite? (y/n) " -n 1 -r
  echo
  if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "   Using existing .env.local"
  else
    cp .env.example .env.local
    echo "   ✓ .env.local reset from example"
  fi
else
  cp .env.example .env.local
  echo "   ✓ Created .env.local from example"
fi

# Enable admin bypass
if grep -q "DEV_ADMIN_BYPASS=" .env.local; then
  # Replace existing value
  if [[ "$OSTYPE" == "darwin"* ]]; then
    sed -i '' 's/^DEV_ADMIN_BYPASS=.*/DEV_ADMIN_BYPASS=true/' .env.local
  else
    sed -i 's/^DEV_ADMIN_BYPASS=.*/DEV_ADMIN_BYPASS=true/' .env.local
  fi
else
  # Add new line
  echo 'DEV_ADMIN_BYPASS=true' >> .env.local
fi

echo "   ✓ DEV_ADMIN_BYPASS=true"
echo ""

# Step 2: Check Node.js
echo "2️⃣  Checking dependencies..."
if ! command -v node &> /dev/null; then
  echo "   ❌ Node.js not found. Please install Node.js 18+"
  exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
  echo "   ❌ Node.js 18+ required (you have $NODE_VERSION)"
  exit 1
fi

echo "   ✓ Node.js $(node -v)"
echo ""

# Step 3: Install/update dependencies
echo "3️⃣  Installing dependencies..."
npm install > /dev/null 2>&1 || true
echo "   ✓ Dependencies ready"
echo ""

# Step 4: Build project
echo "4️⃣  Building project..."
npm run build > /dev/null 2>&1
echo "   ✓ Build successful"
echo ""

# Step 5: Create test document
echo "5️⃣  Creating sample test document..."
SAMPLE_DOC=".data/sample-report.txt"
mkdir -p "$(dirname "$SAMPLE_DOC")"
cat > "$SAMPLE_DOC" << 'EOF'
BLOOD TEST REPORT
Date: 2024-04-19
Patient: Test Patient
Facility: City Diagnostics

TEST RESULTS
============

Glucose Fasting: 165 mg/dL [HIGH]  (Reference: 70-100)
HbA1c: 8.2 % [HIGH]  (Reference: <5.7)
Creatinine: 1.1 mg/dL [NORMAL] (Reference: 0.7-1.3)

NOTES:
Patient shows elevated glucose levels. Recommend follow-up HbA1c
in 3 months. Increase physical activity and monitor diet.
EOF

echo "   ✓ Sample report created at $SAMPLE_DOC"
echo ""

# Step 6: Summary and next steps
echo "✅ Setup Complete!"
echo ""
echo "════════════════════════════════════════════════════════"
echo ""
echo "🚀 To start testing:"
echo ""
echo "   npm run dev"
echo ""
echo "   Then open: http://localhost:3000/product-v2"
echo ""
echo "📚 For detailed testing guide, see: TESTING_GUIDE.md"
echo ""
echo "🔐 Admin bypass enabled:"
echo "   - User ID: dev-admin-user"
echo "   - Email: admin@local.test"
echo "   - Can access product without login"
echo ""
echo "📁 Sample test document:"
echo "   - Location: .data/sample-report.txt"
echo "   - Upload this when testing document ingestion"
echo ""
echo "💡 Test Flow:"
echo "   1. Start dev server (npm run dev)"
echo "   2. Navigate to /product-v2"
echo "   3. Upload sample report"
echo "   4. Ingest WhatsApp text"
echo "   5. Ingest audio transcript"
echo "   6. View dashboard stats"
echo "   7. Check old /product page for full extraction details"
echo ""
echo "════════════════════════════════════════════════════════"
echo ""
