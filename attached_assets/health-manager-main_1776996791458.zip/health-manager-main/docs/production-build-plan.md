# SwasthAI Production Build Plan

Date: 18 Apr 2026

## Status snapshot (latest)

Completed in codebase since initial plan:
- Consent management v1 (grant/list/revoke + immutable consent events).
- Care reminders v1 (task lifecycle + immutable task events).
- Duplicate test prevention v1 (lookback rules + recommendations + history).
- Family delegation v1 (family profiles + delegated caregiver access/events).
- WhatsApp + audio ingestion v1 (channel endpoints + source metadata).
- Multilingual channel text normalization v1 (Indic digit normalization + Hindi/English medical term cleanup + confidence metadata in `sourceContext`).

Now the next major production gaps are:
- Image OCR pipeline for photographed reports/prescriptions.
- Async worker queue + retries for extraction/normalization/risk jobs.
- Emergency access package (token/QR + scoped critical summary).
- Clinical explainability citations in doctor brief UI.

This document aligns three sources:
- `docs/claude.md`
- `docs/india_health_ai_deepdive.html`
- current implemented code in `swasthai-next`

## 1) What is already built (working foundation)

### A. Secure collaboration workspace
- Supabase auth-protected product access.
- Workspace persistence with PostgreSQL + Prisma.
- Role-based members (`OWNER`, `EDITOR`, `VIEWER`).
- Invite lifecycle: create, accept, revoke, resend.

### B. Clinical document pipeline v1
- Upload/list clinical documents.
- Store file metadata + extraction jobs.
- Extract structured content from PDF/text.
- Persist extraction output for downstream analysis.

### C. Clinical normalization v1
- Normalize extracted labs against reference ranges.
- Persist normalized lab values with status (`NORMAL`, `LOW`, `HIGH`, `CRITICAL`).
- Expose normalized labs and reference ranges through APIs.

### D. Trend + risk engine v1
- Detect trends (improving/stable/worsening).
- Compute risk levels (`LOW` → `CRITICAL`) for key categories.
- Generate clinical alerts from risk/trend conditions.

### E. Clinical dashboard + doctor brief integration
- `/product` dashboard shows:
  - overall risk
  - top risk categories
  - worsening trends
  - active/acknowledged/resolved alerts
- `buildDoctorBrief` is now risk-aware using clinical summary context.

### F. Alert lifecycle + governance trail
- Alert actions: acknowledge/resolve.
- Immutable alert event timeline (`CREATED`, `ACKNOWLEDGED`, `RESOLVED`).
- Actor enrichment (human-readable actor labels).
- Timeline filters (`action/from/to`).
- Timeline exports: copy, JSON, CSV.
- Timeline pagination: `page`, `pageSize`, response metadata.

## 2) End-to-end flow currently available

1. User signs in and creates/loads a workspace.
2. Team members are invited and granted role-based access.
3. Clinical documents are uploaded into workspace.
4. Extraction pipeline parses report text and key values.
5. Lab normalization applies reference ranges and flags abnormalities.
6. Trend engine tracks longitudinal movement of values.
7. Risk engine computes category risk scores.
8. Alert engine creates actionable alerts.
9. Doctor brief + dashboard surface summarized context.
10. Clinicians/caregivers acknowledge/resolve alerts with auditable history.

## 3) What we intended to build (from Claude + deep dive)

Target vision: **SwasthAI = living health memory + care navigator for India**.

Core experience promised:
- ingest from all channels (PDF/image/WhatsApp/audio)
- build complete longitudinal health map
- produce doctor-ready pre-consult brief
- detect risk patterns early
- prevent duplicate tests
- support family/caregiver workflows
- enforce consented sharing with auditable trust layer
- operate in multilingual, mobile-first Indian workflows

## 4) Gap between current build and target product

### Product gaps
- No true family account graph (dependent profiles with shared permissions).
- No reminders engine (medication, retest, follow-up schedules).
- No duplicate test recommendation engine in patient UX.
- No specialty-aware consult mode with visit intent and checklist.
- No emergency access card/token workflow.
- No multilingual and voice-first clinical UX yet.

### Integration gaps
- No production WhatsApp ingestion connector.
- No ABHA/ABDM data exchange integration yet.
- No insurer/employer analytics module (consented anonymized cohorts).

### Trust, safety, compliance gaps
- No explicit patient consent object model and share policy lifecycle in product flow.
- No trust-plane receipts integration (hash/attestation events).
- Need stronger explainability UI: source citations for each AI claim.
- Need clinical safety policy layer (guardrails + escalation + human override traces).

### Platform engineering gaps
- No background queue workers for ingestion/analysis at scale.
- No SLO-grade observability stack (metrics/traces/audit dashboards).
- No full rate-limit/abuse controls for production internet traffic.
- Need backup/restore drills, key management hardening, data retention policies.

## 5) Production architecture target (v1.0)

### Data plane (off-chain PHI)
- Encrypted object storage for documents/media.
- PostgreSQL for structured timeline entities.
- Background job queue for extraction/normalization/risk jobs.
- Search/retrieval index for doctor brief grounding.

### Intelligence plane
- OCR + document parsing + optional ASR.
- Clinical extraction + normalization + trend/risk scoring.
- Explainable summarization with source links.
- Rules + model hybrid for deterministic safety checks.

### Trust plane
- Consent receipts and access attestations (tamper-evident).
- Integrity hash registry for shared summaries/doc bundles.
- Revocation events and verifiable share history.

### Experience plane
- Patient app: timeline, reminders, alerts, share controls.
- Doctor view: pre-consult brief + trend/risk explainability.
- Caregiver view: family dashboard and delegated workflows.

## 6) 90-day production execution roadmap

## Sprint 1 (Weeks 1–2): Consent + sharing contract
- Add consent domain models:
  - `ConsentGrant`, `ConsentReceipt`, `SharedArtifact`
- APIs:
  - create/revoke consent
  - list active consents
  - issue signed share link with scope/time-bound expiry
- UI:
  - consent management panel in `/product`
- Done when:
  - every share action is traceable and revocable.

## Sprint 2 (Weeks 3–4): Reminder and care-plan engine
- Models:
  - `CarePlanTask`, `ReminderRule`, `ReminderEvent`
- Logic:
  - create retest/follow-up reminders from alert and trend conditions
- UX:
  - patient/caregiver reminder board and status actions
- Done when:
  - user can track what to do next and when.

## Sprint 3 (Weeks 5–6): Duplicate test prevention
- Rules:
  - test recency windows by test type and severity context
- API:
  - duplicate test check endpoint before upload/order
- UX:
  - “already done recently” warning with prior value/date/source
- Done when:
  - duplicate test warnings are generated with explainability.

## Sprint 4 (Weeks 7–8): Family accounts + delegated care
- Models:
  - `FamilyProfile`, `DependentProfile`, `DelegatedAccess`
- UX:
  - switch between self and dependents
  - caregiver-level notifications
- Done when:
  - one account can safely manage multiple family members.

## Sprint 5 (Weeks 9–10): Ingestion channels expansion
- Add WhatsApp ingestion connector abstraction.
- Add audio note ingestion (ASR + extraction).
- Done when:
  - reports arrive from user-native channels, not only manual upload.

## Sprint 6 (Weeks 11–12): Production hardening
- Add queue workers and retries for async jobs.
- Add observability dashboards + SLOs.
- Add security controls and runbook docs.
- Done when:
  - system can handle real pilot load with auditable reliability.

## 7) Metrics to prove product-market and clinical value

### Continuity metrics
- % users with 3+ documents linked chronologically.
- Time-to-first-useful-insight after signup.

### Clinical workflow metrics
- Doctor prep time saved per consult.
- Alert acknowledgment/resolution turnaround.

### Economic metrics
- Duplicate test warnings issued.
- % warnings acted upon.
- Estimated avoided duplicate spend per active user.

### Engagement and retention
- 30/60/90-day retention for chronic users.
- Family profile expansion rate.

## 8) Immediate next build ticket (start now)

**Ticket: Consent management v1**

Scope:
- DB schema for consent grants + receipts.
- Workspace APIs for create/revoke/list consent.
- Minimal consent panel UI in `/product`.
- Audit timeline entries for consent events.

Acceptance criteria:
- user can grant scoped sharing (who/what/how-long)
- user can revoke active sharing
- every consent action appears in immutable event log
- role rules enforced (`VIEWER` cannot manage consent)

---

Positioning recap:

`SwasthAI gives every patient a living health memory and every doctor the right context before the consult, with consent and auditability by default.`
