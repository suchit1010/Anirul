# SwasthAI Merged Strategy (Claude + Copilot)

Date: 17 Apr 2026

This document is the canonical merge of:
- `docs/claude.md`
- the follow-up strategy recommendations in chat

It explicitly shows what we **kept**, **changed**, and **why**.

---

## 1) Core Thesis Alignment

### Kept (from Claude)
- India healthcare’s primary failure mode is **context fragmentation**, not doctor quality.
- The highest leverage product is an **AI intelligence layer** over existing records.
- Patient value is immediate if we can provide:
  - universal ingestion (PDF/photo/WhatsApp)
  - longitudinal health timeline
  - pre-consult doctor brief
  - proactive pattern flags
- Price sensitivity is real; India-native pricing (e.g., `₹99/month`) is valid for B2C.

### Strengthened (in merge)
- Added explicit execution wedge: start with **chronic care continuity** (`diabetes + hypertension`) for faster proof.
- Added risk controls: AI must be assistive, explainable, and clinician-overridable.
- Added infra realism: production-grade reliability/security is required to win trust and judges.

---

## 2) Product Scope: Claude vs Merged

### Claude Direction
Build broad "SwasthAI" with full family intelligence, timeline, doctor brief, alerts, and large multi-sided flywheel.

### Merged Direction (Final)
Build the same vision, but in phased sequence:

#### Phase A (Hackathon-winning MVP)
- Ingestion: report/prescription upload (image/PDF/WhatsApp)
- Structured timeline: meds, labs, diagnoses, visits
- Doctor brief: 1-page specialty-aware summary
- Trend/risk nudges: e.g., HbA1c/BP drift
- Duplicate test detector
- Consented sharing + auditable access receipts

#### Phase B (Post-hackathon scale)
- Family account orchestration
- Medication interaction alerts
- Emergency access mode
- Deeper multilingual voice workflows
- Employer/insurer cohort analytics

Why: wins the hackathon while reducing execution risk.

---

## 3) Solana Role: Exact Decision

### Kept concept
Use blockchain for trust and interoperability.

### Changed/Clarified (critical)
**Do not store PHI on-chain.**

### Solana is used for
- Consent receipts (who shared what, with whom, when)
- Access attestation logs (tamper-evident audit trail)
- Integrity proofs (hashes of off-chain documents/summaries)
- Revocation events and policy state

### Solana is NOT used for
- Raw reports, prescriptions, diagnostics, conversations
- Mutable clinical records requiring correction/deletion
- Latency-sensitive clinical transactions

Why: privacy/compliance + enterprise adoption + practical architecture.

---

## 4) Architecture Merge (Production-Ready)

### Off-chain (health data plane)
- Encrypted object store: documents and media
- Relational DB: patient timeline + clinical entities
- Search index: retrieval for doctor brief and QA
- AI pipeline:
  - OCR/ASR
  - extraction + normalization
  - timeline linking
  - summary generation
  - trend/risk checks

### On-chain (trust plane)
- Consent contract/events
- Access attestation events
- Integrity hash registry

### Integration plane
- ABDM/ABHA connectors (where available)
- Dune SIM + GoldRush integrations for bounty requirements

---

## 5) Business Model Merge

### Kept from Claude
- Multi-sided model can become a strong moat.
- `₹99/month` anchor is compelling for B2C.

### Sequenced in merge
#### Stage 1 (Revenue-first)
- B2B clinic SaaS (`₹5k–₹25k/month` per clinic)
- Core promise: better consult prep + fewer duplicate tests + better follow-up

#### Stage 2 (Consumer expansion)
- B2C premium (`₹99–₹299/month`) for families and proactive care

#### Stage 3 (Enterprise data products)
- Employer/insurer cohort intelligence (anonymized + consent-governed)

Why: de-risks adoption and compliance while building long-term moat.

---

## 6) What We Explicitly Changed from Claude Notes

1. **From broad immediate rollout → wedge-first rollout**
   - Reason: shipping probability and demo quality in hackathon window.

2. **From implicit blockchain usage → constrained blockchain usage**
   - Reason: PHI safety, legal defensibility, adoption realism.

3. **From narrative-heavy moat claim → measurable moat path**
   - Reason: judges/investors prefer proof: retention, integrations, outcomes.

4. **From generic LLM framing → clinical safety framing**
   - Reason: healthcare AI requires trust, explainability, and guardrails.

---

## 7) Final Canonical Build Direction (Use This)

Build `SwasthAI` as:
- **AI continuity layer for Indian healthcare**
- **Off-chain PHI + on-chain trust receipts**
- **Clinic-first chronic-care wedge**, then family and payer expansion

### Non-negotiables
- AI assistive only (no autonomous diagnosis claims)
- Consent-first sharing model
- Source-grounded summaries
- Auditability by default
- India-first UX: multilingual, WhatsApp-friendly, low-friction

---

## 8) Hackathon Win Mapping

### Colosseum Main
- Massive real-world pain + startup-grade product + believable GTM.

### Dune SIM bounty
- Demonstrate explicit SIM endpoint usage in ingestion/event/timeline updates and webhook-triggered alerts.

### GoldRush bounty
- Demonstrate structured/classified data usage for risk/trend scoring and explainable summary generation.

---

## 9) Immediate Next Build Decisions

1. Lock v1 use case: `diabetes + hypertension` continuity.
2. Freeze data schema for timeline entities.
3. Implement consent + audit receipt flow (Solana trust plane).
4. Build doctor brief v1 and duplicate test checker.
5. Prepare demo with before/after measurable outcomes.

---

## 10) One-Line Positioning

`SwasthAI gives every Indian patient a living health memory and gives every doctor the right context before the consult.`
