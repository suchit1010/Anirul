-- CreateEnum
CREATE TYPE "ConsentStatus" AS ENUM ('ACTIVE', 'REVOKED', 'EXPIRED');

-- CreateEnum
CREATE TYPE "ConsentEventAction" AS ENUM ('CREATED', 'REVOKED', 'EXPIRED');

-- CreateTable
CREATE TABLE "ConsentGrant" (
    "id" TEXT NOT NULL,
    "workspaceId" TEXT NOT NULL,
    "grantedById" TEXT NOT NULL,
    "subjectName" TEXT NOT NULL,
    "subjectContact" TEXT NOT NULL,
    "purpose" TEXT NOT NULL,
    "scopes" TEXT[],
    "status" "ConsentStatus" NOT NULL DEFAULT 'ACTIVE',
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "revokedAt" TIMESTAMP(3),
    "revokeReason" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ConsentGrant_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ConsentEvent" (
    "id" TEXT NOT NULL,
    "consentId" TEXT NOT NULL,
    "workspaceId" TEXT NOT NULL,
    "action" "ConsentEventAction" NOT NULL,
    "actorUserId" TEXT,
    "actorDisplay" TEXT,
    "note" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ConsentEvent_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "ConsentGrant_workspaceId_idx" ON "ConsentGrant"("workspaceId");

-- CreateIndex
CREATE INDEX "ConsentGrant_grantedById_idx" ON "ConsentGrant"("grantedById");

-- CreateIndex
CREATE INDEX "ConsentGrant_status_idx" ON "ConsentGrant"("status");

-- CreateIndex
CREATE INDEX "ConsentGrant_expiresAt_idx" ON "ConsentGrant"("expiresAt");

-- CreateIndex
CREATE INDEX "ConsentEvent_consentId_idx" ON "ConsentEvent"("consentId");

-- CreateIndex
CREATE INDEX "ConsentEvent_workspaceId_idx" ON "ConsentEvent"("workspaceId");

-- CreateIndex
CREATE INDEX "ConsentEvent_action_idx" ON "ConsentEvent"("action");

-- CreateIndex
CREATE INDEX "ConsentEvent_createdAt_idx" ON "ConsentEvent"("createdAt");

-- AddForeignKey
ALTER TABLE "ConsentGrant" ADD CONSTRAINT "ConsentGrant_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES "Workspace"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ConsentGrant" ADD CONSTRAINT "ConsentGrant_grantedById_fkey" FOREIGN KEY ("grantedById") REFERENCES "UserProfile"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ConsentEvent" ADD CONSTRAINT "ConsentEvent_consentId_fkey" FOREIGN KEY ("consentId") REFERENCES "ConsentGrant"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ConsentEvent" ADD CONSTRAINT "ConsentEvent_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES "Workspace"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ConsentEvent" ADD CONSTRAINT "ConsentEvent_actorUserId_fkey" FOREIGN KEY ("actorUserId") REFERENCES "UserProfile"("id") ON DELETE SET NULL ON UPDATE CASCADE;
