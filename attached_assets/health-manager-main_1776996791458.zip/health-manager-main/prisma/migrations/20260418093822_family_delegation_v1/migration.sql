-- CreateEnum
CREATE TYPE "FamilyRelation" AS ENUM ('SELF', 'SPOUSE', 'CHILD', 'PARENT', 'SIBLING', 'OTHER');

-- CreateEnum
CREATE TYPE "FamilyAccessRole" AS ENUM ('MANAGER', 'VIEWER');

-- CreateEnum
CREATE TYPE "FamilyAccessStatus" AS ENUM ('ACTIVE', 'REVOKED');

-- CreateEnum
CREATE TYPE "FamilyAccessEventAction" AS ENUM ('GRANTED', 'REVOKED');

-- CreateTable
CREATE TABLE "FamilyProfile" (
    "id" TEXT NOT NULL,
    "workspaceId" TEXT NOT NULL,
    "fullName" TEXT NOT NULL,
    "ageYears" INTEGER,
    "sex" TEXT,
    "relation" "FamilyRelation" NOT NULL DEFAULT 'OTHER',
    "notes" TEXT,
    "createdById" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "FamilyProfile_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "FamilyAccess" (
    "id" TEXT NOT NULL,
    "workspaceId" TEXT NOT NULL,
    "profileId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "role" "FamilyAccessRole" NOT NULL DEFAULT 'VIEWER',
    "status" "FamilyAccessStatus" NOT NULL DEFAULT 'ACTIVE',
    "grantedById" TEXT NOT NULL,
    "revokedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "FamilyAccess_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "FamilyAccessEvent" (
    "id" TEXT NOT NULL,
    "workspaceId" TEXT NOT NULL,
    "profileId" TEXT NOT NULL,
    "accessId" TEXT NOT NULL,
    "action" "FamilyAccessEventAction" NOT NULL,
    "actorUserId" TEXT,
    "actorDisplay" TEXT,
    "note" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "FamilyAccessEvent_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "FamilyProfile_workspaceId_idx" ON "FamilyProfile"("workspaceId");

-- CreateIndex
CREATE INDEX "FamilyProfile_relation_idx" ON "FamilyProfile"("relation");

-- CreateIndex
CREATE INDEX "FamilyAccess_workspaceId_idx" ON "FamilyAccess"("workspaceId");

-- CreateIndex
CREATE INDEX "FamilyAccess_userId_idx" ON "FamilyAccess"("userId");

-- CreateIndex
CREATE INDEX "FamilyAccess_status_idx" ON "FamilyAccess"("status");

-- CreateIndex
CREATE UNIQUE INDEX "FamilyAccess_profileId_userId_key" ON "FamilyAccess"("profileId", "userId");

-- CreateIndex
CREATE INDEX "FamilyAccessEvent_workspaceId_idx" ON "FamilyAccessEvent"("workspaceId");

-- CreateIndex
CREATE INDEX "FamilyAccessEvent_profileId_idx" ON "FamilyAccessEvent"("profileId");

-- CreateIndex
CREATE INDEX "FamilyAccessEvent_accessId_idx" ON "FamilyAccessEvent"("accessId");

-- CreateIndex
CREATE INDEX "FamilyAccessEvent_action_idx" ON "FamilyAccessEvent"("action");

-- CreateIndex
CREATE INDEX "FamilyAccessEvent_createdAt_idx" ON "FamilyAccessEvent"("createdAt");

-- AddForeignKey
ALTER TABLE "FamilyProfile" ADD CONSTRAINT "FamilyProfile_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES "Workspace"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "FamilyProfile" ADD CONSTRAINT "FamilyProfile_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "UserProfile"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "FamilyAccess" ADD CONSTRAINT "FamilyAccess_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES "Workspace"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "FamilyAccess" ADD CONSTRAINT "FamilyAccess_profileId_fkey" FOREIGN KEY ("profileId") REFERENCES "FamilyProfile"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "FamilyAccess" ADD CONSTRAINT "FamilyAccess_userId_fkey" FOREIGN KEY ("userId") REFERENCES "UserProfile"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "FamilyAccess" ADD CONSTRAINT "FamilyAccess_grantedById_fkey" FOREIGN KEY ("grantedById") REFERENCES "UserProfile"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "FamilyAccessEvent" ADD CONSTRAINT "FamilyAccessEvent_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES "Workspace"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "FamilyAccessEvent" ADD CONSTRAINT "FamilyAccessEvent_profileId_fkey" FOREIGN KEY ("profileId") REFERENCES "FamilyProfile"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "FamilyAccessEvent" ADD CONSTRAINT "FamilyAccessEvent_accessId_fkey" FOREIGN KEY ("accessId") REFERENCES "FamilyAccess"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "FamilyAccessEvent" ADD CONSTRAINT "FamilyAccessEvent_actorUserId_fkey" FOREIGN KEY ("actorUserId") REFERENCES "UserProfile"("id") ON DELETE SET NULL ON UPDATE CASCADE;
