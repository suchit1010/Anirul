-- CreateTable
CREATE TABLE "DuplicateTestCheck" (
    "id" TEXT NOT NULL,
    "workspaceId" TEXT NOT NULL,
    "patientId" TEXT,
    "requestedLabName" TEXT NOT NULL,
    "normalizedLabName" TEXT NOT NULL,
    "requestedById" TEXT NOT NULL,
    "lookbackDays" INTEGER NOT NULL DEFAULT 90,
    "isDuplicate" BOOLEAN NOT NULL DEFAULT false,
    "recommendation" TEXT NOT NULL,
    "rationale" TEXT NOT NULL,
    "recentTestDate" TIMESTAMP(3),
    "recentTestValue" DOUBLE PRECISION,
    "recentTestStatus" "LabValueStatus",
    "requestedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "DuplicateTestCheck_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "DuplicateTestCheck_workspaceId_idx" ON "DuplicateTestCheck"("workspaceId");

-- CreateIndex
CREATE INDEX "DuplicateTestCheck_patientId_idx" ON "DuplicateTestCheck"("patientId");

-- CreateIndex
CREATE INDEX "DuplicateTestCheck_requestedLabName_idx" ON "DuplicateTestCheck"("requestedLabName");

-- CreateIndex
CREATE INDEX "DuplicateTestCheck_isDuplicate_idx" ON "DuplicateTestCheck"("isDuplicate");

-- CreateIndex
CREATE INDEX "DuplicateTestCheck_requestedAt_idx" ON "DuplicateTestCheck"("requestedAt");

-- AddForeignKey
ALTER TABLE "DuplicateTestCheck" ADD CONSTRAINT "DuplicateTestCheck_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES "Workspace"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DuplicateTestCheck" ADD CONSTRAINT "DuplicateTestCheck_requestedById_fkey" FOREIGN KEY ("requestedById") REFERENCES "UserProfile"("id") ON DELETE CASCADE ON UPDATE CASCADE;
