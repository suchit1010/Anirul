-- CreateEnum
CREATE TYPE "LabValueStatus" AS ENUM ('NORMAL', 'LOW', 'HIGH', 'CRITICAL');

-- CreateTable
CREATE TABLE "NormalizedLabValue" (
    "id" TEXT NOT NULL,
    "workspaceId" TEXT NOT NULL,
    "patientId" TEXT,
    "testDate" TIMESTAMP(3) NOT NULL,
    "labName" TEXT NOT NULL,
    "rawValue" TEXT NOT NULL,
    "value" DOUBLE PRECISION NOT NULL,
    "unit" TEXT NOT NULL,
    "referenceRangeMin" DOUBLE PRECISION,
    "referenceRangeMax" DOUBLE PRECISION,
    "status" "LabValueStatus" NOT NULL DEFAULT 'NORMAL',
    "ageYears" INTEGER,
    "sex" TEXT,
    "populationGroup" TEXT NOT NULL DEFAULT 'INDIAN_ADULT',
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "NormalizedLabValue_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "LabReferenceRange" (
    "id" TEXT NOT NULL,
    "labName" TEXT NOT NULL,
    "unit" TEXT NOT NULL,
    "populationGroup" TEXT NOT NULL DEFAULT 'INDIAN_ADULT',
    "sexSpecific" BOOLEAN NOT NULL DEFAULT false,
    "sexValue" TEXT,
    "ageMin" INTEGER,
    "ageMax" INTEGER,
    "referenceMin" DOUBLE PRECISION NOT NULL,
    "referenceMax" DOUBLE PRECISION NOT NULL,
    "criticalLow" DOUBLE PRECISION,
    "criticalHigh" DOUBLE PRECISION,
    "source" TEXT NOT NULL DEFAULT 'WHO_India',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "LabReferenceRange_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "NormalizedLabValue_workspaceId_idx" ON "NormalizedLabValue"("workspaceId");

-- CreateIndex
CREATE INDEX "NormalizedLabValue_patientId_idx" ON "NormalizedLabValue"("patientId");

-- CreateIndex
CREATE INDEX "NormalizedLabValue_labName_idx" ON "NormalizedLabValue"("labName");

-- CreateIndex
CREATE INDEX "NormalizedLabValue_status_idx" ON "NormalizedLabValue"("status");

-- CreateIndex
CREATE INDEX "NormalizedLabValue_testDate_idx" ON "NormalizedLabValue"("testDate");

-- CreateIndex
CREATE INDEX "LabReferenceRange_labName_idx" ON "LabReferenceRange"("labName");

-- CreateIndex
CREATE UNIQUE INDEX "LabReferenceRange_labName_unit_populationGroup_sexValue_age_key" ON "LabReferenceRange"("labName", "unit", "populationGroup", "sexValue", "ageMin", "ageMax");
