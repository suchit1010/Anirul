-- AlterTable
ALTER TABLE "ClinicalAlertRecord" ADD COLUMN     "acknowledgedAt" TIMESTAMP(3),
ADD COLUMN     "acknowledgedById" TEXT;

-- CreateIndex
CREATE INDEX "ClinicalAlertRecord_acknowledgedAt_idx" ON "ClinicalAlertRecord"("acknowledgedAt");
