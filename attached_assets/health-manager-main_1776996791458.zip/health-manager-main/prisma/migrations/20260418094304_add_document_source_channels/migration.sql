-- CreateEnum
CREATE TYPE "DocumentSourceChannel" AS ENUM ('DIRECT_UPLOAD', 'WHATSAPP_FORWARD', 'AUDIO_TRANSCRIPT');

-- AlterTable
ALTER TABLE "WorkspaceDocument" ADD COLUMN     "sourceChannel" "DocumentSourceChannel" NOT NULL DEFAULT 'DIRECT_UPLOAD',
ADD COLUMN     "sourceContext" TEXT;
