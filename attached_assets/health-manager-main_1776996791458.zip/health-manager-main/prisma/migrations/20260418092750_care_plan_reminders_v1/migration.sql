-- CreateEnum
CREATE TYPE "CareTaskStatus" AS ENUM ('PENDING', 'COMPLETED', 'SKIPPED');

-- CreateEnum
CREATE TYPE "CareTaskPriority" AS ENUM ('LOW', 'MODERATE', 'HIGH');

-- CreateEnum
CREATE TYPE "CareTaskSource" AS ENUM ('MANUAL', 'ALERT_FOLLOWUP', 'RISK_FOLLOWUP');

-- CreateEnum
CREATE TYPE "CareTaskAction" AS ENUM ('CREATED', 'COMPLETED', 'SKIPPED', 'REOPENED');

-- CreateTable
CREATE TABLE "CareTask" (
    "id" TEXT NOT NULL,
    "workspaceId" TEXT NOT NULL,
    "patientId" TEXT,
    "title" TEXT NOT NULL,
    "description" TEXT,
    "dueAt" TIMESTAMP(3),
    "priority" "CareTaskPriority" NOT NULL DEFAULT 'MODERATE',
    "status" "CareTaskStatus" NOT NULL DEFAULT 'PENDING',
    "source" "CareTaskSource" NOT NULL DEFAULT 'MANUAL',
    "sourceRefId" TEXT,
    "createdById" TEXT NOT NULL,
    "completedAt" TIMESTAMP(3),
    "completedById" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "CareTask_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CareTaskEvent" (
    "id" TEXT NOT NULL,
    "taskId" TEXT NOT NULL,
    "workspaceId" TEXT NOT NULL,
    "action" "CareTaskAction" NOT NULL,
    "actorUserId" TEXT,
    "actorDisplay" TEXT,
    "note" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "CareTaskEvent_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "CareTask_workspaceId_idx" ON "CareTask"("workspaceId");

-- CreateIndex
CREATE INDEX "CareTask_patientId_idx" ON "CareTask"("patientId");

-- CreateIndex
CREATE INDEX "CareTask_status_idx" ON "CareTask"("status");

-- CreateIndex
CREATE INDEX "CareTask_priority_idx" ON "CareTask"("priority");

-- CreateIndex
CREATE INDEX "CareTask_dueAt_idx" ON "CareTask"("dueAt");

-- CreateIndex
CREATE INDEX "CareTask_createdById_idx" ON "CareTask"("createdById");

-- CreateIndex
CREATE INDEX "CareTaskEvent_taskId_idx" ON "CareTaskEvent"("taskId");

-- CreateIndex
CREATE INDEX "CareTaskEvent_workspaceId_idx" ON "CareTaskEvent"("workspaceId");

-- CreateIndex
CREATE INDEX "CareTaskEvent_action_idx" ON "CareTaskEvent"("action");

-- CreateIndex
CREATE INDEX "CareTaskEvent_createdAt_idx" ON "CareTaskEvent"("createdAt");

-- AddForeignKey
ALTER TABLE "CareTask" ADD CONSTRAINT "CareTask_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES "Workspace"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CareTask" ADD CONSTRAINT "CareTask_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "UserProfile"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CareTask" ADD CONSTRAINT "CareTask_completedById_fkey" FOREIGN KEY ("completedById") REFERENCES "UserProfile"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CareTaskEvent" ADD CONSTRAINT "CareTaskEvent_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES "CareTask"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CareTaskEvent" ADD CONSTRAINT "CareTaskEvent_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES "Workspace"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CareTaskEvent" ADD CONSTRAINT "CareTaskEvent_actorUserId_fkey" FOREIGN KEY ("actorUserId") REFERENCES "UserProfile"("id") ON DELETE SET NULL ON UPDATE CASCADE;
