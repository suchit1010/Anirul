-- CreateEnum
CREATE TYPE "TrendDirection" AS ENUM ('IMPROVING', 'STABLE', 'WORSENING');

-- CreateEnum
CREATE TYPE "RiskLevel" AS ENUM ('LOW', 'MODERATE', 'HIGH', 'CRITICAL');

-- CreateEnum
CREATE TYPE "AlertType" AS ENUM ('CRITICAL_LAB_VALUE', 'ABNORMAL_TREND', 'MULTI_TEST_ABNORMALITY', 'MEDICATION_CONTRAINDICATION', 'AGE_RISK_FACTOR');

-- CreateTable
CREATE TABLE "LabTrend" (
    "id" TEXT NOT NULL,
    "workspaceId" TEXT NOT NULL,
    "patientId" TEXT,
    "labName" TEXT NOT NULL,
    "trend" "TrendDirection" NOT NULL,
    "valueCount" INTEGER NOT NULL,
    "oldestValue" DOUBLE PRECISION NOT NULL,
    "latestValue" DOUBLE PRECISION NOT NULL,
    "referenceMin" DOUBLE PRECISION,
    "referenceMax" DOUBLE PRECISION,
    "daysAnalyzed" INTEGER NOT NULL DEFAULT 90,
    "lastAnalyzedAt" TIMESTAMP(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "LabTrend_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ClinicalRiskScore" (
    "id" TEXT NOT NULL,
    "workspaceId" TEXT NOT NULL,
    "patientId" TEXT,
    "riskCategory" TEXT NOT NULL DEFAULT 'GENERAL',
    "riskLevel" "RiskLevel" NOT NULL,
    "score" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "maxScore" DOUBLE PRECISION NOT NULL DEFAULT 100,
    "contributingFactors" TEXT[],
    "recommendations" TEXT[],
    "expiresAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ClinicalRiskScore_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ClinicalAlertRecord" (
    "id" TEXT NOT NULL,
    "workspaceId" TEXT NOT NULL,
    "patientId" TEXT,
    "alertType" "AlertType" NOT NULL,
    "severity" "RiskLevel" NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "relatedLabs" TEXT[],
    "actionItems" TEXT[],
    "resolvedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ClinicalAlertRecord_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "LabTrend_workspaceId_idx" ON "LabTrend"("workspaceId");

-- CreateIndex
CREATE INDEX "LabTrend_patientId_idx" ON "LabTrend"("patientId");

-- CreateIndex
CREATE INDEX "LabTrend_labName_idx" ON "LabTrend"("labName");

-- CreateIndex
CREATE INDEX "LabTrend_trend_idx" ON "LabTrend"("trend");

-- CreateIndex
CREATE INDEX "ClinicalRiskScore_workspaceId_idx" ON "ClinicalRiskScore"("workspaceId");

-- CreateIndex
CREATE INDEX "ClinicalRiskScore_patientId_idx" ON "ClinicalRiskScore"("patientId");

-- CreateIndex
CREATE INDEX "ClinicalRiskScore_riskCategory_idx" ON "ClinicalRiskScore"("riskCategory");

-- CreateIndex
CREATE INDEX "ClinicalRiskScore_riskLevel_idx" ON "ClinicalRiskScore"("riskLevel");

-- CreateIndex
CREATE INDEX "ClinicalAlertRecord_workspaceId_idx" ON "ClinicalAlertRecord"("workspaceId");

-- CreateIndex
CREATE INDEX "ClinicalAlertRecord_patientId_idx" ON "ClinicalAlertRecord"("patientId");

-- CreateIndex
CREATE INDEX "ClinicalAlertRecord_severity_idx" ON "ClinicalAlertRecord"("severity");

-- CreateIndex
CREATE INDEX "ClinicalAlertRecord_resolvedAt_idx" ON "ClinicalAlertRecord"("resolvedAt");
