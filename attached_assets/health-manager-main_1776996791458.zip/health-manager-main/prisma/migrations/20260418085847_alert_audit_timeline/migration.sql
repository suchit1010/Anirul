-- CreateEnum
CREATE TYPE "ClinicalAlertAction" AS ENUM ('CREATED', 'ACKNOWLEDGED', 'RESOLVED');

-- CreateTable
CREATE TABLE "ClinicalAlertEvent" (
    "id" TEXT NOT NULL,
    "alertId" TEXT NOT NULL,
    "workspaceId" TEXT NOT NULL,
    "patientId" TEXT,
    "action" "ClinicalAlertAction" NOT NULL,
    "actorUserId" TEXT,
    "actorDisplay" TEXT,
    "note" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ClinicalAlertEvent_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "ClinicalAlertEvent_alertId_idx" ON "ClinicalAlertEvent"("alertId");

-- CreateIndex
CREATE INDEX "ClinicalAlertEvent_workspaceId_idx" ON "ClinicalAlertEvent"("workspaceId");

-- CreateIndex
CREATE INDEX "ClinicalAlertEvent_patientId_idx" ON "ClinicalAlertEvent"("patientId");

-- CreateIndex
CREATE INDEX "ClinicalAlertEvent_action_idx" ON "ClinicalAlertEvent"("action");

-- CreateIndex
CREATE INDEX "ClinicalAlertEvent_createdAt_idx" ON "ClinicalAlertEvent"("createdAt");
