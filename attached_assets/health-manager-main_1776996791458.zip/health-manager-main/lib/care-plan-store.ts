import { prisma } from "@/lib/prisma";

export type CareTaskStatusValue = "PENDING" | "COMPLETED" | "SKIPPED";
export type CareTaskPriorityValue = "LOW" | "MODERATE" | "HIGH";
export type CareTaskSourceValue = "MANUAL" | "ALERT_FOLLOWUP" | "RISK_FOLLOWUP";

export type CareTaskSummary = {
  id: string;
  workspaceId: string;
  patientId: string | null;
  title: string;
  description: string | null;
  dueAt: string | null;
  priority: CareTaskPriorityValue;
  status: CareTaskStatusValue;
  source: CareTaskSourceValue;
  sourceRefId: string | null;
  createdById: string;
  completedAt: string | null;
  completedById: string | null;
  createdAt: string;
  updatedAt: string;
};

export type CareTaskEventSummary = {
  id: string;
  taskId: string;
  workspaceId: string;
  action: "CREATED" | "COMPLETED" | "SKIPPED" | "REOPENED";
  actorUserId: string | null;
  actorDisplay: string | null;
  actorLabel: string;
  note: string | null;
  createdAt: string;
};

function mapTaskStatus(status: string): CareTaskStatusValue {
  if (status === "COMPLETED") {
    return "COMPLETED";
  }

  if (status === "SKIPPED") {
    return "SKIPPED";
  }

  return "PENDING";
}

function mapTaskPriority(priority: string): CareTaskPriorityValue {
  if (priority === "LOW") {
    return "LOW";
  }

  if (priority === "HIGH") {
    return "HIGH";
  }

  return "MODERATE";
}

function mapTaskSource(source: string): CareTaskSourceValue {
  if (source === "ALERT_FOLLOWUP") {
    return "ALERT_FOLLOWUP";
  }

  if (source === "RISK_FOLLOWUP") {
    return "RISK_FOLLOWUP";
  }

  return "MANUAL";
}

function mapTask(task: {
  id: string;
  workspaceId: string;
  patientId: string | null;
  title: string;
  description: string | null;
  dueAt: Date | null;
  priority: string;
  status: string;
  source: string;
  sourceRefId: string | null;
  createdById: string;
  completedAt: Date | null;
  completedById: string | null;
  createdAt: Date;
  updatedAt: Date;
}): CareTaskSummary {
  return {
    id: task.id,
    workspaceId: task.workspaceId,
    patientId: task.patientId,
    title: task.title,
    description: task.description,
    dueAt: task.dueAt?.toISOString() ?? null,
    priority: mapTaskPriority(task.priority),
    status: mapTaskStatus(task.status),
    source: mapTaskSource(task.source),
    sourceRefId: task.sourceRefId,
    createdById: task.createdById,
    completedAt: task.completedAt?.toISOString() ?? null,
    completedById: task.completedById,
    createdAt: task.createdAt.toISOString(),
    updatedAt: task.updatedAt.toISOString()
  };
}

export async function createCareTask(input: {
  workspaceId: string;
  createdById: string;
  patientId?: string;
  title: string;
  description?: string;
  dueAt?: Date;
  priority?: CareTaskPriorityValue;
  source?: CareTaskSourceValue;
  sourceRefId?: string;
}) {
  const created = await prisma.careTask.create({
    data: {
      workspaceId: input.workspaceId,
      createdById: input.createdById,
      patientId: input.patientId,
      title: input.title,
      description: input.description,
      dueAt: input.dueAt,
      priority: input.priority ?? "MODERATE",
      source: input.source ?? "MANUAL",
      sourceRefId: input.sourceRefId,
      events: {
        create: {
          workspaceId: input.workspaceId,
          action: "CREATED",
          actorUserId: input.createdById,
          note: "Care task created"
        }
      }
    }
  });

  return mapTask(created);
}

export async function updateCareTaskStatus(input: {
  workspaceId: string;
  taskId: string;
  actorUserId: string;
  action: "complete" | "skip" | "reopen";
  note?: string;
}) {
  const existing = await prisma.careTask.findUnique({ where: { id: input.taskId } });
  if (!existing || existing.workspaceId !== input.workspaceId) {
    return null;
  }

  const now = new Date();
  let nextStatus: "PENDING" | "COMPLETED" | "SKIPPED" = "PENDING";
  let eventAction: "COMPLETED" | "SKIPPED" | "REOPENED" = "REOPENED";

  if (input.action === "complete") {
    nextStatus = "COMPLETED";
    eventAction = "COMPLETED";
  } else if (input.action === "skip") {
    nextStatus = "SKIPPED";
    eventAction = "SKIPPED";
  }

  const [updated] = await prisma.$transaction([
    prisma.careTask.update({
      where: { id: input.taskId },
      data: {
        status: nextStatus,
        completedAt: nextStatus === "COMPLETED" ? now : null,
        completedById: nextStatus === "COMPLETED" ? input.actorUserId : null
      }
    }),
    prisma.careTaskEvent.create({
      data: {
        taskId: input.taskId,
        workspaceId: input.workspaceId,
        action: eventAction,
        actorUserId: input.actorUserId,
        note: input.note || `Task ${eventAction.toLowerCase()}`
      }
    })
  ]);

  return mapTask(updated);
}

export async function listCareTasks(
  workspaceId: string,
  filters?: {
    status?: CareTaskStatusValue | "all";
    patientId?: string;
  }
) {
  const tasks = await prisma.careTask.findMany({
    where: {
      workspaceId,
      patientId: filters?.patientId || undefined,
      ...(filters?.status && filters.status !== "all" ? { status: filters.status } : {})
    },
    orderBy: [{ status: "asc" }, { dueAt: "asc" }, { createdAt: "desc" }]
  });

  const taskIds = tasks.map((task: { id: string }) => task.id);

  const events = taskIds.length
    ? await prisma.careTaskEvent.findMany({
        where: {
          workspaceId,
          taskId: {
            in: taskIds
          }
        },
        orderBy: {
          createdAt: "desc"
        }
      })
    : [];

  const actorIds = Array.from(
    new Set(
      events
        .map((event: { actorUserId: string | null }) => event.actorUserId)
        .filter((value: string | null): value is string => Boolean(value))
    )
  );

  const profiles = actorIds.length
    ? await prisma.userProfile.findMany({
        where: {
          id: {
            in: actorIds
          }
        },
        select: {
          id: true,
          fullName: true,
          email: true
        }
      })
    : [];

  const profileById = new Map<string, { fullName: string | null; email: string | null }>(
    profiles.map((profile: { id: string; fullName: string | null; email: string | null }) => [
      profile.id,
      { fullName: profile.fullName, email: profile.email }
    ])
  );

  return {
    tasks: tasks.map(mapTask),
    events: events.map(
      (event: {
        id: string;
        taskId: string;
        workspaceId: string;
        action: "CREATED" | "COMPLETED" | "SKIPPED" | "REOPENED";
        actorUserId: string | null;
        actorDisplay: string | null;
        note: string | null;
        createdAt: Date;
      }): CareTaskEventSummary => {
        const profile = event.actorUserId ? profileById.get(event.actorUserId) : null;

        return {
          id: event.id,
          taskId: event.taskId,
          workspaceId: event.workspaceId,
          action: event.action,
          actorUserId: event.actorUserId,
          actorDisplay: event.actorDisplay,
          actorLabel:
            profile?.fullName || profile?.email || event.actorDisplay || event.actorUserId || "System",
          note: event.note,
          createdAt: event.createdAt.toISOString()
        };
      }
    )
  };
}
