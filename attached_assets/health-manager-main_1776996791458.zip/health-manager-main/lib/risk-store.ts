/* eslint-disable @typescript-eslint/no-explicit-any */

/**
 * Clinical Risk Store
 * 
 * Persists risk scores, trends, and alerts to database
 * Provides query APIs for clinical dashboards and decision support
 */

import { prisma } from './prisma';
import { calculateAllRiskScores } from './risk-scoring';
import {
  analyzeTrendsForPatient,
} from './trend-detection';
import type { RiskLevel } from './risk-scoring';

/**
 * Calculate and persist risk scores for a patient
 */
export async function calculateAndPersistRiskScores(
  workspaceId: string,
  patientId: string | undefined
) {
  // Get patient's latest lab values
  const since = new Date();
  since.setDate(since.getDate() - 90);

  const labs = await prisma.normalizedLabValue.findMany({
    where: {
      workspaceId,
      patientId: patientId || undefined,
      testDate: { gte: since },
      status: { not: 'NORMAL' }, // Only abnormal labs contribute to risk
    },
    orderBy: { testDate: 'desc' },
    take: 100,
  });

  if (labs.length === 0) {
    return {
      message: 'No abnormal labs to calculate risk',
      scores: [],
    };
  }

  // Calculate risk scores
  const scores = calculateAllRiskScores(labs as any);

  // Persist each score
  const persisted = await Promise.all(
    scores.map((score) =>
      prisma.clinicalRiskScore.create({
        data: {
          workspaceId,
          patientId,
          riskCategory: score.category,
          riskLevel: score.level,
          score: score.score,
          maxScore: score.maxScore,
          contributingFactors: score.contributingFactors,
          recommendations: score.recommendations,
          expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
        },
      })
    )
  );

  return {
    message: `Calculated ${scores.length} risk scores`,
    scores: persisted,
  };
}

/**
 * Get latest risk scores for a patient
 */
export async function getLatestRiskScores(
  workspaceId: string,
  patientId?: string
) {
  const where: any = { workspaceId };
  if (patientId) {
    where.patientId = patientId;
  }

  // Get most recent score per category
  const categories = ['DIABETES', 'CKD', 'CVD', 'LIVER'];

  const scores = await Promise.all(
    categories.map((category) =>
      prisma.clinicalRiskScore.findFirst({
        where: { ...where, riskCategory: category },
        orderBy: { createdAt: 'desc' },
      })
    )
  );

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return scores.filter((s: any) => s !== null);
}

/**
 * Create a clinical alert for abnormal findings
 */
export async function createClinicalAlert(
  workspaceId: string,
  patientId: string | undefined,
  alertType: 'CRITICAL_LAB_VALUE' | 'ABNORMAL_TREND' | 'MULTI_TEST_ABNORMALITY' | 'MEDICATION_CONTRAINDICATION' | 'AGE_RISK_FACTOR',
  severity: RiskLevel,
  title: string,
  description: string,
  relatedLabs: string[] = [],
  actionItems: string[] = []
) {
  return prisma.$transaction(async (tx: any) => {
    const alert = await tx.clinicalAlertRecord.create({
      data: {
        workspaceId,
        patientId,
        alertType,
        severity,
        title,
        description,
        relatedLabs,
        actionItems,
      },
    });

    await tx.clinicalAlertEvent.create({
      data: {
        alertId: alert.id,
        workspaceId,
        patientId,
        action: "CREATED",
        note: "Alert created by risk engine"
      }
    });

    return alert;
  });
}

/**
 * Get active clinical alerts for a workspace/patient
 */
export async function getActiveAlerts(
  workspaceId: string,
  patientId?: string,
  severity?: RiskLevel
) {
  const where: any = {
    workspaceId,
    acknowledgedAt: null,
    resolvedAt: null,
  };

  if (patientId) {
    where.patientId = patientId;
  }

  if (severity) {
    where.severity = severity;
  }

  return prisma.clinicalAlertRecord.findMany({
    where,
    orderBy: { createdAt: 'desc' },
  });
}

/**
 * Acknowledge an alert without resolving it
 */
export async function acknowledgeAlert(alertId: string, acknowledgedById: string) {
  return prisma.$transaction(async (tx: any) => {
    const acknowledged = await tx.clinicalAlertRecord.update({
      where: { id: alertId },
      data: {
        acknowledgedAt: new Date(),
        acknowledgedById
      }
    });

    await tx.clinicalAlertEvent.create({
      data: {
        alertId,
        workspaceId: acknowledged.workspaceId,
        patientId: acknowledged.patientId,
        action: "ACKNOWLEDGED",
        actorUserId: acknowledgedById,
        actorDisplay: acknowledgedById,
        note: "Alert acknowledged"
      }
    });

    return acknowledged;
  });
}

/**
 * Resolve an alert
 */
export async function resolveAlert(alertId: string, resolvedById?: string) {
  return prisma.$transaction(async (tx: any) => {
    const resolved = await tx.clinicalAlertRecord.update({
      where: { id: alertId },
      data: { resolvedAt: new Date() },
    });

    await tx.clinicalAlertEvent.create({
      data: {
        alertId,
        workspaceId: resolved.workspaceId,
        patientId: resolved.patientId,
        action: "RESOLVED",
        actorUserId: resolvedById,
        actorDisplay: resolvedById,
        note: "Alert resolved"
      }
    });

    return resolved;
  });
}

export async function listAlertEvents(
  workspaceId: string,
  alertId: string,
  options?: {
    action?: "CREATED" | "ACKNOWLEDGED" | "RESOLVED";
    from?: Date;
    to?: Date;
    page?: number;
    pageSize?: number;
  }
) {
  const where: any = {
    workspaceId,
    alertId
  };

  if (options?.action) {
    where.action = options.action;
  }

  if (options?.from || options?.to) {
    where.createdAt = {
      ...(options.from ? { gte: options.from } : {}),
      ...(options.to ? { lte: options.to } : {})
    };
  }

  const page = Math.max(1, options?.page ?? 1);
  const pageSize = Math.min(100, Math.max(1, options?.pageSize ?? 10));
  const skip = (page - 1) * pageSize;

  const [total, events] = await prisma.$transaction([
    prisma.clinicalAlertEvent.count({ where }),
    prisma.clinicalAlertEvent.findMany({
      where,
      orderBy: {
        createdAt: "asc"
      },
      skip,
      take: pageSize
    })
  ]);

  const actorIds = Array.from(
    new Set(
      events
        .map((event: any) => event.actorUserId)
        .filter((value: any): value is string => Boolean(value))
    )
  );

  if (actorIds.length === 0) {
    const enrichedEvents = events.map((event: any) => ({
      ...event,
      actorLabel: event.actorDisplay || event.actorUserId || "System"
    }));

    const totalPages = Math.max(1, Math.ceil(total / pageSize));
    return {
      events: enrichedEvents,
      pagination: {
        page,
        pageSize,
        total,
        totalPages,
        hasMore: page < totalPages
      }
    };
  }

  const profiles = await prisma.userProfile.findMany({
    where: {
      id: {
        in: actorIds
      }
    },
    select: {
      id: true,
      fullName: true,
      email: true
    }
  });

  const profileById = new Map<string, { fullName: string | null; email: string | null }>(
    profiles.map((profile: any) => [profile.id, { fullName: profile.fullName, email: profile.email }])
  );

  const enrichedEvents = events.map((event: any) => {
    const profile = event.actorUserId ? profileById.get(event.actorUserId) : null;
    const actorLabel =
      profile?.fullName ||
      profile?.email ||
      event.actorDisplay ||
      event.actorUserId ||
      "System";

    return {
      ...event,
      actorLabel
    };
  });

  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  return {
    events: enrichedEvents,
    pagination: {
      page,
      pageSize,
      total,
      totalPages,
      hasMore: page < totalPages
    }
  };
}

/**
 * Generate comprehensive clinical summary for a patient
 */
export async function generateClinicalSummary(
  workspaceId: string,
  patientId: string,
  ageYears?: number,
  sex?: string
) {
  // Get trends
  const trends = await analyzeTrendsForPatient(workspaceId, patientId, 90);

  // Get risk scores
  const riskScores = await getLatestRiskScores(workspaceId, patientId);

  // Get active alerts
  const alerts = await getActiveAlerts(workspaceId, patientId);

  // Get critical labs
  const criticalLabs = await prisma.normalizedLabValue.findMany({
    where: {
      workspaceId,
      patientId,
      status: 'CRITICAL',
    },
    orderBy: { testDate: 'desc' },
    take: 10,
  });

  const overallRiskLevel = riskScores.length > 0
    ? riskScores.reduce(
        (max: RiskLevel, score: any) => {
          const order: Record<string, number> = { CRITICAL: 4, HIGH: 3, MODERATE: 2, LOW: 1 };
          const maxOrder = order[max] || 0;
          const scoreOrder = order[score.riskLevel] || 0;
          return maxOrder > scoreOrder ? max : (score.riskLevel as RiskLevel);
        },
        'LOW' as RiskLevel
      )
    : 'LOW';

  return {
    patientId,
    ageYears,
    sex,
    summary: {
      totalAbnormalLabs: trends.labTrends?.length || 0,
      worseningTrends: trends.worseningTrends?.length || 0,
      clinicalPatterns: trends.patterns?.length || 0,
      riskCategories: riskScores.length,
      activeAlerts: alerts.length,
      criticalValues: criticalLabs.length,
    },
    overallRiskLevel,
    riskScores,
    trends: {
      worseningTrends: trends.worseningTrends || [],
      improvingTrends: trends.improvingTrends || [],
      patterns: trends.patterns || [],
    },
    alerts: alerts.slice(0, 5), // Top 5 most recent
    criticalLabs: criticalLabs.slice(0, 5),
    recommendations: generateRecommendations(
      riskScores,
      trends.worseningTrends || [],
      alerts
    ),
  };
}

/**
 * Generate clinical recommendations based on risk scores and trends
 */
function generateRecommendations(
  riskScores: any[],
  worseningTrends: any[],
  alerts: any[]
): string[] {
  const recommendations: Set<string> = new Set();

  // Add recommendations from risk scores
  riskScores.forEach((score) => {
    score.recommendations?.forEach((rec: string) => {
      recommendations.add(rec);
    });
  });

  // Add worsening trend recommendations
  if (worseningTrends.length > 0) {
    recommendations.add('Monitor closely - multiple abnormal trends detected');
    if (worseningTrends.length >= 3) {
      recommendations.add('Consider multi-system disease workup');
    }
  }

  // Alert-based recommendations
  alerts.forEach((alert) => {
    alert.actionItems?.forEach((item: string) => {
      recommendations.add(item);
    });
  });

  return Array.from(recommendations).slice(0, 10); // Top 10
}

/**
 * Persist trend analysis results
 */
export async function persistTrendAnalysis(
  workspaceId: string,
  patientId: string,
  trendAnalysis: any
) {
  const trends = await Promise.all(
    trendAnalysis.labTrends.map((trend: any) =>
      prisma.labTrend.create({
        data: {
          workspaceId,
          patientId,
          labName: trend.labName,
          trend: trend.trend.toUpperCase(),
          valueCount: trend.valueCount,
          oldestValue: trend.oldestValue,
          latestValue: trend.latestValue,
          referenceMin: trend.referenceMin,
          referenceMax: trend.referenceMax,
          daysAnalyzed: trend.daysAnalyzed,
          lastAnalyzedAt: new Date(),
        },
      })
    )
  );

  return trends;
}

/**
 * Get patient's risk trajectory over time
 */
export async function getRiskTrajectory(
  workspaceId: string,
  patientId: string,
  category: string,
  days: number = 90
) {
  const since = new Date();
  since.setDate(since.getDate() - days);

  const scores = await prisma.clinicalRiskScore.findMany({
    where: {
      workspaceId,
      patientId,
      riskCategory: category,
      createdAt: { gte: since },
    },
    orderBy: { createdAt: 'asc' },
  });

  if (scores.length === 0) {
    return {
      category,
      message: 'No risk score history available',
      trajectory: null,
    };
  }

  const trajectory = scores.map((s: any) => ({
    date: s.createdAt,
    score: s.score,
    level: s.riskLevel,
  }));

  const trend = scores.length >= 2
    ? scores[scores.length - 1].score > scores[0].score
      ? 'worsening'
      : scores[scores.length - 1].score < scores[0].score
      ? 'improving'
      : 'stable'
    : null;

  return {
    category,
    trajectory,
    trend,
    latest: scores[scores.length - 1],
  };
}
