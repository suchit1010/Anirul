/**
 * Clinical Normalization Engine
 * 
 * Maps extracted lab values to age/sex-adjusted reference ranges
 * and flags abnormalities for risk scoring and clinical decision support.
 * 
 * Reference ranges are based on:
 * - WHO guidelines adapted for Indian populations
 * - ICMR (Indian Council of Medical Research) recommendations
 * - Common clinical lab standards in India
 */

export type LabValueStatus = 'NORMAL' | 'LOW' | 'HIGH' | 'CRITICAL';

export interface LabReferenceRange {
  labName: string;
  unit: string;
  populationGroup: 'INDIAN_ADULT' | 'INDIAN_CHILD' | 'INDIAN_ELDERLY';
  sexSpecific: boolean;
  sex?: 'M' | 'F';
  ageMin?: number;
  ageMax?: number;
  referenceMin: number;
  referenceMax: number;
  criticalLow?: number;
  criticalHigh?: number;
  source: string;
}

export interface NormalizedLabValue {
  labName: string;
  rawValue: string;
  value: number;
  unit: string;
  referenceMin?: number;
  referenceMax?: number;
  status: LabValueStatus;
  ageYears?: number;
  sex?: 'M' | 'F';
  populationGroup: 'INDIAN_ADULT' | 'INDIAN_CHILD' | 'INDIAN_ELDERLY';
  notes?: string;
  testDate: Date;
}

/**
 * Comprehensive reference ranges for Indian populations
 * Based on WHO, ICMR, and common clinical standards
 */
const REFERENCE_RANGES: LabReferenceRange[] = [
  // Glucose
  {
    labName: 'Fasting Glucose',
    unit: 'mg/dL',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: false,
    referenceMin: 70,
    referenceMax: 100,
    criticalLow: 50,
    criticalHigh: 300,
    source: 'ICMR Guidelines',
  },
  {
    labName: 'HbA1c',
    unit: '%',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: false,
    referenceMin: 4.0,
    referenceMax: 5.6,
    criticalLow: 2.0,
    criticalHigh: 15.0,
    source: 'ICMR Diabetes Guidelines',
  },
  {
    labName: 'Random Blood Glucose',
    unit: 'mg/dL',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: false,
    referenceMin: 70,
    referenceMax: 140,
    criticalHigh: 300,
    source: 'WHO Guidelines',
  },

  // Thyroid
  {
    labName: 'TSH',
    unit: 'mIU/L',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: false,
    referenceMin: 0.4,
    referenceMax: 4.0,
    criticalLow: 0.01,
    criticalHigh: 50,
    source: 'WHO Guidelines',
  },
  {
    labName: 'Free T3',
    unit: 'pg/mL',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: false,
    referenceMin: 1.7,
    referenceMax: 3.7,
    source: 'WHO Guidelines',
  },
  {
    labName: 'Free T4',
    unit: 'ng/dL',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: false,
    referenceMin: 0.7,
    referenceMax: 1.9,
    source: 'WHO Guidelines',
  },

  // Lipid Panel
  {
    labName: 'Total Cholesterol',
    unit: 'mg/dL',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: false,
    referenceMin: 0,
    referenceMax: 200,
    criticalHigh: 300,
    source: 'ICMR Cardiovascular Guidelines',
  },
  {
    labName: 'LDL Cholesterol',
    unit: 'mg/dL',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: false,
    referenceMin: 0,
    referenceMax: 130,
    criticalHigh: 200,
    source: 'ICMR Cardiovascular Guidelines',
  },
  {
    labName: 'HDL Cholesterol',
    unit: 'mg/dL',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: true,
    sex: 'M',
    referenceMin: 40,
    referenceMax: 1000,
    source: 'ICMR Cardiovascular Guidelines',
  },
  {
    labName: 'HDL Cholesterol',
    unit: 'mg/dL',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: true,
    sex: 'F',
    referenceMin: 50,
    referenceMax: 1000,
    source: 'ICMR Cardiovascular Guidelines',
  },
  {
    labName: 'Triglycerides',
    unit: 'mg/dL',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: false,
    referenceMin: 0,
    referenceMax: 150,
    criticalHigh: 400,
    source: 'ICMR Cardiovascular Guidelines',
  },

  // Kidney Function
  {
    labName: 'Creatinine',
    unit: 'mg/dL',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: true,
    sex: 'M',
    referenceMin: 0.7,
    referenceMax: 1.3,
    criticalHigh: 4.0,
    source: 'WHO Guidelines',
  },
  {
    labName: 'Creatinine',
    unit: 'mg/dL',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: true,
    sex: 'F',
    referenceMin: 0.5,
    referenceMax: 1.0,
    criticalHigh: 4.0,
    source: 'WHO Guidelines',
  },
  {
    labName: 'BUN',
    unit: 'mg/dL',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: false,
    referenceMin: 7,
    referenceMax: 20,
    criticalHigh: 50,
    source: 'WHO Guidelines',
  },
  {
    labName: 'eGFR',
    unit: 'mL/min/1.73m²',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: false,
    referenceMin: 60,
    referenceMax: 1000,
    criticalLow: 15,
    source: 'KDIGO Guidelines',
  },

  // Liver Function
  {
    labName: 'ALT',
    unit: 'U/L',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: false,
    referenceMin: 7,
    referenceMax: 56,
    criticalHigh: 200,
    source: 'WHO Guidelines',
  },
  {
    labName: 'AST',
    unit: 'U/L',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: false,
    referenceMin: 10,
    referenceMax: 40,
    criticalHigh: 200,
    source: 'WHO Guidelines',
  },
  {
    labName: 'Bilirubin',
    unit: 'mg/dL',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: false,
    referenceMin: 0.1,
    referenceMax: 1.2,
    criticalHigh: 5.0,
    source: 'WHO Guidelines',
  },
  {
    labName: 'Alkaline Phosphatase',
    unit: 'U/L',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: false,
    referenceMin: 30,
    referenceMax: 120,
    criticalHigh: 300,
    source: 'WHO Guidelines',
  },

  // Hemoglobin/Blood Cells
  {
    labName: 'Hemoglobin',
    unit: 'g/dL',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: true,
    sex: 'M',
    referenceMin: 13.5,
    referenceMax: 17.5,
    criticalLow: 7,
    source: 'WHO Guidelines',
  },
  {
    labName: 'Hemoglobin',
    unit: 'g/dL',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: true,
    sex: 'F',
    referenceMin: 12.0,
    referenceMax: 15.5,
    criticalLow: 7,
    source: 'WHO Guidelines',
  },
  {
    labName: 'WBC',
    unit: 'K/uL',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: false,
    referenceMin: 4.5,
    referenceMax: 11.0,
    criticalLow: 2,
    criticalHigh: 30,
    source: 'WHO Guidelines',
  },
  {
    labName: 'Platelet Count',
    unit: 'K/uL',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: false,
    referenceMin: 150,
    referenceMax: 400,
    criticalLow: 50,
    criticalHigh: 1000,
    source: 'WHO Guidelines',
  },

  // Electrolytes
  {
    labName: 'Sodium',
    unit: 'mEq/L',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: false,
    referenceMin: 136,
    referenceMax: 145,
    criticalLow: 120,
    criticalHigh: 160,
    source: 'WHO Guidelines',
  },
  {
    labName: 'Potassium',
    unit: 'mEq/L',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: false,
    referenceMin: 3.5,
    referenceMax: 5.0,
    criticalLow: 2.5,
    criticalHigh: 6.5,
    source: 'WHO Guidelines',
  },
  {
    labName: 'Calcium',
    unit: 'mg/dL',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: false,
    referenceMin: 8.5,
    referenceMax: 10.2,
    criticalLow: 7,
    criticalHigh: 13,
    source: 'WHO Guidelines',
  },
  {
    labName: 'Phosphate',
    unit: 'mg/dL',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: false,
    referenceMin: 2.5,
    referenceMax: 4.5,
    criticalLow: 1,
    criticalHigh: 7,
    source: 'WHO Guidelines',
  },

  // Uric Acid
  {
    labName: 'Uric Acid',
    unit: 'mg/dL',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: true,
    sex: 'M',
    referenceMin: 3.5,
    referenceMax: 7.2,
    source: 'WHO Guidelines',
  },
  {
    labName: 'Uric Acid',
    unit: 'mg/dL',
    populationGroup: 'INDIAN_ADULT',
    sexSpecific: true,
    sex: 'F',
    referenceMin: 2.6,
    referenceMax: 6.0,
    source: 'WHO Guidelines',
  },
];

/**
 * Find the appropriate reference range for a lab value
 * considering age, sex, and population group
 */
function findReferenceRange(
  labName: string,
  unit: string,
  ageYears?: number,
  sex?: 'M' | 'F',
  populationGroup: 'INDIAN_ADULT' | 'INDIAN_CHILD' | 'INDIAN_ELDERLY' = 'INDIAN_ADULT'
): LabReferenceRange | null {
  // Find matching reference ranges
  let candidates = REFERENCE_RANGES.filter(
    (r) =>
      r.labName.toLowerCase() === labName.toLowerCase() &&
      r.unit.toLowerCase() === unit.toLowerCase() &&
      r.populationGroup === populationGroup
  );

  if (candidates.length === 0) return null;

  // If sex-specific ranges exist, prioritize them if sex is provided
  const sexSpecific = candidates.filter((r) => r.sexSpecific);
  if (sexSpecific.length > 0 && sex) {
    candidates = sexSpecific.filter((r) => r.sex === sex);
  } else {
    candidates = candidates.filter((r) => !r.sexSpecific);
  }

  if (candidates.length === 0) return null;
  return candidates[0];
}

/**
 * Determine lab value status based on reference ranges
 */
function determineStatus(
  value: number,
  range: LabReferenceRange
): LabValueStatus {
  if (
    range.criticalLow !== undefined &&
    value < range.criticalLow
  ) {
    return 'CRITICAL';
  }
  if (
    range.criticalHigh !== undefined &&
    value > range.criticalHigh
  ) {
    return 'CRITICAL';
  }
  if (value < range.referenceMin) {
    return 'LOW';
  }
  if (value > range.referenceMax) {
    return 'HIGH';
  }
  return 'NORMAL';
}

/**
 * Normalize a lab value against appropriate reference ranges
 */
export function normalizeLabValue(
  labName: string,
  rawValue: string,
  unit: string,
  testDate: Date,
  ageYears?: number,
  sex?: 'M' | 'F'
): NormalizedLabValue | null {
  // Parse the value
  const value = parseFloat(rawValue);
  if (isNaN(value)) {
    return null;
  }

  // Determine population group
  let populationGroup: 'INDIAN_ADULT' | 'INDIAN_CHILD' | 'INDIAN_ELDERLY' =
    'INDIAN_ADULT';
  if (ageYears !== undefined) {
    if (ageYears < 18) {
      populationGroup = 'INDIAN_CHILD';
    } else if (ageYears >= 65) {
      populationGroup = 'INDIAN_ELDERLY';
    }
  }

  // Find reference range
  const range = findReferenceRange(
    labName,
    unit,
    ageYears,
    sex,
    populationGroup
  );

  if (!range) {
    // Return unannotated value if no reference found
    return {
      labName,
      rawValue,
      value,
      unit,
      status: 'NORMAL',
      ageYears,
      sex,
      populationGroup,
      testDate,
      notes: 'No reference range found for this test',
    };
  }

  const status = determineStatus(value, range);

  return {
    labName,
    rawValue,
    value,
    unit,
    referenceMin: range.referenceMin,
    referenceMax: range.referenceMax,
    status,
    ageYears,
    sex,
    populationGroup,
    testDate,
  };
}

/**
 * Batch normalize multiple lab values
 */
export function normalizeLabValues(
  labs: Array<{
    labName: string;
    rawValue: string;
    unit: string;
    testDate: Date;
    ageYears?: number;
    sex?: 'M' | 'F';
  }>
): NormalizedLabValue[] {
  return labs
    .map((lab) =>
      normalizeLabValue(
        lab.labName,
        lab.rawValue,
        lab.unit,
        lab.testDate,
        lab.ageYears,
        lab.sex
      )
    )
    .filter((result): result is NormalizedLabValue => result !== null);
}

/**
 * Get all abnormal values from a set of normalized labs
 */
export function getAbnormalValues(
  normalized: NormalizedLabValue[]
): NormalizedLabValue[] {
  return normalized.filter((lab) => lab.status !== 'NORMAL');
}

/**
 * Get critical values (for immediate clinical attention)
 */
export function getCriticalValues(
  normalized: NormalizedLabValue[]
): NormalizedLabValue[] {
  return normalized.filter((lab) => lab.status === 'CRITICAL');
}

/**
 * Export reference ranges for API and documentation
 */
export function getAllReferenceRanges(): LabReferenceRange[] {
  return [...REFERENCE_RANGES];
}
