import { createServerClient } from "@supabase/auth-helpers-nextjs";
import { cookies } from "next/headers";

export function createServerSupabase() {
  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL ?? "",
    process.env.SUPABASE_SERVICE_ROLE_KEY ?? "",
    {
      cookies: {
        getAll: async () => {
          const cookieStore = await cookies();
          return cookieStore.getAll().map((cookie) => ({
            name: cookie.name,
            value: cookie.value
          }));
        },
        setAll: async (newCookies) => {
          const cookieStore = await cookies();
          for (const cookie of newCookies) {
            const options = cookie.options ?? {};
            cookieStore.set(cookie.name, cookie.value, options);
          }
        }
      },
      auth: {
        persistSession: true,
        autoRefreshToken: true
      }
    }
  );
}
