import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { prisma } from "@/lib/prisma";
import { extractDocumentContent } from "@/lib/document-ingestion";
import { sanitizeWorkspaceId } from "@/lib/workspace-store";

export type WorkspaceDocumentSummary = {
  id: string;
  workspaceId: string;
  uploadedById: string;
  sourceChannel: "DIRECT_UPLOAD" | "WHATSAPP_FORWARD" | "AUDIO_TRANSCRIPT";
  sourceContext: string | null;
  originalName: string;
  mimeType: string;
  sizeBytes: number;
  status: "UPLOADED" | "PROCESSED" | "FAILED";
  extractionNote: string | null;
  extractedTextPreview: string | null;
  extractedData: unknown;
  createdAt: string;
  updatedAt: string;
};

export type ExtractionJobSummary = {
  id: string;
  documentId: string;
  requestedBy: string;
  status: "QUEUED" | "PROCESSING" | "COMPLETED" | "FAILED";
  error: string | null;
  startedAt: string | null;
  finishedAt: string | null;
  createdAt: string;
  updatedAt: string;
};

const uploadRoot = path.join(process.cwd(), ".data", "uploads");

function sanitizeFileName(name: string): string {
  return name.replace(/[^a-zA-Z0-9._-]/g, "_");
}

function toDocumentSummary(document: {
  id: string;
  workspaceId: string;
  uploadedById: string;
  sourceChannel: string;
  sourceContext: string | null;
  originalName: string;
  mimeType: string;
  sizeBytes: number;
  status: string;
  extractionNote: string | null;
  extractedText: string | null;
  extractedData: unknown;
  createdAt: Date;
  updatedAt: Date;
}): WorkspaceDocumentSummary {
  return {
    id: document.id,
    workspaceId: document.workspaceId,
    uploadedById: document.uploadedById,
    sourceChannel: document.sourceChannel as WorkspaceDocumentSummary["sourceChannel"],
    sourceContext: document.sourceContext,
    originalName: document.originalName,
    mimeType: document.mimeType,
    sizeBytes: document.sizeBytes,
    status: document.status as WorkspaceDocumentSummary["status"],
    extractionNote: document.extractionNote,
    extractedTextPreview: document.extractedText ? document.extractedText.slice(0, 500) : null,
    extractedData: document.extractedData,
    createdAt: document.createdAt.toISOString(),
    updatedAt: document.updatedAt.toISOString()
  };
}

function toJobSummary(job: {
  id: string;
  documentId: string;
  requestedBy: string;
  status: string;
  error: string | null;
  startedAt: Date | null;
  finishedAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}): ExtractionJobSummary {
  return {
    id: job.id,
    documentId: job.documentId,
    requestedBy: job.requestedBy,
    status: job.status as ExtractionJobSummary["status"],
    error: job.error,
    startedAt: job.startedAt?.toISOString() ?? null,
    finishedAt: job.finishedAt?.toISOString() ?? null,
    createdAt: job.createdAt.toISOString(),
    updatedAt: job.updatedAt.toISOString()
  };
}

async function hasWorkspaceAccess(workspaceId: string, userId: string): Promise<boolean> {
  const membership = await prisma.workspaceMember.findFirst({
    where: {
      workspaceId,
      userId
    },
    select: {
      id: true
    }
  });

  return Boolean(membership);
}

export async function listWorkspaceDocuments(
  workspaceId: string,
  userId: string
): Promise<WorkspaceDocumentSummary[] | null> {
  const safeWorkspaceId = sanitizeWorkspaceId(workspaceId);
  const access = await hasWorkspaceAccess(safeWorkspaceId, userId);

  if (!access) {
    return null;
  }

  const documents = await prisma.workspaceDocument.findMany({
    where: {
      workspaceId: safeWorkspaceId
    },
    orderBy: {
      createdAt: "desc"
    }
  });

  return documents.map(toDocumentSummary);
}

export async function uploadWorkspaceDocument(params: {
  workspaceId: string;
  userId: string;
  fileName: string;
  mimeType: string;
  fileBytes: Buffer;
  sourceChannel?: "DIRECT_UPLOAD" | "WHATSAPP_FORWARD" | "AUDIO_TRANSCRIPT";
  sourceContext?: string;
}): Promise<WorkspaceDocumentSummary | null> {
  const safeWorkspaceId = sanitizeWorkspaceId(params.workspaceId);
  const access = await hasWorkspaceAccess(safeWorkspaceId, params.userId);

  if (!access) {
    return null;
  }

  const documentId = `doc_${randomUUID().replace(/-/g, "").slice(0, 20)}`;
  const safeName = sanitizeFileName(params.fileName || "upload.bin");

  await prisma.userProfile.upsert({
    where: { id: params.userId },
    update: {},
    create: { id: params.userId }
  });

  await mkdir(path.join(uploadRoot, safeWorkspaceId), { recursive: true });
  const storagePath = path.join(uploadRoot, safeWorkspaceId, `${documentId}_${safeName}`);
  await writeFile(storagePath, params.fileBytes);

  const document = await prisma.workspaceDocument.create({
    data: {
      id: documentId,
      workspaceId: safeWorkspaceId,
      uploadedById: params.userId,
      sourceChannel: params.sourceChannel ?? "DIRECT_UPLOAD",
      sourceContext: params.sourceContext,
      originalName: params.fileName || "upload.bin",
      mimeType: params.mimeType || "application/octet-stream",
      sizeBytes: params.fileBytes.byteLength,
      storagePath,
      status: "UPLOADED"
    }
  });

  return toDocumentSummary(document);
}

export async function ingestTextChannelDocument(params: {
  workspaceId: string;
  userId: string;
  fileName: string;
  sourceChannel: "WHATSAPP_FORWARD" | "AUDIO_TRANSCRIPT";
  sourceContext?: string;
  textContent: string;
}): Promise<WorkspaceDocumentSummary | null> {
  const created = await uploadWorkspaceDocument({
    workspaceId: params.workspaceId,
    userId: params.userId,
    fileName: params.fileName,
    mimeType: "text/plain",
    fileBytes: Buffer.from(params.textContent, "utf8"),
    sourceChannel: params.sourceChannel,
    sourceContext: params.sourceContext
  });

  if (!created) {
    return null;
  }

  const extracted = await runDocumentExtraction({
    workspaceId: params.workspaceId,
    documentId: created.id,
    userId: params.userId
  });

  if (extracted === "forbidden" || extracted === "not-found") {
    return created;
  }

  return extracted.document;
}

export async function runDocumentExtraction(params: {
  workspaceId: string;
  documentId: string;
  userId: string;
}): Promise<{ document: WorkspaceDocumentSummary; job: ExtractionJobSummary } | "not-found" | "forbidden"> {
  const safeWorkspaceId = sanitizeWorkspaceId(params.workspaceId);
  const access = await hasWorkspaceAccess(safeWorkspaceId, params.userId);

  if (!access) {
    return "forbidden";
  }

  const document = await prisma.workspaceDocument.findFirst({
    where: {
      id: params.documentId,
      workspaceId: safeWorkspaceId
    }
  });

  if (!document) {
    return "not-found";
  }

  await prisma.userProfile.upsert({
    where: { id: params.userId },
    update: {},
    create: { id: params.userId }
  });

  const queuedJob = await prisma.documentExtractionJob.create({
    data: {
      documentId: document.id,
      requestedBy: params.userId,
      status: "QUEUED"
    }
  });

  await prisma.documentExtractionJob.update({
    where: { id: queuedJob.id },
    data: {
      status: "PROCESSING",
      startedAt: new Date(),
      error: null
    }
  });

  try {
    const fileBytes = await readFile(document.storagePath);
    const extraction = await extractDocumentContent(document.mimeType, fileBytes);

    const [updatedDocument, updatedJob] = await prisma.$transaction([
      prisma.workspaceDocument.update({
        where: { id: document.id },
        data: {
          status: extraction.note ? "FAILED" : "PROCESSED",
          extractedText: extraction.text || null,
          extractedData: extraction.data,
          extractionNote: extraction.note ?? null
        }
      }),
      prisma.documentExtractionJob.update({
        where: { id: queuedJob.id },
        data: {
          status: extraction.note ? "FAILED" : "COMPLETED",
          finishedAt: new Date(),
          error: extraction.note ?? null
        }
      })
    ]);

    return {
      document: toDocumentSummary(updatedDocument),
      job: toJobSummary(updatedJob)
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : "Extraction failed";

    const [failedDocument, failedJob] = await prisma.$transaction([
      prisma.workspaceDocument.update({
        where: { id: document.id },
        data: {
          status: "FAILED",
          extractionNote: message
        }
      }),
      prisma.documentExtractionJob.update({
        where: { id: queuedJob.id },
        data: {
          status: "FAILED",
          finishedAt: new Date(),
          error: message
        }
      })
    ]);

    return {
      document: toDocumentSummary(failedDocument),
      job: toJobSummary(failedJob)
    };
  }
}
