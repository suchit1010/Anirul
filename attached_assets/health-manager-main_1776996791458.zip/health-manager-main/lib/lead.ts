import { z } from "zod";

export const leadSchema = z.object({
  fullName: z.string().trim().min(2).max(120),
  workEmail: z.string().trim().email().max(255),
  organization: z.string().trim().min(2).max(180),
  role: z.string().trim().min(2).max(120),
  monthlyPatients: z.enum(["lt_1000", "1k_5k", "5k_20k", "20k_plus"]),
  objective: z.string().trim().min(25).max(4000)
});

export type LeadRequest = z.infer<typeof leadSchema>;

function webhookUrl(): string {
  const url = process.env.CRM_WEBHOOK_URL;
  if (!url) {
    throw new Error("Missing CRM_WEBHOOK_URL environment variable");
  }
  return url;
}

export async function sendLeadToCrm(payload: LeadRequest): Promise<void> {
  const url = webhookUrl();
  const token = process.env.CRM_WEBHOOK_BEARER_TOKEN;

  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {})
    },
    body: JSON.stringify({
      source: "anirul-site",
      createdAt: new Date().toISOString(),
      lead: payload
    })
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`CRM webhook rejected request (${response.status}): ${text}`);
  }
}
