import { createServerSupabase } from "@/lib/supabase-server";
import type { Session } from "@supabase/supabase-js";

function parseBooleanEnv(value: string | undefined): boolean {
  return value === "1" || value === "true" || value === "yes";
}

export function isDevAdminBypassEnabled(): boolean {
  return process.env.NODE_ENV !== "production" && parseBooleanEnv(process.env.DEV_ADMIN_BYPASS);
}

function buildDevAdminBypassSession(): Session {
  const nowSeconds = Math.floor(Date.now() / 1000);
  const bypassUserId = process.env.DEV_ADMIN_BYPASS_USER_ID?.trim() || "dev-admin-user";
  const bypassEmail = process.env.DEV_ADMIN_BYPASS_EMAIL?.trim() || "admin@local.test";

  return {
    access_token: "dev-admin-bypass-token",
    refresh_token: "dev-admin-bypass-refresh",
    token_type: "bearer",
    expires_in: 60 * 60 * 24,
    expires_at: nowSeconds + 60 * 60 * 24,
    user: {
      id: bypassUserId,
      email: bypassEmail
    }
  } as unknown as Session;
}

export async function requireUserSession() {
  const supabase = createServerSupabase();
  const {
    data: { session },
    error
  } = await supabase.auth.getSession();

  if (error || !session) {
    if (isDevAdminBypassEnabled()) {
      return buildDevAdminBypassSession();
    }

    return null;
  }

  return session;
}
