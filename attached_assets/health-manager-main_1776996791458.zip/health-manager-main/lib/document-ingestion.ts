import { PDFParse } from "pdf-parse";

export type ExtractedLabValue = {
  name: string;
  value: number;
  unit?: string;
};

export type DocumentExtractionResult = {
  text: string;
  data: {
    highlights: string[];
    labValues: ExtractedLabValue[];
    medications: string[];
  };
  note?: string;
};

function parseLabValues(text: string): ExtractedLabValue[] {
  const output: ExtractedLabValue[] = [];

  const hba1cMatch = text.match(/(?:hba1c|glycated\s+hemoglobin)[^\d]{0,20}(\d{1,2}(?:\.\d+)?)/i);
  if (hba1cMatch) {
    output.push({
      name: "HbA1c",
      value: Number(hba1cMatch[1]),
      unit: "%"
    });
  }

  const fastingGlucoseMatch = text.match(/(?:fasting\s+glucose|fbs)[^\d]{0,20}(\d{2,3}(?:\.\d+)?)/i);
  if (fastingGlucoseMatch) {
    output.push({
      name: "Fasting Glucose",
      value: Number(fastingGlucoseMatch[1]),
      unit: "mg/dL"
    });
  }

  const tshMatch = text.match(/(?:tsh|thyroid\s+stimulating\s+hormone)[^\d]{0,20}(\d{1,2}(?:\.\d+)?)/i);
  if (tshMatch) {
    output.push({
      name: "TSH",
      value: Number(tshMatch[1]),
      unit: "mIU/L"
    });
  }

  return output.filter((entry) => Number.isFinite(entry.value));
}

function parseMedications(text: string): string[] {
  const medicationKeywords = [
    "metformin",
    "telmisartan",
    "atorvastatin",
    "amlodipine",
    "insulin",
    "levothyroxine",
    "aspirin"
  ];

  const normalized = text.toLowerCase();
  return medicationKeywords.filter((keyword) => normalized.includes(keyword));
}

function createHighlights(text: string, labValues: ExtractedLabValue[], medications: string[]): string[] {
  const highlights: string[] = [];

  if (labValues.length > 0) {
    highlights.push(`Detected ${labValues.length} lab value(s) from document text.`);
  }

  if (medications.length > 0) {
    highlights.push(`Detected medication references: ${medications.join(", ")}.`);
  }

  if (highlights.length === 0 && text.trim().length > 0) {
    highlights.push("Text extracted successfully; no known structured markers found.");
  }

  return highlights;
}

export async function extractDocumentContent(
  mimeType: string,
  buffer: Buffer
): Promise<DocumentExtractionResult> {
  const normalizedMime = mimeType.toLowerCase();

  let text = "";
  let note: string | undefined;

  if (normalizedMime === "application/pdf") {
    const parser = new PDFParse({ data: buffer });
    const parsed = await parser.getText();
    await parser.destroy();
    text = parsed.text || "";
  } else if (normalizedMime.startsWith("text/") || normalizedMime === "application/json") {
    text = buffer.toString("utf8");
  } else if (normalizedMime.startsWith("image/")) {
    note = "Image OCR is not yet enabled in this environment. Upload PDF or text for extraction v1.";
    text = "";
  } else {
    note = `Unsupported mime type for extraction v1: ${mimeType}`;
    text = "";
  }

  const labValues = parseLabValues(text);
  const medications = parseMedications(text);
  const highlights = createHighlights(text, labValues, medications);

  return {
    text,
    data: {
      highlights,
      labValues,
      medications
    },
    note
  };
}
