export type RecordType = "lab" | "prescription" | "visit" | "note";

export type PatientProfile = {
  fullName: string;
  age: number;
  conditions: string[];
  primaryDoctor: string;
};

export type TimelineRecord = {
  id: string;
  createdAt: string;
  date: string;
  type: RecordType;
  title: string;
  summary: string;
  source: string;
  labValue?: number;
  unit?: string;
};

export type ProductState = {
  patient: PatientProfile | null;
  records: TimelineRecord[];
  updatedAt: string;
};

export type DoctorBrief = {
  generatedAt: string;
  patientLine: string;
  continuityScore: number;
  recentHighlights: string[];
  riskFlags: string[];
  suggestedActions: string[];
};

export type ClinicalSummarySnapshot = {
  overallRiskLevel: "LOW" | "MODERATE" | "HIGH" | "CRITICAL";
  summary: {
    totalAbnormalLabs: number;
    worseningTrends: number;
    clinicalPatterns: number;
    riskCategories: number;
    activeAlerts: number;
    criticalValues: number;
  };
  riskScores: Array<{
    category: string;
    level: "LOW" | "MODERATE" | "HIGH" | "CRITICAL";
    score: number;
    maxScore: number;
    recommendations: string[];
    contributingFactors: string[];
  }>;
  trends: {
    worseningTrends: Array<{
      labName: string;
      trend: string;
      trendStrength?: string;
      acceleration?: string;
    }>;
    improvingTrends: Array<{
      labName: string;
      trend: string;
    }>;
    patterns: Array<{
      patternName: string;
      severity: string;
      clinicalImplication: string;
    }>;
  };
  alerts: Array<{
    id: string;
    title: string;
    severity: string;
    description: string;
    actionItems: string[];
  }>;
  criticalLabs: Array<{
    labName: string;
    value: number;
    unit: string;
    status: string;
  }>;
  recommendations: string[];
};

export const PRODUCT_STORAGE_KEY = "anirul-product-v1";

export const EMPTY_PRODUCT_STATE: ProductState = {
  patient: null,
  records: [],
  updatedAt: new Date(0).toISOString()
};

function scoreFromFlags(flags: string[]): number {
  const penalty = flags.length * 12;
  return Math.max(45, 100 - penalty);
}

function scoreFromClinicalSummary(summary?: ClinicalSummarySnapshot): number {
  if (!summary) {
    return 0;
  }

  const riskPenalty = {
    LOW: 0,
    MODERATE: 8,
    HIGH: 18,
    CRITICAL: 30
  }[summary.overallRiskLevel];

  const alertPenalty = Math.min(summary.summary.activeAlerts * 4, 20);
  const trendPenalty = Math.min(summary.summary.worseningTrends * 3, 15);
  const criticalPenalty = Math.min(summary.summary.criticalValues * 8, 24);

  return riskPenalty + alertPenalty + trendPenalty + criticalPenalty;
}

function asDate(value: string): number {
  const time = Date.parse(value);
  return Number.isNaN(time) ? 0 : time;
}

function includesAny(text: string, tokens: string[]): boolean {
  const normalized = text.toLowerCase();
  return tokens.some((token) => normalized.includes(token));
}

export function sortRecords(records: TimelineRecord[]): TimelineRecord[] {
  return [...records].sort((first, second) => asDate(second.date) - asDate(first.date));
}

export function updateProductState(
  previous: ProductState,
  updates: Partial<Pick<ProductState, "patient" | "records">>
): ProductState {
  return {
    patient: updates.patient ?? previous.patient,
    records: updates.records ?? previous.records,
    updatedAt: new Date().toISOString()
  };
}

export function buildDoctorBrief(
  state: ProductState,
  clinicalSummary?: ClinicalSummarySnapshot
): DoctorBrief | null {
  if (!state.patient) {
    return null;
  }

  const records = sortRecords(state.records);
  const latest = records.slice(0, 5);
  const riskFlags: string[] = [];

  const hasRecentVisit = records.some((record) => {
    if (record.type !== "visit") {
      return false;
    }
    const days = (Date.now() - asDate(record.date)) / (1000 * 60 * 60 * 24);
    return days <= 90;
  });

  if (!hasRecentVisit && records.length > 0) {
    riskFlags.push("No visit logged in the last 90 days.");
  }

  if (clinicalSummary) {
    riskFlags.push(
      `Clinical risk level: ${clinicalSummary.overallRiskLevel.toLowerCase()}.`
    );

    if (clinicalSummary.summary.criticalValues > 0) {
      riskFlags.push(
        `${clinicalSummary.summary.criticalValues} critical lab value${clinicalSummary.summary.criticalValues === 1 ? "" : "s"} require attention.`
      );
    }

    if (clinicalSummary.summary.worseningTrends > 0) {
      riskFlags.push(
        `${clinicalSummary.summary.worseningTrends} worsening trend${clinicalSummary.summary.worseningTrends === 1 ? "" : "s"} detected.`
      );
    }

    if (clinicalSummary.summary.activeAlerts > 0) {
      riskFlags.push(
        `${clinicalSummary.summary.activeAlerts} active clinical alert${clinicalSummary.summary.activeAlerts === 1 ? "" : "s"} pending review.`
      );
    }
  }

  const hasDiabetes = state.patient.conditions.some((condition) =>
    includesAny(condition, ["diabetes", "t2d", "t1d", "sugar"])
  );

  const latestGlycemicLab = records.find(
    (record) =>
      record.type === "lab" && includesAny(`${record.title} ${record.summary}`, ["hba1c", "glucose"])
  );

  if (hasDiabetes && latestGlycemicLab && typeof latestGlycemicLab.labValue === "number") {
    if (latestGlycemicLab.labValue >= 8) {
      riskFlags.push(`Latest glycemic marker is elevated (${latestGlycemicLab.labValue}${latestGlycemicLab.unit || ""}).`);
    }
  }

  const seenLabs = new Map<string, string>();
  for (const record of records) {
    if (record.type !== "lab") {
      continue;
    }
    const key = record.title.toLowerCase().trim();
    const previousDate = seenLabs.get(key);
    if (previousDate) {
      const daysApart = Math.abs(asDate(record.date) - asDate(previousDate)) / (1000 * 60 * 60 * 24);
      if (daysApart <= 45) {
        riskFlags.push(`Potential duplicate lab window detected for ${record.title}.`);
        break;
      }
    }
    seenLabs.set(key, record.date);
  }

  const recentHighlights = latest.map(
    (record) => `${record.date}: ${record.title} (${record.type}) — ${record.summary}`
  );

  const suggestedActions =
    riskFlags.length === 0 && !clinicalSummary
      ? [
          "Continue current follow-up cadence and keep record uploads current.",
          "Confirm medication adherence at next consult.",
          "Share this brief with care team before the next appointment."
        ]
      : [
          "Review flagged risks with the clinician during the next visit.",
          "Confirm whether any planned labs can be deduplicated.",
          "Lock follow-up date and medication plan in patient memory."
        ];

  if (clinicalSummary) {
    clinicalSummary.recommendations.slice(0, 3).reverse().forEach((recommendation) => {
      suggestedActions.unshift(recommendation);
    });
  }

  const clinicalPenalty = scoreFromClinicalSummary(clinicalSummary);
  const continuityScore = Math.max(35, scoreFromFlags(riskFlags) - clinicalPenalty);

  return {
    generatedAt: new Date().toISOString(),
    patientLine: `${state.patient.fullName}, ${state.patient.age} — ${state.patient.conditions.join(", ") || "No chronic condition specified"}`,
    continuityScore,
    recentHighlights,
    riskFlags: riskFlags.length > 0 ? riskFlags : ["No immediate continuity risks detected from current data."],
    suggestedActions
  };
}

export const DEMO_PRODUCT_STATE: ProductState = {
  patient: {
    fullName: "Aarav Mehta",
    age: 54,
    conditions: ["Type 2 Diabetes", "Hypertension"],
    primaryDoctor: "Dr. R. Iyer"
  },
  records: [
    {
      id: "rec-1",
      createdAt: "2026-04-10T12:00:00.000Z",
      date: "2026-04-10",
      type: "lab",
      title: "HbA1c",
      summary: "Quarterly glycemic marker",
      source: "City Diagnostics",
      labValue: 8.2,
      unit: "%"
    },
    {
      id: "rec-2",
      createdAt: "2026-04-08T12:00:00.000Z",
      date: "2026-04-08",
      type: "visit",
      title: "Endocrinology follow-up",
      summary: "Medication adherence concerns and evening glucose spikes.",
      source: "SouthCare Clinic"
    },
    {
      id: "rec-3",
      createdAt: "2026-03-30T12:00:00.000Z",
      date: "2026-03-30",
      type: "prescription",
      title: "Metformin + Telmisartan",
      summary: "Dose adjusted for blood pressure stability.",
      source: "SouthCare Clinic"
    }
  ],
  updatedAt: "2026-04-10T12:00:00.000Z"
};