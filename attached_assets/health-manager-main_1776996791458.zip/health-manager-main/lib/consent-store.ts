import { prisma } from "@/lib/prisma";

export const CONSENT_SCOPES = [
  "DOCTOR_BRIEF",
  "FULL_TIMELINE",
  "LAB_TRENDS",
  "ALERTS",
  "DOCUMENTS"
] as const;

export type ConsentScope = (typeof CONSENT_SCOPES)[number];
export type ConsentStatusValue = "ACTIVE" | "REVOKED" | "EXPIRED";

export type ConsentGrantSummary = {
  id: string;
  workspaceId: string;
  grantedById: string;
  subjectName: string;
  subjectContact: string;
  purpose: string;
  scopes: ConsentScope[];
  status: ConsentStatusValue;
  expiresAt: string;
  revokedAt: string | null;
  revokeReason: string | null;
  createdAt: string;
  updatedAt: string;
};

export type ConsentEventSummary = {
  id: string;
  consentId: string;
  workspaceId: string;
  action: "CREATED" | "REVOKED" | "EXPIRED";
  actorUserId: string | null;
  actorDisplay: string | null;
  actorLabel: string;
  note: string | null;
  createdAt: string;
};

function mapStatus(status: string): ConsentStatusValue {
  if (status === "REVOKED") {
    return "REVOKED";
  }

  if (status === "EXPIRED") {
    return "EXPIRED";
  }

  return "ACTIVE";
}

function mapConsent(grant: {
  id: string;
  workspaceId: string;
  grantedById: string;
  subjectName: string;
  subjectContact: string;
  purpose: string;
  scopes: string[];
  status: string;
  expiresAt: Date;
  revokedAt: Date | null;
  revokeReason: string | null;
  createdAt: Date;
  updatedAt: Date;
}): ConsentGrantSummary {
  const effectiveStatus: ConsentStatusValue =
    grant.status === "ACTIVE" && grant.expiresAt.getTime() < Date.now()
      ? "EXPIRED"
      : mapStatus(grant.status);

  return {
    id: grant.id,
    workspaceId: grant.workspaceId,
    grantedById: grant.grantedById,
    subjectName: grant.subjectName,
    subjectContact: grant.subjectContact,
    purpose: grant.purpose,
    scopes: grant.scopes.filter((scope): scope is ConsentScope =>
      CONSENT_SCOPES.includes(scope as ConsentScope)
    ),
    status: effectiveStatus,
    expiresAt: grant.expiresAt.toISOString(),
    revokedAt: grant.revokedAt?.toISOString() ?? null,
    revokeReason: grant.revokeReason,
    createdAt: grant.createdAt.toISOString(),
    updatedAt: grant.updatedAt.toISOString()
  };
}

export async function createConsentGrant(input: {
  workspaceId: string;
  grantedById: string;
  subjectName: string;
  subjectContact: string;
  purpose: string;
  scopes: ConsentScope[];
  expiresAt: Date;
}) {
  const created = await prisma.consentGrant.create({
    data: {
      workspaceId: input.workspaceId,
      grantedById: input.grantedById,
      subjectName: input.subjectName,
      subjectContact: input.subjectContact,
      purpose: input.purpose,
      scopes: input.scopes,
      expiresAt: input.expiresAt,
      events: {
        create: {
          workspaceId: input.workspaceId,
          action: "CREATED",
          actorUserId: input.grantedById,
          note: `Consent granted for ${input.scopes.length} scope${input.scopes.length === 1 ? "" : "s"}`
        }
      }
    }
  });

  return mapConsent(created);
}

export async function revokeConsentGrant(input: {
  workspaceId: string;
  consentId: string;
  actorUserId: string;
  reason?: string;
}) {
  const existing = await prisma.consentGrant.findUnique({ where: { id: input.consentId } });

  if (!existing || existing.workspaceId !== input.workspaceId) {
    return null;
  }

  const now = new Date();
  const expired = existing.expiresAt.getTime() < now.getTime();

  if (existing.status === "REVOKED" || expired) {
    return mapConsent(existing);
  }

  const [revoked] = await prisma.$transaction([
    prisma.consentGrant.update({
      where: { id: input.consentId },
      data: {
        status: "REVOKED",
        revokedAt: now,
        revokeReason: input.reason || "Revoked by workspace member"
      }
    }),
    prisma.consentEvent.create({
      data: {
        consentId: input.consentId,
        workspaceId: input.workspaceId,
        action: "REVOKED",
        actorUserId: input.actorUserId,
        note: input.reason || "Consent revoked"
      }
    })
  ]);

  return mapConsent(revoked);
}

export async function listWorkspaceConsents(
  workspaceId: string,
  status: ConsentStatusValue | "all" = "all"
) {
  const grants = await prisma.consentGrant.findMany({
    where: {
      workspaceId,
      ...(status === "all" ? {} : { status })
    },
    orderBy: {
      createdAt: "desc"
    }
  });

  const consentIds = grants.map((grant: { id: string }) => grant.id);

  const events = consentIds.length
    ? await prisma.consentEvent.findMany({
        where: {
          workspaceId,
          consentId: {
            in: consentIds
          }
        },
        orderBy: {
          createdAt: "desc"
        }
      })
    : [];

  const actorIds = Array.from(
    new Set(
      events
        .map((event: { actorUserId: string | null }) => event.actorUserId)
        .filter((value: string | null): value is string => Boolean(value))
    )
  );

  const profiles = actorIds.length
    ? await prisma.userProfile.findMany({
        where: {
          id: {
            in: actorIds
          }
        },
        select: {
          id: true,
          fullName: true,
          email: true
        }
      })
    : [];

  const profileById = new Map<string, { fullName: string | null; email: string | null }>(
    profiles.map((profile: { id: string; fullName: string | null; email: string | null }) => [
      profile.id,
      { fullName: profile.fullName, email: profile.email }
    ])
  );

  const grantMap = grants.map(mapConsent);
  const eventMap: ConsentEventSummary[] = events.map((event: {
    id: string;
    consentId: string;
    workspaceId: string;
    action: "CREATED" | "REVOKED" | "EXPIRED";
    actorUserId: string | null;
    actorDisplay: string | null;
    note: string | null;
    createdAt: Date;
  }) => {
    const profile = event.actorUserId ? profileById.get(event.actorUserId) : null;
    return {
      id: event.id,
      consentId: event.consentId,
      workspaceId: event.workspaceId,
      action: event.action,
      actorUserId: event.actorUserId,
      actorDisplay: event.actorDisplay,
      actorLabel: profile?.fullName || profile?.email || event.actorDisplay || event.actorUserId || "System",
      note: event.note,
      createdAt: event.createdAt.toISOString()
    };
  });

  return {
    consents: grantMap,
    events: eventMap
  };
}
