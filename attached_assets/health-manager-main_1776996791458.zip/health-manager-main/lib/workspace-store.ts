import { randomUUID } from "node:crypto";
import { z } from "zod";
import { EMPTY_PRODUCT_STATE, type ProductState } from "@/lib/product-engine";
import { prisma } from "@/lib/prisma";

const workspaceIdSchema = z
  .string()
  .min(6)
  .max(64)
  .regex(/^[a-zA-Z0-9_-]+$/);

const workspaceDocumentSchema = z.object({
  id: workspaceIdSchema,
  createdAt: z.string(),
  updatedAt: z.string(),
  state: z.custom<ProductState>()
});

export type WorkspaceDocument = z.infer<typeof workspaceDocumentSchema>;
export type WorkspaceMemberRole = "OWNER" | "EDITOR" | "VIEWER";
export type WorkspaceInviteStatus = "PENDING" | "ACCEPTED" | "REVOKED" | "EXPIRED";

type WorkspaceMemberSummary = {
  userId: string;
  email: string | null;
  fullName: string | null;
  role: WorkspaceMemberRole;
  invitedById: string | null;
  createdAt: string;
  updatedAt: string;
};

type RemovedMemberSummary = {
  removedUserId: string;
};

export type WorkspaceInviteSummary = {
  id: string;
  workspaceId: string;
  email: string;
  role: WorkspaceMemberRole;
  token: string;
  status: WorkspaceInviteStatus;
  invitedById: string;
  acceptedById: string | null;
  expiresAt: string;
  acceptedAt: string | null;
  revokedAt: string | null;
  createdAt: string;
  updatedAt: string;
};

function createWorkspaceId(): string {
  return `ws_${randomUUID().replace(/-/g, "").slice(0, 20)}`;
}

function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

function createInviteToken(): string {
  return `inv_${randomUUID().replace(/-/g, "")}`;
}

function mapInviteToSummary(invite: {
  id: string;
  workspaceId: string;
  email: string;
  role: string;
  token: string;
  status: string;
  invitedById: string;
  acceptedById: string | null;
  expiresAt: Date;
  acceptedAt: Date | null;
  revokedAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}): WorkspaceInviteSummary {
  return {
    id: invite.id,
    workspaceId: invite.workspaceId,
    email: invite.email,
    role: invite.role as WorkspaceMemberRole,
    token: invite.token,
    status: invite.status as WorkspaceInviteStatus,
    invitedById: invite.invitedById,
    acceptedById: invite.acceptedById,
    expiresAt: invite.expiresAt.toISOString(),
    acceptedAt: invite.acceptedAt?.toISOString() ?? null,
    revokedAt: invite.revokedAt?.toISOString() ?? null,
    createdAt: invite.createdAt.toISOString(),
    updatedAt: invite.updatedAt.toISOString()
  };
}

function mapMemberToSummary(member: {
  userId: string;
  role: string;
  invitedById: string | null;
  createdAt: Date;
  updatedAt: Date;
  user: {
    email: string | null;
    fullName: string | null;
  };
}): WorkspaceMemberSummary {
  return {
    userId: member.userId,
    email: member.user.email,
    fullName: member.user.fullName,
    role: member.role as WorkspaceMemberRole,
    invitedById: member.invitedById,
    createdAt: member.createdAt.toISOString(),
    updatedAt: member.updatedAt.toISOString()
  };
}

async function getWorkspaceOwnerId(workspaceId: string): Promise<string | null> {
  const workspace = await prisma.workspace.findUnique({
    where: { id: workspaceId },
    select: { ownerId: true }
  });

  return workspace?.ownerId ?? null;
}

export async function ensureWorkspaceStore(): Promise<void> {
  return Promise.resolve();
}

export function sanitizeWorkspaceId(workspaceId: string): string {
  return workspaceIdSchema.parse(workspaceId);
}

export async function createWorkspace(
  ownerId: string,
  initialState?: ProductState
): Promise<WorkspaceDocument> {
  const id = createWorkspaceId();
  const created = await prisma.$transaction(async (transaction) => {
    await transaction.userProfile.upsert({
      where: { id: ownerId },
      update: {},
      create: { id: ownerId }
    });

    return transaction.workspace.create({
      data: {
        id,
        ownerId,
        state: (initialState ?? EMPTY_PRODUCT_STATE) as unknown as object,
        members: {
          create: {
            userId: ownerId,
            role: "OWNER"
          }
        }
      }
    });
  });

  return workspaceDocumentSchema.parse({
    id: created.id,
    createdAt: created.createdAt.toISOString(),
    updatedAt: created.updatedAt.toISOString(),
    state: created.state as ProductState
  });
}

export async function loadWorkspace(
  workspaceId: string,
  userId: string
): Promise<WorkspaceDocument | null> {
  const safeId = sanitizeWorkspaceId(workspaceId);

  const existing = await prisma.workspace.findFirst({
    where: {
      id: safeId,
      members: {
        some: {
          userId
        }
      }
    }
  });

  if (!existing) {
    return null;
  }

  return workspaceDocumentSchema.parse({
    id: existing.id,
    createdAt: existing.createdAt.toISOString(),
    updatedAt: existing.updatedAt.toISOString(),
    state: existing.state as ProductState
  });
}

export async function saveWorkspace(
  workspaceId: string,
  userId: string,
  state: ProductState
): Promise<WorkspaceDocument | null> {
  const safeId = sanitizeWorkspaceId(workspaceId);
  const writeAccess = await prisma.workspaceMember.findFirst({
    where: {
      workspaceId: safeId,
      userId,
      role: {
        in: ["OWNER", "EDITOR"]
      }
    },
    select: {
      id: true
    }
  });

  if (!writeAccess) {
    return null;
  }

  const updated = await prisma.workspace.updateManyAndReturn({
    where: {
      id: safeId
    },
    data: {
      state: state as unknown as object
    }
  });

  const row = updated[0];
  if (!row) {
    return null;
  }

  return workspaceDocumentSchema.parse({
    id: row.id,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
    state: row.state as ProductState
  });
}

export async function listWorkspaceMembers(
  workspaceId: string,
  userId: string
): Promise<WorkspaceMemberSummary[] | null> {
  const safeId = sanitizeWorkspaceId(workspaceId);

  const workspace = await prisma.workspace.findFirst({
    where: {
      id: safeId,
      members: {
        some: {
          userId
        }
      }
    },
    include: {
      members: {
        include: {
          user: {
            select: {
              id: true,
              email: true,
              fullName: true
            }
          }
        },
        orderBy: [{ role: "asc" }, { createdAt: "asc" }]
      }
    }
  });

  if (!workspace) {
    return null;
  }

  return workspace.members.map(mapMemberToSummary);
}

export async function addWorkspaceMember(
  workspaceId: string,
  actorUserId: string,
  targetUserId: string,
  role: WorkspaceMemberRole
): Promise<WorkspaceMemberSummary | "forbidden" | null> {
  const safeId = sanitizeWorkspaceId(workspaceId);

  const workspace = await prisma.workspace.findUnique({
    where: { id: safeId },
    select: {
      id: true,
      ownerId: true
    }
  });

  if (!workspace) {
    return null;
  }

  if (workspace.ownerId !== actorUserId) {
    return "forbidden";
  }

  await prisma.userProfile.upsert({
    where: { id: targetUserId },
    update: {},
    create: { id: targetUserId }
  });

  const member = await prisma.workspaceMember.upsert({
    where: {
      workspaceId_userId: {
        workspaceId: safeId,
        userId: targetUserId
      }
    },
    update: {
      role,
      invitedById: actorUserId
    },
    create: {
      workspaceId: safeId,
      userId: targetUserId,
      role,
      invitedById: actorUserId
    },
    include: {
      user: {
        select: {
          id: true,
          email: true,
          fullName: true
        }
      }
    }
  });

  return {
    userId: member.userId,
    email: member.user.email,
    fullName: member.user.fullName,
    role: member.role as WorkspaceMemberRole,
    invitedById: member.invitedById,
    createdAt: member.createdAt.toISOString(),
    updatedAt: member.updatedAt.toISOString()
  };
}

export async function updateWorkspaceMemberRole(
  workspaceId: string,
  actorUserId: string,
  targetUserId: string,
  role: WorkspaceMemberRole
): Promise<WorkspaceMemberSummary | "forbidden" | "owner-protected" | null> {
  const safeId = sanitizeWorkspaceId(workspaceId);
  const ownerId = await getWorkspaceOwnerId(safeId);

  if (!ownerId) {
    return null;
  }

  if (ownerId !== actorUserId) {
    return "forbidden";
  }

  if (targetUserId === ownerId) {
    return "owner-protected";
  }

  const updated = await prisma.workspaceMember.updateManyAndReturn({
    where: {
      workspaceId: safeId,
      userId: targetUserId
    },
    data: {
      role,
      invitedById: actorUserId
    },
    include: {
      user: {
        select: {
          email: true,
          fullName: true
        }
      }
    }
  });

  const row = updated[0];
  if (!row) {
    return null;
  }

  return mapMemberToSummary(row);
}

export async function removeWorkspaceMember(
  workspaceId: string,
  actorUserId: string,
  targetUserId: string
): Promise<RemovedMemberSummary | "forbidden" | "owner-protected" | null> {
  const safeId = sanitizeWorkspaceId(workspaceId);
  const ownerId = await getWorkspaceOwnerId(safeId);

  if (!ownerId) {
    return null;
  }

  if (ownerId !== actorUserId) {
    return "forbidden";
  }

  if (targetUserId === ownerId) {
    return "owner-protected";
  }

  const deleted = await prisma.workspaceMember.deleteMany({
    where: {
      workspaceId: safeId,
      userId: targetUserId
    }
  });

  if (deleted.count === 0) {
    return null;
  }

  return {
    removedUserId: targetUserId
  };
}

export async function listWorkspaceInvites(
  workspaceId: string,
  userId: string
): Promise<WorkspaceInviteSummary[] | null> {
  const safeId = sanitizeWorkspaceId(workspaceId);

  const hasAccess = await prisma.workspaceMember.findFirst({
    where: {
      workspaceId: safeId,
      userId
    },
    select: { id: true }
  });

  if (!hasAccess) {
    return null;
  }

  const now = new Date();
  await prisma.workspaceInvite.updateMany({
    where: {
      workspaceId: safeId,
      status: "PENDING",
      expiresAt: {
        lt: now
      }
    },
    data: {
      status: "EXPIRED"
    }
  });

  const invites = await prisma.workspaceInvite.findMany({
    where: {
      workspaceId: safeId
    },
    orderBy: [{ status: "asc" }, { createdAt: "desc" }]
  });

  return invites.map(mapInviteToSummary);
}

export async function createWorkspaceInvite(
  workspaceId: string,
  actorUserId: string,
  inviteEmail: string,
  role: WorkspaceMemberRole
): Promise<WorkspaceInviteSummary | "forbidden" | null> {
  const safeId = sanitizeWorkspaceId(workspaceId);
  const normalizedEmail = normalizeEmail(inviteEmail);

  const workspace = await prisma.workspace.findUnique({
    where: { id: safeId },
    select: { id: true, ownerId: true }
  });

  if (!workspace) {
    return null;
  }

  if (workspace.ownerId !== actorUserId) {
    return "forbidden";
  }

  const existingUser = await prisma.userProfile.findFirst({
    where: {
      email: normalizedEmail
    },
    select: {
      id: true
    }
  });

  if (existingUser) {
    await prisma.workspaceMember.upsert({
      where: {
        workspaceId_userId: {
          workspaceId: safeId,
          userId: existingUser.id
        }
      },
      update: {
        role,
        invitedById: actorUserId
      },
      create: {
        workspaceId: safeId,
        userId: existingUser.id,
        role,
        invitedById: actorUserId
      }
    });
  }

  await prisma.workspaceInvite.updateMany({
    where: {
      workspaceId: safeId,
      email: normalizedEmail,
      status: "PENDING"
    },
    data: {
      status: "REVOKED",
      revokedAt: new Date()
    }
  });

  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
  const created = await prisma.workspaceInvite.create({
    data: {
      workspaceId: safeId,
      email: normalizedEmail,
      role,
      token: createInviteToken(),
      invitedById: actorUserId,
      expiresAt
    }
  });

  return mapInviteToSummary(created);
}

export async function revokeWorkspaceInvite(
  workspaceId: string,
  actorUserId: string,
  inviteId: string
): Promise<WorkspaceInviteSummary | "forbidden" | null> {
  const safeId = sanitizeWorkspaceId(workspaceId);
  const ownerId = await getWorkspaceOwnerId(safeId);

  if (!ownerId) {
    return null;
  }

  if (ownerId !== actorUserId) {
    return "forbidden";
  }

  const updated = await prisma.workspaceInvite.updateManyAndReturn({
    where: {
      id: inviteId,
      workspaceId: safeId
    },
    data: {
      status: "REVOKED",
      revokedAt: new Date()
    }
  });

  const row = updated[0];
  if (!row) {
    return null;
  }

  return mapInviteToSummary(row);
}

export async function resendWorkspaceInvite(
  workspaceId: string,
  actorUserId: string,
  inviteId: string
): Promise<WorkspaceInviteSummary | "forbidden" | null> {
  const safeId = sanitizeWorkspaceId(workspaceId);
  const ownerId = await getWorkspaceOwnerId(safeId);

  if (!ownerId) {
    return null;
  }

  if (ownerId !== actorUserId) {
    return "forbidden";
  }

  const sourceInvite = await prisma.workspaceInvite.findFirst({
    where: {
      id: inviteId,
      workspaceId: safeId
    }
  });

  if (!sourceInvite) {
    return null;
  }

  await prisma.workspaceInvite.updateMany({
    where: {
      workspaceId: safeId,
      email: sourceInvite.email,
      status: "PENDING"
    },
    data: {
      status: "REVOKED",
      revokedAt: new Date()
    }
  });

  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
  const resent = await prisma.workspaceInvite.create({
    data: {
      workspaceId: safeId,
      email: sourceInvite.email,
      role: sourceInvite.role,
      token: createInviteToken(),
      invitedById: actorUserId,
      expiresAt
    }
  });

  return mapInviteToSummary(resent);
}

export async function acceptWorkspaceInvite(
  token: string,
  userId: string,
  userEmail: string | null | undefined
): Promise<WorkspaceInviteSummary | "invalid" | "email-mismatch"> {
  const normalizedUserEmail = normalizeEmail(userEmail ?? "");
  if (!normalizedUserEmail) {
    return "email-mismatch";
  }

  const invite = await prisma.workspaceInvite.findUnique({
    where: { token }
  });

  if (!invite || invite.status !== "PENDING") {
    return "invalid";
  }

  if (invite.expiresAt.getTime() < Date.now()) {
    await prisma.workspaceInvite.update({
      where: { id: invite.id },
      data: {
        status: "EXPIRED"
      }
    });
    return "invalid";
  }

  if (normalizeEmail(invite.email) !== normalizedUserEmail) {
    return "email-mismatch";
  }

  const accepted = await prisma.$transaction(async (transaction) => {
    await transaction.userProfile.upsert({
      where: { id: userId },
      update: {
        email: normalizedUserEmail
      },
      create: {
        id: userId,
        email: normalizedUserEmail
      }
    });

    const existingMembership = await transaction.workspaceMember.findUnique({
      where: {
        workspaceId_userId: {
          workspaceId: invite.workspaceId,
          userId
        }
      }
    });

    if (!existingMembership) {
      await transaction.workspaceMember.create({
        data: {
          workspaceId: invite.workspaceId,
          userId,
          role: invite.role,
          invitedById: invite.invitedById
        }
      });
    }

    return transaction.workspaceInvite.update({
      where: { id: invite.id },
      data: {
        status: "ACCEPTED",
        acceptedById: userId,
        acceptedAt: new Date()
      }
    });
  });

  return mapInviteToSummary(accepted);
}