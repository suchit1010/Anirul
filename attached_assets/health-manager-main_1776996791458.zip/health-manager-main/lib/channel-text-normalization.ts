export type ChannelType = "whatsapp" | "audio";

export type ChannelTextNormalizationResult = {
  originalText: string;
  cleanedText: string;
  languageHint: string | null;
  detectedScript: "latin" | "devanagari" | "mixed" | "unknown";
  confidence: number;
  notes: string[];
};

const DEVANAGARI_DIGIT_MAP: Record<string, string> = {
  "०": "0",
  "१": "1",
  "२": "2",
  "३": "3",
  "४": "4",
  "५": "5",
  "६": "6",
  "७": "7",
  "८": "8",
  "९": "9"
};

const DEVANAGARI_TO_ENGLISH_MEDICAL_MAP: Array<[RegExp, string]> = [
  [/\bशुगर\b/gi, "sugar"],
  [/\bब्लड शुगर\b/gi, "blood sugar"],
  [/\bउपवास शुगर\b/gi, "fasting glucose"],
  [/\bथायरॉइड\b/gi, "thyroid"],
  [/\bटीएसएच\b/gi, "TSH"],
  [/\bहीमोग्लोबिन\b/gi, "hemoglobin"],
  [/\bदवा\b/gi, "medicine"],
  [/\bमेटफॉर्मिन\b/gi, "metformin"],
  [/\bइंसुलिन\b/gi, "insulin"],
  [/\bक्रिएटिनिन\b/gi, "creatinine"],
  [/\bरिपोर्ट\b/gi, "report"],
  [/\bमिलीग्राम\b/gi, "mg"],
  [/\bप्रतिशत\b/gi, "%"]
];

const COMMON_ABBREVIATION_MAP: Array<[RegExp, string]> = [
  [/\bfbs\b/gi, "fasting glucose"],
  [/\bpp\s*bs\b/gi, "post prandial glucose"],
  [/\bbp\b/gi, "blood pressure"],
  [/\bhb\b/gi, "hemoglobin"],
  [/\ba1c\b/gi, "hba1c"],
  [/\bthyroid profile\b/gi, "TSH thyroid profile"],
  [/\bsugar test\b/gi, "glucose test"]
];

function normalizeDigits(input: string): string {
  return input.replace(/[०-९]/g, (digit) => DEVANAGARI_DIGIT_MAP[digit] ?? digit);
}

function detectScript(input: string): "latin" | "devanagari" | "mixed" | "unknown" {
  const hasLatin = /[A-Za-z]/.test(input);
  const hasDevanagari = /[\u0900-\u097F]/.test(input);

  if (hasLatin && hasDevanagari) {
    return "mixed";
  }

  if (hasDevanagari) {
    return "devanagari";
  }

  if (hasLatin) {
    return "latin";
  }

  return "unknown";
}

function scoreNormalization(text: string, cleanedText: string): number {
  let score = 0.45;

  if (cleanedText.length >= 40) {
    score += 0.2;
  } else if (cleanedText.length >= 20) {
    score += 0.1;
  }

  if (/\d/.test(cleanedText)) {
    score += 0.15;
  }

  if (/(hba1c|glucose|tsh|hemoglobin|metformin|insulin|creatinine|blood pressure)/i.test(cleanedText)) {
    score += 0.2;
  }

  if (Math.abs(cleanedText.length - text.length) <= Math.max(10, text.length * 0.25)) {
    score += 0.05;
  }

  return Math.max(0, Math.min(0.99, Number(score.toFixed(2))));
}

export function normalizeChannelText(input: {
  text: string;
  channel: ChannelType;
  languageHint?: string;
}): ChannelTextNormalizationResult {
  const original = input.text ?? "";
  const notes: string[] = [];

  let cleaned = original
    .replace(/[\u200B-\u200D\uFEFF]/g, "")
    .replace(/\r\n?/g, "\n")
    .replace(/\t/g, " ")
    .replace(/[ ]{2,}/g, " ")
    .trim();

  const beforeDigitNormalization = cleaned;
  cleaned = normalizeDigits(cleaned);
  if (cleaned !== beforeDigitNormalization) {
    notes.push("Converted Indic numerals to ASCII digits.");
  }

  for (const [pattern, replacement] of DEVANAGARI_TO_ENGLISH_MEDICAL_MAP) {
    const next = cleaned.replace(pattern, replacement);
    if (next !== cleaned) {
      cleaned = next;
    }
  }

  for (const [pattern, replacement] of COMMON_ABBREVIATION_MAP) {
    const next = cleaned.replace(pattern, replacement);
    if (next !== cleaned) {
      cleaned = next;
    }
  }

  cleaned = cleaned
    .replace(/\n{3,}/g, "\n\n")
    .replace(/[ ]{2,}/g, " ")
    .trim();

  const detectedScript = detectScript(cleaned);

  if (input.channel === "audio") {
    notes.push("Applied transcript cleanup tuned for conversational input.");
  } else {
    notes.push("Applied forwarded-text cleanup tuned for messaging artifacts.");
  }

  const confidence = scoreNormalization(original, cleaned);

  return {
    originalText: original,
    cleanedText: cleaned,
    languageHint: input.languageHint?.trim() || null,
    detectedScript,
    confidence,
    notes
  };
}
