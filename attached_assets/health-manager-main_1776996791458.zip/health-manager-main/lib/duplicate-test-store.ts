import { prisma } from "@/lib/prisma";

export type DuplicateTestCheckResult = {
  id: string;
  workspaceId: string;
  patientId: string | null;
  requestedLabName: string;
  normalizedLabName: string;
  lookbackDays: number;
  isDuplicate: boolean;
  recommendation: string;
  rationale: string;
  recentTestDate: string | null;
  recentTestValue: number | null;
  recentTestStatus: "NORMAL" | "LOW" | "HIGH" | "CRITICAL" | null;
  requestedAt: string;
};

const LAB_ALIASES: Record<string, string[]> = {
  hba1c: ["hba1c", "hemoglobin a1c", "glycated hemoglobin"],
  fasting_glucose: ["fasting glucose", "fbs", "fasting blood sugar", "fasting blood glucose"],
  tsh: ["tsh", "thyroid stimulating hormone"],
  creatinine: ["creatinine", "serum creatinine"],
  cbc: ["cbc", "complete blood count", "hemogram"],
  lipid_panel: ["lipid panel", "lipid profile", "total cholesterol", "ldl cholesterol", "hdl cholesterol", "triglycerides"]
};

function normalizeLabName(input: string): string {
  return input.trim().toLowerCase().replace(/\s+/g, " ");
}

function resolveEquivalentNames(inputLabName: string): string[] {
  const normalized = normalizeLabName(inputLabName);

  for (const aliases of Object.values(LAB_ALIASES)) {
    if (aliases.includes(normalized)) {
      return aliases;
    }
  }

  return [normalized];
}

function buildRecommendation(input: {
  isDuplicate: boolean;
  daysSinceRecent: number | null;
  recentStatus: "NORMAL" | "LOW" | "HIGH" | "CRITICAL" | null;
}) {
  if (!input.isDuplicate) {
    return {
      recommendation: "No recent equivalent test found. Proceed with test if clinically indicated.",
      rationale: "No equivalent normalized lab record exists in the requested lookback window."
    };
  }

  if (input.recentStatus === "CRITICAL") {
    return {
      recommendation: "Recent result was critical. Avoid routine duplicate repeat; prioritize urgent clinician review.",
      rationale: `Equivalent test already exists from ${input.daysSinceRecent ?? 0} day(s) ago with CRITICAL status.`
    };
  }

  if (input.recentStatus === "HIGH" || input.recentStatus === "LOW") {
    return {
      recommendation: "Recent abnormal result exists. Consider targeted follow-up timing instead of immediate duplicate test.",
      rationale: `Equivalent test already exists from ${input.daysSinceRecent ?? 0} day(s) ago with abnormal status (${input.recentStatus}).`
    };
  }

  return {
    recommendation: "Recent normal result exists. Consider deferring duplicate test unless new symptoms or doctor-directed need.",
    rationale: `Equivalent test already exists from ${input.daysSinceRecent ?? 0} day(s) ago with NORMAL status.`
  };
}

function mapCheckResult(check: {
  id: string;
  workspaceId: string;
  patientId: string | null;
  requestedLabName: string;
  normalizedLabName: string;
  lookbackDays: number;
  isDuplicate: boolean;
  recommendation: string;
  rationale: string;
  recentTestDate: Date | null;
  recentTestValue: number | null;
  recentTestStatus: "NORMAL" | "LOW" | "HIGH" | "CRITICAL" | null;
  requestedAt: Date;
}): DuplicateTestCheckResult {
  return {
    id: check.id,
    workspaceId: check.workspaceId,
    patientId: check.patientId,
    requestedLabName: check.requestedLabName,
    normalizedLabName: check.normalizedLabName,
    lookbackDays: check.lookbackDays,
    isDuplicate: check.isDuplicate,
    recommendation: check.recommendation,
    rationale: check.rationale,
    recentTestDate: check.recentTestDate?.toISOString() ?? null,
    recentTestValue: check.recentTestValue,
    recentTestStatus: check.recentTestStatus,
    requestedAt: check.requestedAt.toISOString()
  };
}

export async function checkDuplicateTest(input: {
  workspaceId: string;
  requestedById: string;
  patientId?: string;
  labName: string;
  lookbackDays?: number;
}) {
  const lookbackDays = Math.min(365, Math.max(1, input.lookbackDays ?? 90));
  const since = new Date();
  since.setDate(since.getDate() - lookbackDays);

  const equivalentNames = resolveEquivalentNames(input.labName);

  const recentCandidates = await prisma.normalizedLabValue.findMany({
    where: {
      workspaceId: input.workspaceId,
      patientId: input.patientId || undefined,
      testDate: {
        gte: since
      }
    },
    orderBy: {
      testDate: "desc"
    },
    take: 50
  });

  const recent = recentCandidates.find((lab: { labName: string }) =>
    equivalentNames.includes(normalizeLabName(lab.labName))
  );

  const daysSinceRecent = recent
    ? Math.max(0, Math.floor((Date.now() - new Date(recent.testDate).getTime()) / (24 * 60 * 60 * 1000)))
    : null;

  const isDuplicate = Boolean(recent);
  const recommendationBundle = buildRecommendation({
    isDuplicate,
    daysSinceRecent,
    recentStatus: recent?.status ?? null
  });

  const check = await prisma.duplicateTestCheck.create({
    data: {
      workspaceId: input.workspaceId,
      patientId: input.patientId,
      requestedLabName: input.labName,
      normalizedLabName: normalizeLabName(input.labName),
      requestedById: input.requestedById,
      lookbackDays,
      isDuplicate,
      recommendation: recommendationBundle.recommendation,
      rationale: recommendationBundle.rationale,
      recentTestDate: recent?.testDate ?? null,
      recentTestValue: recent?.value ?? null,
      recentTestStatus: recent?.status ?? null
    }
  });

  return mapCheckResult({
    ...check,
    recentTestStatus: check.recentTestStatus as "NORMAL" | "LOW" | "HIGH" | "CRITICAL" | null
  });
}

export async function listDuplicateChecks(workspaceId: string, patientId?: string, limit = 20) {
  const checks = await prisma.duplicateTestCheck.findMany({
    where: {
      workspaceId,
      patientId: patientId || undefined
    },
    orderBy: {
      requestedAt: "desc"
    },
    take: Math.min(100, Math.max(1, limit))
  });

  return checks.map((check: {
    id: string;
    workspaceId: string;
    patientId: string | null;
    requestedLabName: string;
    normalizedLabName: string;
    lookbackDays: number;
    isDuplicate: boolean;
    recommendation: string;
    rationale: string;
    recentTestDate: Date | null;
    recentTestValue: number | null;
    recentTestStatus: string | null;
    requestedAt: Date;
  }) =>
    mapCheckResult({
      ...check,
      recentTestStatus: check.recentTestStatus as "NORMAL" | "LOW" | "HIGH" | "CRITICAL" | null
    })
  );
}
