import { z } from "zod";

export const contactSchema = z.object({
  name: z.string().trim().min(2).max(120),
  email: z.string().trim().email().max(255),
  company: z.string().trim().max(120).optional().default(""),
  interest: z.enum(["pilot", "clinic", "enterprise", "investor", "media", "other"]),
  message: z.string().trim().min(20).max(4000)
});

export type ContactRequest = z.infer<typeof contactSchema>;

const FROM_EMAIL = process.env.CONTACT_FROM_EMAIL;
const TO_EMAIL = process.env.CONTACT_TO_EMAIL;

function buildHtml(payload: ContactRequest): string {
  return `
    <h2>New Anirul inbound request</h2>
    <p><strong>Name:</strong> ${payload.name}</p>
    <p><strong>Email:</strong> ${payload.email}</p>
    <p><strong>Company:</strong> ${payload.company || "N/A"}</p>
    <p><strong>Interest:</strong> ${payload.interest}</p>
    <p><strong>Message:</strong></p>
    <pre style="white-space: pre-wrap; font-family: sans-serif;">${payload.message}</pre>
  `;
}

export async function sendContactEmail(payload: ContactRequest): Promise<void> {
  if (!FROM_EMAIL || !TO_EMAIL) {
    throw new Error("Missing CONTACT_FROM_EMAIL or CONTACT_TO_EMAIL environment variable");
  }

  if (process.env.RESEND_API_KEY) {
    const { Resend } = await import("resend");
    const resend = new Resend(process.env.RESEND_API_KEY);

    await resend.emails.send({
      from: FROM_EMAIL,
      to: TO_EMAIL,
      replyTo: payload.email,
      subject: `[Anirul] ${payload.interest} request from ${payload.name}`,
      html: buildHtml(payload),
      text: `${payload.name} (${payload.email})\nInterest: ${payload.interest}\nCompany: ${payload.company || "N/A"}\n\n${payload.message}`
    });

    return;
  }

  throw new Error("No delivery provider configured. Set RESEND_API_KEY to enable live email delivery.");
}
