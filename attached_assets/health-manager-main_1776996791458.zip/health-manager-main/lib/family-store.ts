import { prisma } from "@/lib/prisma";

export type FamilyProfileSummary = {
  id: string;
  workspaceId: string;
  fullName: string;
  ageYears: number | null;
  sex: string | null;
  relation: "SELF" | "SPOUSE" | "CHILD" | "PARENT" | "SIBLING" | "OTHER";
  notes: string | null;
  createdById: string;
  createdAt: string;
  updatedAt: string;
  accesses: FamilyAccessSummary[];
};

export type FamilyAccessSummary = {
  id: string;
  workspaceId: string;
  profileId: string;
  userId: string;
  role: "MANAGER" | "VIEWER";
  status: "ACTIVE" | "REVOKED";
  grantedById: string;
  revokedAt: string | null;
  createdAt: string;
  updatedAt: string;
};

export type FamilyAccessEventSummary = {
  id: string;
  workspaceId: string;
  profileId: string;
  accessId: string;
  action: "GRANTED" | "REVOKED";
  actorUserId: string | null;
  actorDisplay: string | null;
  actorLabel: string;
  note: string | null;
  createdAt: string;
};

function mapRelation(value: string): FamilyProfileSummary["relation"] {
  if (value === "SELF" || value === "SPOUSE" || value === "CHILD" || value === "PARENT" || value === "SIBLING") {
    return value;
  }
  return "OTHER";
}

function mapAccessRole(value: string): FamilyAccessSummary["role"] {
  return value === "MANAGER" ? "MANAGER" : "VIEWER";
}

function mapAccessStatus(value: string): FamilyAccessSummary["status"] {
  return value === "REVOKED" ? "REVOKED" : "ACTIVE";
}

function mapAccess(access: {
  id: string;
  workspaceId: string;
  profileId: string;
  userId: string;
  role: string;
  status: string;
  grantedById: string;
  revokedAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}): FamilyAccessSummary {
  return {
    id: access.id,
    workspaceId: access.workspaceId,
    profileId: access.profileId,
    userId: access.userId,
    role: mapAccessRole(access.role),
    status: mapAccessStatus(access.status),
    grantedById: access.grantedById,
    revokedAt: access.revokedAt?.toISOString() ?? null,
    createdAt: access.createdAt.toISOString(),
    updatedAt: access.updatedAt.toISOString()
  };
}

function mapProfile(profile: {
  id: string;
  workspaceId: string;
  fullName: string;
  ageYears: number | null;
  sex: string | null;
  relation: string;
  notes: string | null;
  createdById: string;
  createdAt: Date;
  updatedAt: Date;
  accesses: Array<{
    id: string;
    workspaceId: string;
    profileId: string;
    userId: string;
    role: string;
    status: string;
    grantedById: string;
    revokedAt: Date | null;
    createdAt: Date;
    updatedAt: Date;
  }>;
}): FamilyProfileSummary {
  return {
    id: profile.id,
    workspaceId: profile.workspaceId,
    fullName: profile.fullName,
    ageYears: profile.ageYears,
    sex: profile.sex,
    relation: mapRelation(profile.relation),
    notes: profile.notes,
    createdById: profile.createdById,
    createdAt: profile.createdAt.toISOString(),
    updatedAt: profile.updatedAt.toISOString(),
    accesses: profile.accesses.map(mapAccess)
  };
}

export async function createFamilyProfile(input: {
  workspaceId: string;
  createdById: string;
  fullName: string;
  ageYears?: number;
  sex?: string;
  relation?: "SELF" | "SPOUSE" | "CHILD" | "PARENT" | "SIBLING" | "OTHER";
  notes?: string;
}) {
  const profile = await prisma.familyProfile.create({
    data: {
      workspaceId: input.workspaceId,
      fullName: input.fullName,
      ageYears: input.ageYears,
      sex: input.sex,
      relation: input.relation ?? "OTHER",
      notes: input.notes,
      createdById: input.createdById
    }
  });

  const access = await prisma.familyAccess.create({
    data: {
      workspaceId: input.workspaceId,
      profileId: profile.id,
      userId: input.createdById,
      role: "MANAGER",
      status: "ACTIVE",
      grantedById: input.createdById
    }
  });

  await prisma.familyAccessEvent.create({
    data: {
      workspaceId: input.workspaceId,
      profileId: profile.id,
      accessId: access.id,
      action: "GRANTED",
      actorUserId: input.createdById,
      note: "Primary caregiver access granted"
    }
  });

  const hydrated = await prisma.familyProfile.findUnique({
    where: { id: profile.id },
    include: {
      accesses: {
        orderBy: {
          createdAt: "desc"
        }
      }
    }
  });

  if (!hydrated) {
    throw new Error("Unable to load created family profile");
  }

  return mapProfile(hydrated);
}

export async function upsertFamilyAccess(input: {
  workspaceId: string;
  profileId: string;
  targetUserId: string;
  role: "MANAGER" | "VIEWER";
  actorUserId: string;
}) {
  const existing = await prisma.familyAccess.findFirst({
    where: {
      workspaceId: input.workspaceId,
      profileId: input.profileId,
      userId: input.targetUserId
    }
  });

  if (!existing) {
    const created = await prisma.familyAccess.create({
      data: {
        workspaceId: input.workspaceId,
        profileId: input.profileId,
        userId: input.targetUserId,
        role: input.role,
        status: "ACTIVE",
        grantedById: input.actorUserId,
        events: {
          create: {
            workspaceId: input.workspaceId,
            profileId: input.profileId,
            action: "GRANTED",
            actorUserId: input.actorUserId,
            note: `Access granted as ${input.role}`
          }
        }
      }
    });

    return mapAccess(created);
  }

  const [updated] = await prisma.$transaction([
    prisma.familyAccess.update({
      where: { id: existing.id },
      data: {
        role: input.role,
        status: "ACTIVE",
        revokedAt: null,
        grantedById: input.actorUserId
      }
    }),
    prisma.familyAccessEvent.create({
      data: {
        workspaceId: input.workspaceId,
        profileId: input.profileId,
        accessId: existing.id,
        action: "GRANTED",
        actorUserId: input.actorUserId,
        note: `Access granted as ${input.role}`
      }
    })
  ]);

  return mapAccess(updated);
}

export async function revokeFamilyAccess(input: {
  workspaceId: string;
  profileId: string;
  targetUserId: string;
  actorUserId: string;
}) {
  const existing = await prisma.familyAccess.findFirst({
    where: {
      workspaceId: input.workspaceId,
      profileId: input.profileId,
      userId: input.targetUserId
    }
  });

  if (!existing) {
    return null;
  }

  const now = new Date();
  const [updated] = await prisma.$transaction([
    prisma.familyAccess.update({
      where: { id: existing.id },
      data: {
        status: "REVOKED",
        revokedAt: now
      }
    }),
    prisma.familyAccessEvent.create({
      data: {
        workspaceId: input.workspaceId,
        profileId: input.profileId,
        accessId: existing.id,
        action: "REVOKED",
        actorUserId: input.actorUserId,
        note: "Access revoked"
      }
    })
  ]);

  return mapAccess(updated);
}

export async function listFamilyProfiles(workspaceId: string) {
  const profiles = await prisma.familyProfile.findMany({
    where: { workspaceId },
    include: {
      accesses: {
        orderBy: {
          createdAt: "desc"
        }
      }
    },
    orderBy: {
      createdAt: "desc"
    }
  });

  const profileIds = profiles.map((profile: { id: string }) => profile.id);
  const events = profileIds.length
    ? await prisma.familyAccessEvent.findMany({
        where: {
          workspaceId,
          profileId: {
            in: profileIds
          }
        },
        orderBy: {
          createdAt: "desc"
        }
      })
    : [];

  const actorIds = Array.from(
    new Set(
      events
        .map((event: { actorUserId: string | null }) => event.actorUserId)
        .filter((value: string | null): value is string => Boolean(value))
    )
  );

  const profilesByActor = actorIds.length
    ? await prisma.userProfile.findMany({
        where: {
          id: { in: actorIds }
        },
        select: {
          id: true,
          fullName: true,
          email: true
        }
      })
    : [];

  const profileMap = new Map<string, { fullName: string | null; email: string | null }>(
    profilesByActor.map((profile: { id: string; fullName: string | null; email: string | null }) => [
      profile.id,
      { fullName: profile.fullName, email: profile.email }
    ])
  );

  const eventList: FamilyAccessEventSummary[] = events.map((event: {
    id: string;
    workspaceId: string;
    profileId: string;
    accessId: string;
    action: string;
    actorUserId: string | null;
    actorDisplay: string | null;
    note: string | null;
    createdAt: Date;
  }) => {
    const actor = event.actorUserId ? profileMap.get(event.actorUserId) : null;
    return {
      id: event.id,
      workspaceId: event.workspaceId,
      profileId: event.profileId,
      accessId: event.accessId,
      action: event.action === "REVOKED" ? "REVOKED" : "GRANTED",
      actorUserId: event.actorUserId,
      actorDisplay: event.actorDisplay,
      actorLabel: actor?.fullName || actor?.email || event.actorDisplay || event.actorUserId || "System",
      note: event.note,
      createdAt: event.createdAt.toISOString()
    };
  });

  return {
    profiles: profiles.map(mapProfile),
    events: eventList
  };
}
