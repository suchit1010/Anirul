/* eslint-disable @typescript-eslint/no-explicit-any, @typescript-eslint/no-unused-vars */

/**
 * Trend Detection Engine
 * 
 * Detects:
 * - Worsening/stable/improving trends in individual labs
 * - Multi-test abnormalities (e.g., elevated glucose + insulin together)
 * - Pattern recognition (e.g., declining kidney function)
 * - Acceleration of decline (trend getting worse faster)
 */

import { prisma } from './prisma';

type NormalizedLabValue = any;

export type TrendType = 'improving' | 'stable' | 'worsening';

export interface LabTrendAnalysis {
  labName: string;
  trend: TrendType;
  valueCount: number;
  oldestValue: number;
  latestValue: number;
  referenceMin?: number;
  referenceMax?: number;
  daysAnalyzed: number;
  trendStrength: 'weak' | 'moderate' | 'strong'; // based on rate of change
  acceleration?: 'accelerating' | 'decelerating'; // rate of change is changing
}

export interface MultiTestPattern {
  patternName: string;
  severity: 'low' | 'moderate' | 'high';
  tests: Array<{ labName: string; status: string; value: number }>;
  clinicalImplication: string;
}

/**
 * Analyze trend for a single lab test
 * Returns direction (improving/stable/worsening) and strength
 */
export function analyzeSingleLabTrend(
  values: NormalizedLabValue[]
): TrendType {
  if (values.length < 2) return 'stable';

  const sorted = [...values].sort(
    (a, b) => new Date(a.testDate).getTime() - new Date(b.testDate).getTime()
  );

  const oldest = sorted[0];
  const newest = sorted[sorted.length - 1];

  // Compare status and values
  const oldestNormal = oldest.status === 'NORMAL';
  const newestNormal = newest.status === 'NORMAL';
  const oldestCritical = oldest.status === 'CRITICAL';
  const newestCritical = newest.status === 'CRITICAL';

  // If both critical or both normal with minimal change
  if (oldestNormal && newestNormal) {
    const change = Math.abs(newest.value - oldest.value);
    const range = Math.abs((oldest.referenceRangeMax || 0) - (oldest.referenceRangeMin || 0));
    return change / (range || 1) < 0.1 ? 'stable' : 'worsening';
  }

  // Worsening: normal → abnormal or abnormal → worse abnormal
  if (oldestNormal && !newestNormal) {
    return 'worsening';
  }
  if (oldestCritical && newestCritical) {
    return 'worsening'; // Still critical
  }
  if (
    (oldest.status === 'LOW' || oldest.status === 'HIGH') &&
    newestCritical
  ) {
    return 'worsening'; // Escalated to critical
  }

  // Improving: abnormal → normal or worse → less worse
  if (!oldestNormal && newestNormal) {
    return 'improving';
  }
  if (
    newestCritical === false &&
    (oldest.status === 'CRITICAL')
  ) {
    return 'improving'; // Stepped down from critical
  }

  // Both abnormal but moving toward normal
  if (oldest.referenceMin !== null && oldest.referenceMax !== null) {
    const midpoint = (oldest.referenceMin + oldest.referenceMax) / 2;
    const oldestDist = Math.abs(oldest.value - midpoint);
    const newestDist = Math.abs(newest.value - midpoint);
    return newestDist < oldestDist ? 'improving' : 'worsening';
  }

  return 'stable';
}

/**
 * Calculate trend strength based on rate of change
 */
export function calculateTrendStrength(
  values: NormalizedLabValue[],
  daysAnalyzed: number
): 'weak' | 'moderate' | 'strong' {
  if (values.length < 2) return 'weak';

  const sorted = [...values].sort(
    (a, b) => new Date(a.testDate).getTime() - new Date(b.testDate).getTime()
  );

  const oldest = sorted[0];
  const newest = sorted[sorted.length - 1];

  // Calculate percentage change
  const change = Math.abs(newest.value - oldest.value);
  const pctChange = (change / Math.abs(oldest.value || 1)) * 100;

  // Normalize by time period
  const dailyChange = pctChange / (daysAnalyzed || 90);

  if (dailyChange > 0.5) return 'strong';
  if (dailyChange > 0.1) return 'moderate';
  return 'weak';
}

/**
 * Detect if change is accelerating or decelerating
 * Compares rate of change in first vs second half of period
 */
export function detectAcceleration(
  values: NormalizedLabValue[]
): 'accelerating' | 'decelerating' | null {
  if (values.length < 4) return null;

  const sorted = [...values].sort(
    (a, b) => new Date(a.testDate).getTime() - new Date(b.testDate).getTime()
  );

  const mid = Math.floor(sorted.length / 2);
  const firstHalf = sorted.slice(0, mid);
  const secondHalf = sorted.slice(mid);

  const firstChange = Math.abs(
    firstHalf[firstHalf.length - 1].value - firstHalf[0].value
  );
  const secondChange = Math.abs(
    secondHalf[secondHalf.length - 1].value - secondHalf[0].value
  );

  if (secondChange > firstChange * 1.2) return 'accelerating';
  if (secondChange < firstChange * 0.8) return 'decelerating';
  return null;
}

/**
 * Multi-test pattern detection
 * Identifies clinically relevant combinations of abnormalities
 */
export function detectMultiTestPatterns(
  normalizedLabs: NormalizedLabValue[]
): MultiTestPattern[] {
  const patterns: MultiTestPattern[] = [];
  const abnormalTests = new Map<string, NormalizedLabValue>();

  // Group abnormal tests by name
  normalizedLabs
    .filter((l) => l.status !== 'NORMAL')
    .forEach((lab) => {
      abnormalTests.set(lab.labName.toLowerCase(), lab);
    });

  // Pattern 1: Metabolic Syndrome (Glucose + Triglycerides)
  const glucose = abnormalTests.get('fasting glucose');
  const triglycerides = abnormalTests.get('triglycerides');
  if (glucose && triglycerides && glucose.status !== 'NORMAL' && triglycerides.status !== 'NORMAL') {
    patterns.push({
      patternName: 'Metabolic Dysregulation',
      severity: 'moderate',
      tests: [
        { labName: 'Fasting Glucose', status: glucose.status, value: glucose.value },
        { labName: 'Triglycerides', status: triglycerides.status, value: triglycerides.value },
      ],
      clinicalImplication:
        'Suggests insulin resistance. Recommend lifestyle intervention + dietary consultation.',
    });
  }

  // Pattern 2: Thyroid Dysfunction (TSH + Free T4)
  const tsh = abnormalTests.get('tsh');
  const freeT4 = abnormalTests.get('free t4');
  if (
    tsh &&
    freeT4 &&
    (tsh.status === 'HIGH' || tsh.status === 'CRITICAL' || freeT4.status === 'LOW')
  ) {
    patterns.push({
      patternName: 'Hypothyroidism',
      severity: tsh.status === 'CRITICAL' ? 'high' : 'moderate',
      tests: [
        { labName: 'TSH', status: tsh.status, value: tsh.value },
        { labName: 'Free T4', status: freeT4.status, value: freeT4.value },
      ],
      clinicalImplication: 'Requires thyroid hormone replacement. Endocrine referral recommended.',
    });
  }

  // Pattern 3: Kidney Disease (Creatinine + eGFR + Potassium)
  const creatinine = abnormalTests.get('creatinine');
  const egfr = abnormalTests.get('egfr');
  const potassium = abnormalTests.get('potassium');
  if (
    (creatinine?.status === 'HIGH' || egfr?.status === 'LOW') &&
    potassium
  ) {
    patterns.push({
      patternName: 'Chronic Kidney Disease Risk',
      severity: egfr?.status === 'CRITICAL' ? 'high' : 'moderate',
      tests: [
        ...(creatinine ? [{ labName: 'Creatinine', status: creatinine.status, value: creatinine.value }] : []),
        ...(egfr ? [{ labName: 'eGFR', status: egfr.status, value: egfr.value }] : []),
        { labName: 'Potassium', status: potassium.status, value: potassium.value },
      ],
      clinicalImplication:
        'Monitor kidney function closely. Nephrology referral if eGFR <30. Avoid NSAIDs.',
    });
  }

  // Pattern 4: Liver Dysfunction (ALT + AST + Bilirubin)
  const alt = abnormalTests.get('alt');
  const ast = abnormalTests.get('ast');
  const bilirubin = abnormalTests.get('bilirubin');
  if ((alt || ast) && bilirubin) {
    patterns.push({
      patternName: 'Hepatic Dysfunction',
      severity: bilirubin.status === 'HIGH' ? 'high' : 'moderate',
      tests: [
        ...(alt ? [{ labName: 'ALT', status: alt.status, value: alt.value }] : []),
        ...(ast ? [{ labName: 'AST', status: ast.status, value: ast.value }] : []),
        { labName: 'Bilirubin', status: bilirubin.status, value: bilirubin.value },
      ],
      clinicalImplication:
        'Investigate liver disease etiology. Consider imaging + viral serology. Reduce hepatotoxic medications.',
    });
  }

  // Pattern 5: Anemia (Hemoglobin + MCV if available)
  const hemoglobin = abnormalTests.get('hemoglobin');
  if (hemoglobin && hemoglobin.status === 'LOW') {
    patterns.push({
      patternName: 'Anemia',
      severity: hemoglobin.status === 'CRITICAL' ? 'high' : 'moderate',
      tests: [
        { labName: 'Hemoglobin', status: hemoglobin.status, value: hemoglobin.value },
      ],
      clinicalImplication:
        'Determine etiology (iron deficiency, B12 deficiency, chronic disease). Iron studies + serum B12 recommended.',
    });
  }

  return patterns;
}

/**
 * Comprehensive trend analysis for a patient
 */
export async function analyzeTrendsForPatient(
  workspaceId: string,
  patientId: string,
  days: number = 90
) {
  const since = new Date();
  since.setDate(since.getDate() - days);

  const values = await prisma.normalizedLabValue.findMany({
    where: {
      workspaceId,
      patientId,
      testDate: { gte: since },
    },
    orderBy: { testDate: 'asc' },
  });

  if (values.length === 0) {
    return {
      patientId,
      labTrends: [],
      patterns: [],
      summary: 'No lab data available for trend analysis',
    };
  }

  // Group by lab name
  const byLab = new Map<string, NormalizedLabValue[]>();
  values.forEach((v: any) => {
    if (!byLab.has(v.labName)) {
      byLab.set(v.labName, []);
    }
    byLab.get(v.labName)!.push(v);
  });

  // Analyze each lab
  const labTrends: LabTrendAnalysis[] = [];
  byLab.forEach((labValues, labName) => {
    const trend = analyzeSingleLabTrend(labValues);
    const strength = calculateTrendStrength(labValues, days);
    const acceleration = detectAcceleration(labValues);

    const sorted = [...labValues].sort(
      (a, b) => new Date(a.testDate).getTime() - new Date(b.testDate).getTime()
    );

    labTrends.push({
      labName,
      trend,
      valueCount: labValues.length,
      oldestValue: sorted[0].value,
      latestValue: sorted[sorted.length - 1].value,
      referenceMin: sorted[0].referenceRangeMin ?? undefined,
      referenceMax: sorted[0].referenceRangeMax ?? undefined,
      daysAnalyzed: days,
      trendStrength: strength,
      acceleration: acceleration ?? undefined,
    });
  });

  // Detect multi-test patterns
  const abnormalLabs = values.filter((v: any) => v.status !== 'NORMAL');
  const patterns = detectMultiTestPatterns(abnormalLabs);

  return {
    patientId,
    daysAnalyzed: days,
    totalTests: values.length,
    uniqueTests: byLab.size,
    labTrends: labTrends.sort((a, b) => (a.trend === 'worsening' ? -1 : 1)),
    patterns,
    worseningTrends: labTrends.filter((t) => t.trend === 'worsening'),
    improvingTrends: labTrends.filter((t) => t.trend === 'improving'),
  };
}
