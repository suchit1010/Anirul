/**
 * Clinical Risk Scoring Engine
 * 
 * Calculates risk scores for:
 * - Diabetes & glucose control
 * - Chronic Kidney Disease (CKD)
 * - Cardiovascular Disease (CVD)
 * - Liver Disease
 * - General metabolic risk
 * 
 * Scores are 0-100, aligned with clinical guidelines
 */

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type NormalizedLabValue = any;

export type RiskCategory = 'DIABETES' | 'CKD' | 'CVD' | 'LIVER' | 'GENERAL';
export type RiskLevel = 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';

export interface RiskScore {
  category: RiskCategory;
  level: RiskLevel;
  score: number;
  maxScore: number;
  percentage: number;
  contributingFactors: string[];
  recommendations: string[];
}

/**
 * Diabetes Risk Score (0-100)
 * Based on: Fasting glucose, HbA1c, triglycerides, BMI (if available)
 */
export function calculateDiabetesRisk(
  labs: NormalizedLabValue[]
): RiskScore {
  let score = 0;
  const factors: string[] = [];
  const recommendations: string[] = [];

  const hba1c = labs.find((l) => l.labName.toLowerCase() === 'hba1c');
  const fastingGlucose = labs.find(
    (l) => l.labName.toLowerCase() === 'fasting glucose'
  );
  const triglycerides = labs.find(
    (l) => l.labName.toLowerCase() === 'triglycerides'
  );

  // HbA1c scoring
  if (hba1c) {
    if (hba1c.value > 9.0) {
      score += 40;
      factors.push('HbA1c > 9% (very poor control)');
    } else if (hba1c.value > 7.5) {
      score += 30;
      factors.push('HbA1c 7.5-9% (suboptimal control)');
    } else if (hba1c.value > 6.5) {
      score += 15;
      factors.push('HbA1c 6.5-7.5% (imperfect control)');
    } else if (hba1c.value < 5.7) {
      score += 0;
      factors.push('HbA1c normal');
    } else {
      score += 5;
      factors.push('HbA1c prediabetic range (5.7-6.5%)');
    }
  }

  // Fasting glucose scoring
  if (fastingGlucose) {
    if (fastingGlucose.value > 200) {
      score += 35;
      factors.push('Fasting glucose > 200 mg/dL (critical)');
    } else if (fastingGlucose.value > 126) {
      score += 25;
      factors.push('Fasting glucose > 126 mg/dL (uncontrolled)');
    } else if (fastingGlucose.value > 100) {
      score += 10;
      factors.push('Fasting glucose > 100 mg/dL (impaired)');
    }
  }

  // Triglycerides scoring (metabolic component)
  if (triglycerides) {
    if (triglycerides.value > 400) {
      score += 15;
      factors.push('Triglycerides > 400 mg/dL (severe)');
      recommendations.push('Consider fibrate therapy if on metformin');
    } else if (triglycerides.value > 200) {
      score += 10;
      factors.push('Triglycerides > 200 mg/dL (elevated)');
    }
  }

  const level: RiskLevel =
    score >= 80 ? 'CRITICAL' : score >= 60 ? 'HIGH' : score >= 30 ? 'MODERATE' : 'LOW';

  recommendations.push(
    'Diabetes screening/management essential',
    'Recommend HbA1c testing every 3 months if diabetic',
    'Lifestyle intervention: diet + exercise',
    'Endocrinology referral if HbA1c > 9%'
  );

  return {
    category: 'DIABETES',
    level,
    score: Math.min(score, 100),
    maxScore: 100,
    percentage: Math.min(score, 100),
    contributingFactors: factors,
    recommendations,
  };
}

/**
 * CKD Risk Score (0-100)
 * Based on: eGFR, Creatinine, Potassium, Urine protein (if available)
 */
export function calculateCKDRisk(labs: NormalizedLabValue[]): RiskScore {
  let score = 0;
  const factors: string[] = [];
  const recommendations: string[] = [];

  const egfr = labs.find((l) => l.labName.toLowerCase() === 'egfr');
  const creatinine = labs.find((l) => l.labName.toLowerCase() === 'creatinine');
  const potassium = labs.find((l) => l.labName.toLowerCase() === 'potassium');

  // eGFR staging (KDIGO)
  if (egfr) {
    if (egfr.value < 15) {
      score += 100;
      factors.push('eGFR < 15 (Stage 5 - End Stage Renal Disease)');
      recommendations.push('URGENT: Nephrology referral for dialysis/transplant evaluation');
    } else if (egfr.value < 30) {
      score += 80;
      factors.push('eGFR 15-29 (Stage 4 - Severe CKD)');
      recommendations.push('Immediate nephrology referral');
    } else if (egfr.value < 45) {
      score += 60;
      factors.push('eGFR 30-44 (Stage 3b - Moderate-severe CKD)');
      recommendations.push('Nephrology consultation recommended');
    } else if (egfr.value < 60) {
      score += 40;
      factors.push('eGFR 45-59 (Stage 3a - Moderate CKD)');
      recommendations.push('Monitor kidney function every 6 months');
    } else if (egfr.value < 90) {
      score += 10;
      factors.push('eGFR 60-89 (Stage 2 - Mild CKD)');
    }
  }

  // Creatinine elevation
  if (creatinine && creatinine.status !== 'NORMAL') {
    score += 20;
    factors.push(`Elevated creatinine: ${creatinine.value} ${creatinine.unit}`);
  }

  // Potassium abnormality (sign of declining kidney function)
  if (potassium) {
    if (potassium.status === 'CRITICAL' || potassium.value > 6.5) {
      score += 25;
      factors.push('Critical hyperkalemia (K+ > 6.5 mEq/L)');
      recommendations.push('URGENT: Check for life-threatening arrhythmias (ECG)');
    } else if (potassium.status === 'HIGH') {
      score += 15;
      factors.push('Elevated potassium');
      recommendations.push('Restrict potassium intake, consider potassium binders');
    }
  }

  const level: RiskLevel =
    score >= 80 ? 'CRITICAL' : score >= 60 ? 'HIGH' : score >= 30 ? 'MODERATE' : 'LOW';

  recommendations.push(
    'Avoid NSAIDs (ibuprofen, naproxen)',
    'Blood pressure target: <130/80 mmHg',
    'ACE inhibitor or ARB therapy recommended'
  );

  return {
    category: 'CKD',
    level,
    score: Math.min(score, 100),
    maxScore: 100,
    percentage: Math.min(score, 100),
    contributingFactors: factors,
    recommendations,
  };
}

/**
 * CVD Risk Score (0-100)
 * Based on: LDL, HDL, Total Cholesterol, Triglycerides, Blood pressure indicators
 */
export function calculateCVDRisk(labs: NormalizedLabValue[]): RiskScore {
  let score = 0;
  const factors: string[] = [];
  const recommendations: string[] = [];

  const ldl = labs.find((l) => l.labName.toLowerCase() === 'ldl cholesterol');
  const hdl = labs.find((l) => l.labName.toLowerCase() === 'hdl cholesterol');
  const totalChol = labs.find(
    (l) => l.labName.toLowerCase() === 'total cholesterol'
  );
  const triglycerides = labs.find(
    (l) => l.labName.toLowerCase() === 'triglycerides'
  );

  // LDL scoring (main driver of CVD risk)
  if (ldl) {
    if (ldl.value > 190) {
      score += 50;
      factors.push('LDL > 190 mg/dL (very high)');
      recommendations.push('High-intensity statin therapy (atorvastatin 80mg or rosuvastatin 20-40mg)');
    } else if (ldl.value > 160) {
      score += 35;
      factors.push('LDL 160-189 mg/dL (high)');
      recommendations.push('Moderate-high intensity statin');
    } else if (ldl.value > 130) {
      score += 20;
      factors.push('LDL 130-159 mg/dL (borderline high)');
    } else if (ldl.value > 100) {
      score += 10;
      factors.push('LDL 100-129 mg/dL (suboptimal)');
    }
  }

  // HDL scoring (protective factor)
  if (hdl) {
    if (hdl.value < 40) {
      score += 20;
      factors.push('Low HDL (< 40 mg/dL in males)');
    } else if (hdl.value < 50) {
      score += 10;
      factors.push('Low HDL (< 50 mg/dL in females)');
    }
  }

  // Triglycerides (emerging risk factor)
  if (triglycerides && triglycerides.value > 150) {
    score += 15;
    factors.push(`Elevated triglycerides: ${triglycerides.value} mg/dL`);
  }

  // Total cholesterol
  if (totalChol && totalChol.value > 240) {
    score += 10;
    factors.push('Total cholesterol > 240 mg/dL');
  }

  const level: RiskLevel =
    score >= 70 ? 'CRITICAL' : score >= 50 ? 'HIGH' : score >= 20 ? 'MODERATE' : 'LOW';

  recommendations.push(
    'Cardiovascular risk assessment recommended',
    'Consider aspirin if high-risk and no contraindications',
    'Lifestyle: reduce saturated fats, increase fiber, exercise 150 min/week',
    'Monitor BP target: <140/90 mmHg (or <130/80 if diabetes)'
  );

  return {
    category: 'CVD',
    level,
    score: Math.min(score, 100),
    maxScore: 100,
    percentage: Math.min(score, 100),
    contributingFactors: factors,
    recommendations,
  };
}

/**
 * Liver Disease Risk Score (0-100)
 * Based on: ALT, AST, Bilirubin, Albumin (if available)
 */
export function calculateLiverRisk(labs: NormalizedLabValue[]): RiskScore {
  let score = 0;
  const factors: string[] = [];
  const recommendations: string[] = [];

  const alt = labs.find((l) => l.labName.toLowerCase() === 'alt');
  const ast = labs.find((l) => l.labName.toLowerCase() === 'ast');
  const bilirubin = labs.find((l) => l.labName.toLowerCase() === 'bilirubin');

  // ALT/AST elevation
  if (alt && alt.value > 40) {
    const ratio = ast ? alt.value / ast.value : 1;
    if (alt.value > 200) {
      score += 60;
      factors.push(`ALT > 200 U/L (severe elevation)`);
      recommendations.push('Investigate: viral hepatitis, autoimmune hepatitis, drug toxicity');
    } else if (alt.value > 100) {
      score += 40;
      factors.push(`ALT 100-200 U/L (moderate elevation)`);
    } else {
      score += 20;
      factors.push(`ALT > 40 U/L (mild elevation)`);
    }

    // AST/ALT ratio suggests cirrhosis if > 2
    if (ratio > 2) {
      score += 20;
      factors.push('AST/ALT ratio > 2 (cirrhosis pattern)');
      recommendations.push('Urgent hepatology referral for cirrhosis assessment');
    }
  }

  // Bilirubin elevation
  if (bilirubin && bilirubin.value > 1.2) {
    if (bilirubin.value > 3) {
      score += 50;
      factors.push(`Bilirubin > 3 mg/dL (severe)`);
    } else {
      score += 20;
      factors.push(`Bilirubin ${bilirubin.value} mg/dL (elevated)`);
    }
  }

  const level: RiskLevel =
    score >= 80 ? 'CRITICAL' : score >= 60 ? 'HIGH' : score >= 20 ? 'MODERATE' : 'LOW';

  recommendations.push(
    'Reduce hepatotoxic medications',
    'Avoid alcohol',
    'Viral serology (HBsAg, Anti-HCV) if not done',
    'Consider imaging (ultrasound) if ALT > 100'
  );

  return {
    category: 'LIVER',
    level,
    score: Math.min(score, 100),
    maxScore: 100,
    percentage: Math.min(score, 100),
    contributingFactors: factors,
    recommendations,
  };
}

/**
 * Calculate all relevant risk scores for a patient
 */
export function calculateAllRiskScores(
  labs: NormalizedLabValue[]
): RiskScore[] {
  return [
    calculateDiabetesRisk(labs),
    calculateCKDRisk(labs),
    calculateCVDRisk(labs),
    calculateLiverRisk(labs),
  ];
}

/**
 * Get overall risk level based on all category scores
 */
export function getOverallRiskLevel(scores: RiskScore[]): RiskLevel {
  const maxScore = Math.max(...scores.map((s) => s.score));

  if (maxScore >= 80) return 'CRITICAL';
  if (maxScore >= 60) return 'HIGH';
  if (maxScore >= 30) return 'MODERATE';
  return 'LOW';
}
