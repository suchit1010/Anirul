import { type Session } from "@supabase/supabase-js";
import { prisma } from "@/lib/prisma";

export async function ensureUserProfileFromSession(session: Session) {
  return prisma.userProfile.upsert({
    where: { id: session.user.id },
    update: {
      email: session.user.email ?? undefined
    },
    create: {
      id: session.user.id,
      email: session.user.email ?? null
    }
  });
}
