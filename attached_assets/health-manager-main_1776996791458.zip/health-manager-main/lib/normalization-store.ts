/**
 * Clinical Normalization Store
 * 
 * Handles:
 * - Persisting normalized lab values to database
 * - Retrieving normalization history for trend analysis
 * - Managing reference range metadata
 * - Querying abnormal/critical values for risk scoring
 */

import { prisma } from './prisma';
import {
  normalizeLabValues,
  type NormalizedLabValue,
  getAllReferenceRanges,
} from './clinical-normalization';
import type { NormalizedLabValue as PrismaNormalizedLabValue } from '@prisma/client';

/**
 * Persist normalized lab values to database
 */
export async function persistNormalizedLabValues(
  workspaceId: string,
  patientId: string | undefined,
  labs: NormalizedLabValue[]
) {
  const created = await Promise.all(
    labs.map((lab) =>
      prisma.normalizedLabValue.create({
        data: {
          workspaceId,
          patientId,
          testDate: lab.testDate,
          labName: lab.labName,
          rawValue: lab.rawValue,
          value: lab.value,
          unit: lab.unit,
          referenceRangeMin: lab.referenceMin,
          referenceRangeMax: lab.referenceMax,
          status: lab.status,
          ageYears: lab.ageYears,
          sex: lab.sex,
          populationGroup: lab.populationGroup,
          notes: lab.notes,
        },
      })
    )
  );

  return created;
}

/**
 * Normalize and persist lab values extracted from documents
 * Returns the persisted normalized records
 */
export async function normalizeAndPersistLabValues(
  workspaceId: string,
  patientId: string | undefined,
  extractedLabs: Array<{
    labName: string;
    rawValue: string;
    unit: string;
    testDate: Date;
    ageYears?: number;
    sex?: 'M' | 'F';
  }>
) {
  // Normalize in-memory
  const normalized = normalizeLabValues(extractedLabs);

  // Persist
  const persisted = await persistNormalizedLabValues(
    workspaceId,
    patientId,
    normalized
  );

  return persisted;
}

/**
 * Get normalized lab values for a workspace/patient
 */
export async function getNormalizedLabValues(
  workspaceId: string,
  patientId?: string,
  labName?: string,
  days: number = 90
) {
  const since = new Date();
  since.setDate(since.getDate() - days);

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const where: any = {
    workspaceId,
    testDate: { gte: since },
  };

  if (patientId) {
    where.patientId = patientId;
  }

  if (labName) {
    where.labName = {
      contains: labName,
      mode: 'insensitive',
    };
  }

  const values = await prisma.normalizedLabValue.findMany({
    where,
    orderBy: { testDate: 'desc' },
  });

  return values;
}

/**
 * Get abnormal lab values (potential clinical concerns)
 */
export async function getAbnormalLabValues(
  workspaceId: string,
  patientId?: string,
  days: number = 90
) {
  const values = await getNormalizedLabValues(
    workspaceId,
    patientId,
    undefined,
    days
  );

  return values.filter((v: PrismaNormalizedLabValue) => v.status !== 'NORMAL');
}

/**
 * Get critical lab values (require immediate attention)
 */
export async function getCriticalLabValues(
  workspaceId: string,
  patientId?: string
) {
  const values = await getNormalizedLabValues(
    workspaceId,
    patientId,
    undefined,
    365
  );

  return values.filter((v: PrismaNormalizedLabValue) => v.status === 'CRITICAL');
}

/**
 * Initialize reference ranges in database
 * Call once during setup to populate reference data
 */
export async function initializeReferenceRanges() {
  const existing = await prisma.labReferenceRange.count();
  if (existing > 0) {
    console.log('Reference ranges already initialized');
    return;
  }

  const ranges = getAllReferenceRanges();

  await Promise.all(
    ranges.map((r) =>
      prisma.labReferenceRange.create({
        data: {
          labName: r.labName,
          unit: r.unit,
          populationGroup: r.populationGroup,
          sexSpecific: r.sexSpecific,
          sexValue: r.sex,
          ageMin: r.ageMin,
          ageMax: r.ageMax,
          referenceMin: r.referenceMin,
          referenceMax: r.referenceMax,
          criticalLow: r.criticalLow,
          criticalHigh: r.criticalHigh,
          source: r.source,
        },
      })
    )
  );

  console.log(`Initialized ${ranges.length} lab reference ranges`);
}

/**
 * Get reference range for a specific test
 */
export async function getReferenceRange(
  labName: string,
  unit: string,
  populationGroup: string = 'INDIAN_ADULT',
  sex?: string,
  ageMin?: number,
  ageMax?: number
) {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const where: any = {
    labName,
    unit,
    populationGroup,
  };

  if (sex) {
    where.sexValue = sex;
  }

  if (ageMin !== undefined) {
    where.ageMin = ageMin;
  }

  if (ageMax !== undefined) {
    where.ageMax = ageMax;
  }

  return prisma.labReferenceRange.findFirst({
    where,
  });
}

/**
 * Get all available reference ranges for a lab test
 */
export async function getLabTestReferenceRanges(
  labName: string,
  unit?: string
) {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const where: any = { labName };

  if (unit) {
    where.unit = unit;
  }

  return prisma.labReferenceRange.findMany({
    where,
    orderBy: [
      { populationGroup: 'asc' },
      { sexValue: 'asc' },
      { ageMin: 'asc' },
    ],
  });
}

/**
 * Get lab value trend summary for a patient
 * Shows trajectory over time (improving, stable, worsening)
 */
export async function getLabValueTrend(
  workspaceId: string,
  patientId: string,
  labName: string,
  days: number = 90
) {
  const values = await getNormalizedLabValues(
    workspaceId,
    patientId,
    labName,
    days
  );

  if (values.length < 2) {
    return {
      labName,
      valueCount: values.length,
      latest: values[0] || null,
      trend: null,
    };
  }

  // Determine trend direction
  const oldest = values[values.length - 1];
  const newest = values[0];

  let trend: 'improving' | 'stable' | 'worsening' | null = null;

  if (oldest.value !== newest.value) {
    const oldestNormal = oldest.status === 'NORMAL';
    const newestNormal = newest.status === 'NORMAL';

    if (oldestNormal && newestNormal) {
      trend = 'stable';
    } else if (oldestNormal && !newestNormal) {
      trend = 'worsening';
    } else if (!oldestNormal && newestNormal) {
      trend = 'improving';
    } else {
      // Both abnormal - check if moving closer/further from range
      const midpoint =
        (oldest.referenceRangeMin || oldest.value +
          (oldest.referenceRangeMax || oldest.value - 1)) / 2;
      const oldestDist = Math.abs(oldest.value - midpoint);
      const newestDist = Math.abs(newest.value - midpoint);

      trend = newestDist < oldestDist ? 'improving' : 'worsening';
    }
  } else {
    trend = 'stable';
  }

  return {
    labName,
    valueCount: values.length,
    latest: newest,
    oldest,
    trend,
    allValues: values,
  };
}

/**
 * Get comprehensive lab summary for clinical dashboard
 */
export async function getLabSummary(
  workspaceId: string,
  patientId?: string,
  days: number = 90
) {
  const values = await getNormalizedLabValues(
    workspaceId,
    patientId,
    undefined,
    days
  );

  const abnormal = values.filter((v: PrismaNormalizedLabValue) => v.status !== 'NORMAL');
  const critical = values.filter((v: PrismaNormalizedLabValue) => v.status === 'CRITICAL');

  // Group by test name
  const byTest = new Map<string, typeof values>();
  values.forEach((v: PrismaNormalizedLabValue) => {
    if (!byTest.has(v.labName)) {
      byTest.set(v.labName, []);
    }
    byTest.get(v.labName)!.push(v);
  });

  return {
    totalTests: values.length,
    uniqueTests: byTest.size,
    abnormalCount: abnormal.length,
    criticalCount: critical.length,
    abnormalPercentage: (abnormal.length / values.length) * 100,
    abnormalTests: abnormal,
    criticalTests: critical,
    testDetails: Array.from(byTest.entries()).map(([name, vals]) => ({
      testName: name,
      recordCount: vals.length,
      latest: vals[0],
      abnormalCount: vals.filter((v: PrismaNormalizedLabValue) => v.status !== 'NORMAL').length,
    })),
  };
}
