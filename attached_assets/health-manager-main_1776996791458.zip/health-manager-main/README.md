# Anirul

Anirul is a Next.js company website for an India-first healthcare continuity intelligence platform.

## Stack

- Next.js 15 (App Router)
- TypeScript
- Plain CSS (custom Dune-inspired theme)
- Zod validation
- Resend transactional email delivery

## Features

- Cinematic landing page (`Anirul` brand theme)
- Multi-page company website: `/platform`, `/security`, `/pilots`, `/about`
- Live product workspace at `/product` with patient intake, timeline ingestion, and doctor-brief generation
- Shared workspace sync via `/api/workspaces` and `/api/workspaces/:id`
- Supabase-auth protected product/API access
- PostgreSQL-backed workspace persistence via Prisma
- Role-based workspace membership (`OWNER`, `EDITOR`, `VIEWER`)
- User profile API for role/persona metadata
- Email invite workflow with secure invite tokens
- Product narrative: what it does, why it matters, trust architecture
- Real contact form with server-side validation
- Real pilot lead form routed to CRM webhook
- Real email delivery integration (Resend)
- Optional analytics integrations (Plausible / Google Analytics)
- No mocked API responses

## Local development

```bash
cd /Users/kyto/4/frontier/swasthai-next
npm install
cp .env.example .env.local
npm run db:up
npm run db:generate
npm run db:migrate
npm run dev
```

Open `http://localhost:3000`.

## Product workspace (running MVP)

### New Simplified UI (Recommended) ✨

The new dashboard UI is clean, intuitive, and mobile-friendly. Start here:

```bash
# Quick start with admin bypass enabled
./scripts/quick-start.sh

# Then:
npm run dev
# Open http://localhost:3000/product-v2
```

**Features:**
- 📊 Dashboard with stat cards (Documents, Alerts, Tasks, Family)
- 📄 Step-by-step document ingestion wizard
- 📱 Fully responsive mobile design
- 🎯 Task-driven user flow (no overwhelming forms)
- 🌍 India healthcare-focused UX

👉 **[See full guide: NEW_UI_README.md](./NEW_UI_README.md)**

### Legacy UI (Full System)

For testing the complete backend (extraction, risk scoring, alerts, care tasks):

Open `http://localhost:3000/product` and use this flow:

1. Save patient profile (name, age, conditions, doctor).
2. Add timeline records (visit/lab/prescription/note).
3. Review generated doctor brief with continuity score, risk flags, and suggested actions.
4. Create a shared workspace ID, sync changes, and copy a share link for collaborators.
5. Add collaborators in **Workspace sharing** using their Supabase user ID and role.
6. Invite collaborators by email and share invite links that auto-accept for matching signed-in emails.
7. Manage access lifecycle by revoking/resending invites and changing/removing member roles.

Admin test entry:

- Open `http://localhost:3000/admin`.
- If your profile role is `ADMIN`, you are redirected to `/product` for full workflow testing.
- If not, the page shows your current role and prompts role upgrade before admin entry.

Direct no-login admin testing (local/dev only):

- Set these in `.env.local`:

```dotenv
DEV_ADMIN_BYPASS="true"
DEV_ADMIN_BYPASS_USER_ID="dev-admin-user"
DEV_ADMIN_BYPASS_EMAIL="admin@local.test"
```

- Restart dev server and open `http://localhost:3000/product` (or `/admin`).
- In this mode, auth-protected APIs use a synthetic admin test session when no real session exists.
- This bypass is disabled in production (`NODE_ENV=production`).

Notes:

- The MVP is fully interactive and persists in browser `localStorage`.
- Shared workspace data is persisted in PostgreSQL (owner-scoped per authenticated user).
- Workspace read access is member-based; write access is `OWNER` or `EDITOR`.
- Use **Load demo patient** to test instantly.
- Use **Copy brief** to export a consult-ready summary.

### Database (containerized local setup)

This project includes `docker-compose.yml` with a local Postgres service.

```bash
npm run db:up
npm run db:logs
```

When finished:

```bash
npm run db:down
```

Prisma workflow:

```bash
npm run db:generate
npm run db:migrate
```

## Configure contact delivery

Set env values in `.env.local`:

- `CONTACT_FROM_EMAIL`
- `CONTACT_TO_EMAIL`
- `RESEND_API_KEY`
- `DATABASE_URL`
- `CRM_WEBHOOK_URL`
- `CRM_WEBHOOK_BEARER_TOKEN` (optional)
- `NEXT_PUBLIC_PLAUSIBLE_DOMAIN` (optional)
- `NEXT_PUBLIC_GA_ID` (optional)
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`

If `RESEND_API_KEY` is missing, `/api/contact` returns an error by design because delivery is not configured.

## Build and run production

```bash
npm run build
npm start
```

## API

`POST /api/contact`

Payload:

```json
{
  "name": "Aanya Sharma",
  "email": "aanya@clinic.in",
  "company": "Sanjeevani Clinic",
  "interest": "pilot",
  "message": "We want to pilot Anirul for 3 physicians and chronic care workflows."
}
```

Allowed `interest` values:

- `pilot`
- `clinic`
- `enterprise`
- `investor`
- `media`
- `other`

`POST /api/lead`

Payload:

```json
{
  "fullName": "Aanya Sharma",
  "workEmail": "aanya@clinic.in",
  "organization": "Sanjeevani Clinic",
  "role": "COO",
  "monthlyPatients": "1k_5k",
  "objective": "We want to reduce duplicate diagnostics and improve consult preparation for chronic care workflows."
}
```

Allowed `monthlyPatients` values:

- `lt_1000`
- `1k_5k`
- `5k_20k`
- `20k_plus`

`POST /api/workspaces`

Creates a new shared product workspace and returns `workspaceId`.

`GET /api/workspaces/:workspaceId`

Loads a saved shared workspace.

`PUT /api/workspaces/:workspaceId`

Persists latest product state for that workspace.

`GET /api/workspaces/:workspaceId/members`

Returns workspace members for authenticated users who are members of that workspace.

`POST /api/workspaces/:workspaceId/members`

Adds or updates a member role (`EDITOR` or `VIEWER`). Only `OWNER` can add members.

Payload:

```json
{
  "userId": "supabase-user-uuid",
  "role": "EDITOR"
}
```

`PATCH /api/workspaces/:workspaceId/members/:memberUserId`

Updates a member role (`OWNER` only).

Payload:

```json
{
  "role": "VIEWER"
}
```

`DELETE /api/workspaces/:workspaceId/members/:memberUserId`

Removes a member (`OWNER` only).

`GET /api/workspaces/:workspaceId/invites`

Returns invite history for a workspace if the caller is a workspace member.

`POST /api/workspaces/:workspaceId/invites`

Creates a new email invite (`OWNER` only).

Payload:

```json
{
  "email": "doctor@clinic.com",
  "role": "VIEWER"
}
```

`PATCH /api/workspaces/:workspaceId/invites/:inviteId`

Revoke or resend an invite (`OWNER` only).

Payload:

```json
{
  "action": "revoke"
}
```

Allowed `action` values:

- `revoke`
- `resend`

`POST /api/workspace-invites/accept`

Accepts an invite token for the currently signed-in user if the invite email matches.

Payload:

```json
{
  "token": "inv_xxxxxxxxxxxxxxxxx"
}
```

`GET /api/me/profile`

Fetches or auto-creates the authenticated user's profile.

`PUT /api/me/profile`

Updates the authenticated user's profile metadata.

Payload:

```json
{
  "fullName": "Aanya Sharma",
  "role": "DOCTOR"
}
```

## Document Ingestion v1

Workspace members can now ingest clinical evidence from direct uploads, WhatsApp forwards, and audio transcripts for automatic extraction of structured health data.

### Flow

1. Upload a document via `POST /api/workspaces/:workspaceId/documents` (multipart; max 10 MB), or ingest text channels via:
  - `POST /api/workspaces/:workspaceId/documents/channels/whatsapp`
  - `POST /api/workspaces/:workspaceId/documents/channels/audio`
2. Document is stored on disk under `.data/uploads/:workspaceId/...` and indexed in the database with status `UPLOADED`.
3. Channel source metadata is persisted (`sourceChannel`, `sourceContext`) for auditability and workflow routing.
4. WhatsApp/audio channel text is normalized (Indic digit cleanup + common Hindi/English medical term normalization) before extraction.
5. Trigger extraction via `POST /api/workspaces/:workspaceId/documents/:documentId/extract`.
6. Backend parses PDF/text, applies regex-based extraction (HbA1c, fasting glucose, TSH, medications) and summarizes findings.
7. Job status transitions to `PROCESSING` → `COMPLETED` (or `FAILED` on error); extracted data is persisted.
8. List documents and extraction results via `GET /api/workspaces/:workspaceId/documents`.

### Endpoints

`GET /api/workspaces/:workspaceId/documents`

Returns list of documents for authenticated members.

Response:

```json
{
  "documents": [
    {
      "id": "doc_xxx",
      "workspaceId": "ws_xxx",
      "uploadedById": "user_xxx",
      "fileName": "lab_results.pdf",
      "status": "PROCESSED",
      "fileSize": 45000,
      "uploadedAt": "2025-04-18T08:00:00Z",
      "extractions": [
        {
          "id": "job_xxx",
          "status": "COMPLETED",
          "extractedData": {
            "labs": { "HbA1c": "7.2%", "fastingGlucose": "128 mg/dL" },
            "medications": ["Metformin", "Amlodipine"],
            "summary": "Well-controlled diabetes with hypertension..."
          },
          "createdAt": "2025-04-18T08:01:00Z"
        }
      ]
    }
  ]
}
```

`POST /api/workspaces/:workspaceId/documents`

Uploads a document. Multipart form with `file` field. Max file size: 10 MB. Allowed types: PDF, text.

Payload:

```
multipart/form-data
file: <binary PDF or text file>
```

Response:

```json
{
  "id": "doc_xxx",
  "workspaceId": "ws_xxx",
  "status": "UPLOADED",
  "fileName": "lab_results.pdf",
  "fileSize": 45000,
  "uploadedAt": "2025-04-18T08:00:00Z"
}
```

`POST /api/workspaces/:workspaceId/documents/channels/whatsapp`

Ingests forwarded WhatsApp clinical text and runs extraction immediately.

Payload:

```json
{
  "forwardedText": "Patient's HbA1c is 8.1% ...",
  "senderLabel": "Family Group"
}
```

`POST /api/workspaces/:workspaceId/documents/channels/audio`

Ingests voice-note transcript text and runs extraction immediately.

Payload:

```json
{
  "transcript": "Doctor said continue Metformin 500mg ...",
  "language": "hi-IN",
  "durationSeconds": 75
}
```

`POST /api/workspaces/:workspaceId/documents/:documentId/extract`

Triggers extraction job for a document.

Payload:

```json
{}
```

Response:

```json
{
  "jobId": "job_xxx",
  "documentId": "doc_xxx",
  "status": "QUEUED",
  "createdAt": "2025-04-18T08:00:00Z"
}
```

### Extraction Logic

The extraction pipeline uses:

- **PDF parsing**: `pdf-parse` v2 for text extraction from PDFs.
- **Regex-based structured extraction**: Patterns for lab values (HbA1c, fasting glucose, TSH), medications (keyword match against common drugs), and clinical summaries.
- **Job lifecycle**: Each document can have multiple extraction jobs; jobs persist status (`QUEUED` → `PROCESSING` → `COMPLETED`/`FAILED`) and extracted data.

### Storage

- Documents are stored in `.data/uploads/:workspaceId/:documentId/:fileName` on disk.
- Metadata and extraction results are persisted in PostgreSQL via Prisma.
- Future v2 will integrate cloud storage (S3) and async processing (SQS/background workers).

## Clinical Normalization v1

Extracted lab values are automatically normalized against **age/sex-adjusted reference ranges** for Indian populations, enabling clinical decision support and risk detection.

### Flow

1. Extract lab values from documents (via Document Ingestion v1).
2. Normalize against reference ranges (WHO + ICMR adapted for India):
   - Age-adjusted (child, adult, elderly tiers)
   - Sex-specific where applicable
   - Population-group aware
3. Flag abnormalities (`LOW`, `HIGH`, `CRITICAL`) for clinical attention.
4. Store normalized values with reference metadata for trend analysis and risk scoring.

### Reference Ranges

Comprehensive coverage for India-relevant tests:
- **Endocrine**: Glucose, HbA1c, TSH, Free T3, Free T4
- **Lipid panel**: Total cholesterol, LDL, HDL, Triglycerides
- **Kidney function**: Creatinine, BUN, eGFR
- **Liver function**: ALT, AST, Bilirubin, Alkaline Phosphatase
- **Hematology**: Hemoglobin, WBC, Platelet count
- **Electrolytes**: Sodium, Potassium, Calcium, Phosphate
- **Other**: Uric acid

All ranges based on WHO guidelines adapted for Indian populations (ICMR).

### Endpoints

`GET /api/workspaces/:workspaceId/labs/normalized`

Fetches normalized lab values with optional filtering and trend analysis.

Query parameters:
- `type`: `all` (default) | `abnormal` | `critical` | `summary` | `trend`
- `patientId`: filter by patient
- `labName`: filter by specific test
- `days`: lookback window (default: 90)

Response example (type=summary):

```json
{
  "totalTests": 45,
  "uniqueTests": 12,
  "abnormalCount": 8,
  "criticalCount": 1,
  "abnormalPercentage": 17.8,
  "criticalTests": [
    {
      "id": "nlv_xxx",
      "labName": "Potassium",
      "value": 6.8,
      "unit": "mEq/L",
      "status": "CRITICAL",
      "referenceRangeMin": 3.5,
      "referenceRangeMax": 5.0,
      "testDate": "2025-04-18T08:00:00Z"
    }
  ],
  "testDetails": [
    {
      "testName": "HbA1c",
      "recordCount": 3,
      "latest": { ...normalized value },
      "abnormalCount": 1
    }
  ]
}
```

`GET /api/workspaces/:workspaceId/labs/reference-ranges`

Fetches available reference ranges for a given test.

Query parameters:
- `labName`: test name (required)
- `unit`: unit filter (optional)

Response:

```json
{
  "labName": "HbA1c",
  "unit": "%",
  "ranges": [
    {
      "populationGroup": "INDIAN_ADULT",
      "sexSpecific": false,
      "referenceMin": 4.0,
      "referenceMax": 5.6,
      "criticalLow": 2.0,
      "criticalHigh": 15.0,
      "source": "ICMR Diabetes Guidelines"
    }
  ]
}
```

`GET /api/workspaces/:workspaceId/clinical-summary`

Builds a workspace clinical summary with risk scores, active alerts, trends, and recommendations.

Query parameters:
- `patientId`: patient identifier used for normalized lab/risk lookups (defaults to workspace ID)
- `ageYears`: optional age to improve risk context
- `sex`: optional sex hint (`M` or `F`)

Response example:

```json
{
  "ok": true,
  "summary": {
    "patientId": "Aarav Mehta",
    "overallRiskLevel": "HIGH",
    "summary": {
      "totalAbnormalLabs": 12,
      "worseningTrends": 3,
      "clinicalPatterns": 2,
      "riskCategories": 4,
      "activeAlerts": 5,
      "criticalValues": 1
    },
    "riskScores": [
      {
        "category": "DIABETES",
        "level": "HIGH",
        "score": 78,
        "recommendations": ["HbA1c every 3 months"]
      }
    ]
  }
}
```

`GET /api/workspaces/:workspaceId/clinical-alerts`

Fetches clinical alerts for a workspace.

Query parameters:
- `patientId`: optional patient filter
- `severity`: optional (`LOW`, `MODERATE`, `HIGH`, `CRITICAL`)
- `status`: optional (`active`, `acknowledged`, `resolved`, `all`; defaults to `active`)
- `includeResolved`: optional (`true`/`false`, backward compatibility; equivalent to `status=all`)

`PATCH /api/workspaces/:workspaceId/clinical-alerts/:alertId`

Acknowledges or resolves an alert (allowed for `OWNER`/`EDITOR`, not `VIEWER`).

Payload:

```json
{
  "action": "acknowledge"
}
```

Allowed `action` values:

- `acknowledge`
- `resolve`

`GET /api/workspaces/:workspaceId/clinical-alerts/:alertId/events`

Fetches immutable audit timeline entries for an alert (`CREATED`, `ACKNOWLEDGED`, `RESOLVED`) including actor and timestamp metadata.

Query parameters:
- `action`: optional (`CREATED`, `ACKNOWLEDGED`, `RESOLVED`, `all`)
- `from`: optional ISO datetime lower bound
- `to`: optional ISO datetime upper bound
- `page`: optional positive integer (defaults to `1`)
- `pageSize`: optional positive integer up to `100` (defaults to `10`)

Response includes:
- `events`: paginated event list for the requested page
- `pagination`: `{ page, pageSize, total, totalPages, hasMore }`

`GET /api/workspaces/:workspaceId/consents`

Fetches consent grants and immutable consent events for a workspace.

Query parameters:
- `status`: optional (`ACTIVE`, `REVOKED`, `EXPIRED`, `all`; defaults to `all`)

`POST /api/workspaces/:workspaceId/consents`

Creates a new consent grant (allowed for `OWNER`/`EDITOR`, not `VIEWER`).

Payload:

```json
{
  "subjectName": "Dr. Mehta",
  "subjectContact": "doctor@clinic.com",
  "purpose": "Cardiology pre-consult review",
  "scopes": ["DOCTOR_BRIEF", "LAB_TRENDS"],
  "expiresAt": "2026-12-31T23:59:59.999Z"
}
```

Allowed `scopes` values:
- `DOCTOR_BRIEF`
- `FULL_TIMELINE`
- `LAB_TRENDS`
- `ALERTS`
- `DOCUMENTS`

`PATCH /api/workspaces/:workspaceId/consents/:consentId`

Revokes an active consent (allowed for `OWNER`/`EDITOR`, not `VIEWER`).

Payload:

```json
{
  "action": "revoke",
  "reason": "Revoked from workspace consent panel"
}
```

`GET /api/workspaces/:workspaceId/care-tasks`

Fetches care-plan reminders and immutable task events for a workspace.

Query parameters:
- `status`: optional (`PENDING`, `COMPLETED`, `SKIPPED`, `all`; defaults to `all`)
- `patientId`: optional patient filter

`POST /api/workspaces/:workspaceId/care-tasks`

Creates a care-plan reminder task (allowed for `OWNER`/`EDITOR`, not `VIEWER`).

Payload:

```json
{
  "patientId": "Aarav Mehta",
  "title": "Repeat HbA1c",
  "description": "Book follow-up once result is available",
  "dueAt": "2026-05-15T23:59:59.999Z",
  "priority": "HIGH",
  "source": "ALERT_FOLLOWUP"
}
```

Allowed `priority` values:
- `LOW`
- `MODERATE`
- `HIGH`

Allowed `source` values:
- `MANUAL`
- `ALERT_FOLLOWUP`
- `RISK_FOLLOWUP`

`PATCH /api/workspaces/:workspaceId/care-tasks/:taskId`

Updates task lifecycle state (allowed for `OWNER`/`EDITOR`, not `VIEWER`).

Payload:

```json
{
  "action": "complete"
}
```

Allowed `action` values:
- `complete`
- `skip`
- `reopen`

`GET /api/workspaces/:workspaceId/duplicate-test-check`

Fetches recent duplicate-test check history for a workspace.

Query parameters:
- `patientId`: optional patient filter
- `limit`: optional result limit (1-100, defaults to `20`)

`POST /api/workspaces/:workspaceId/duplicate-test-check`

Runs duplicate-test prevention check against recent normalized labs and stores an auditable recommendation.

Payload:

```json
{
  "patientId": "Aarav Mehta",
  "labName": "HbA1c",
  "lookbackDays": 90
}
```

`GET /api/workspaces/:workspaceId/family-profiles`

Fetches family profiles with delegated access grants and immutable access events.

`POST /api/workspaces/:workspaceId/family-profiles`

Creates a family profile and automatically grants creator as primary `MANAGER`.

Payload:

```json
{
  "fullName": "Meera Sharma",
  "ageYears": 62,
  "sex": "F",
  "relation": "PARENT",
  "notes": "Hypertension follow-up managed by daughter"
}
```

Allowed `relation` values:
- `SELF`
- `SPOUSE`
- `CHILD`
- `PARENT`
- `SIBLING`
- `OTHER`

`PATCH /api/workspaces/:workspaceId/family-profiles/:profileId/access`

Grants or revokes delegated profile access for an existing workspace member (`OWNER`/`EDITOR` only).

Payload:

```json
{
  "action": "grant",
  "targetUserId": "00000000-0000-0000-0000-000000000000",
  "role": "VIEWER"
}
```

Allowed `action` values:
- `grant`
- `revoke`

Allowed `role` values:
- `MANAGER`
- `VIEWER`

### Normalization Logic

- **Reference match**: Find age/sex/population-adjusted range for the test
- **Status flag**: Compare value against reference range:
  - `NORMAL`: within range
  - `LOW`: below range (or critical if below criticalLow)
  - `HIGH`: above range (or critical if above criticalHigh)
  - `CRITICAL`: outside critical thresholds (requires immediate clinical attention)
- **Persistent storage**: Normalized values stored with all metadata for trend/risk analysis

### Database Schema

- `NormalizedLabValue`: Stores normalized lab values with status, reference range metadata, and patient context
- `LabReferenceRange`: Canonical reference range definitions (ages, sexes, populations, sources)

## Project structure

- `app/page.tsx` — landing page
- `app/platform/page.tsx` — platform page
- `app/security/page.tsx` — security page
- `app/pilots/page.tsx` — pilot application page
- `app/about/page.tsx` — about page
- `app/product/page.tsx` — live product workspace page
- `components/contact-form.tsx` — client form
- `components/lead-form.tsx` — pilot lead form
- `components/product-workspace.tsx` — in-browser product workflow UI
- `components/site-header.tsx` — shared top navigation
- `components/site-footer.tsx` — shared footer
- `app/api/contact/route.ts` — server endpoint
- `app/api/lead/route.ts` — CRM lead webhook endpoint
- `app/api/workspaces/route.ts` — create shared workspace endpoint
- `app/api/workspaces/[workspaceId]/route.ts` — load/save workspace endpoint
- `app/api/workspaces/[workspaceId]/members/route.ts` — list/add workspace members
- `app/api/workspaces/[workspaceId]/members/[memberUserId]/route.ts` — update/remove member
- `app/api/workspaces/[workspaceId]/invites/route.ts` — list/create workspace invites
- `app/api/workspaces/[workspaceId]/invites/[inviteId]/route.ts` — revoke/resend invite
- `app/api/workspace-invites/accept/route.ts` — accept invite token
- `app/api/me/profile/route.ts` — read/update user profile
- `lib/prisma.ts` — Prisma + Postgres adapter client
- `lib/user-profile.ts` — profile upsert helper
- `lib/contact.ts` — schema + email delivery
- `lib/lead.ts` — schema + CRM webhook delivery
- `lib/product-engine.ts` — continuity logic + brief generator
- `lib/workspace-store.ts` — PostgreSQL-backed shared workspace persistence
- `lib/document-ingestion.ts` — PDF/text extraction logic and data parsing
- `lib/document-store.ts` — document persistence and extraction job orchestration
- `app/api/workspaces/[workspaceId]/documents/route.ts` — list/upload documents
- `app/api/workspaces/[workspaceId]/documents/[documentId]/extract/route.ts` — trigger extraction
- `app/api/workspaces/[workspaceId]/documents/channels/whatsapp/route.ts` — ingest WhatsApp forwarded text
- `app/api/workspaces/[workspaceId]/documents/channels/audio/route.ts` — ingest audio transcript text
- `lib/clinical-normalization.ts` — lab value normalization against reference ranges
- `lib/normalization-store.ts` — normalization persistence and clinical insights querying
- `lib/risk-scoring.ts` — diabetes/CKD/CVD/liver risk scoring engine
- `lib/trend-detection.ts` — trend analysis and multi-test pattern detection
- `lib/risk-store.ts` — clinical risk persistence and summary generation
- `lib/consent-store.ts` — consent grant lifecycle and immutable consent event store
- `lib/care-plan-store.ts` — care reminder task lifecycle and immutable task event store
- `lib/duplicate-test-store.ts` — duplicate test prevention rule engine and check history store
- `lib/family-store.ts` — family profile and delegated caregiver access lifecycle store
- `app/api/workspaces/[workspaceId]/labs/normalized/route.ts` — fetch normalized lab values
- `app/api/workspaces/[workspaceId]/labs/reference-ranges/route.ts` — fetch reference ranges
- `app/api/workspaces/[workspaceId]/clinical-summary/route.ts` — build clinical summary and risk dashboard data
- `app/api/workspaces/[workspaceId]/clinical-alerts/route.ts` — list clinical alerts with filters
- `app/api/workspaces/[workspaceId]/clinical-alerts/[alertId]/route.ts` — resolve a clinical alert
- `app/api/workspaces/[workspaceId]/clinical-alerts/[alertId]/events/route.ts` — fetch alert audit timeline events
- `app/api/workspaces/[workspaceId]/consents/route.ts` — list/create consent grants
- `app/api/workspaces/[workspaceId]/consents/[consentId]/route.ts` — revoke a consent grant
- `app/api/workspaces/[workspaceId]/care-tasks/route.ts` — list/create care reminder tasks
- `app/api/workspaces/[workspaceId]/care-tasks/[taskId]/route.ts` — update care reminder task status
- `app/api/workspaces/[workspaceId]/duplicate-test-check/route.ts` — run/list duplicate test checks
- `app/api/workspaces/[workspaceId]/family-profiles/route.ts` — list/create family profiles
- `app/api/workspaces/[workspaceId]/family-profiles/[profileId]/access/route.ts` — grant/revoke delegated family access
- `app/globals.css` — visual system
