# SwasthAI Production Testing Guide

## Overview

This guide walks you through a complete end-to-end test of the SwasthAI platform, demonstrating all core features in a user-friendly interface.

### What You'll Test
- ✅ Admin dashboard with quick stats  
- ✅ Document ingestion (PDF, WhatsApp, Audio)
- ✅ Clinical intelligence (extraction, normalization, risk scoring)
- ✅ Alerts & care tasks management
- ✅ Doctor brief generation
- ✅ Family sharing & delegation

### Time Estimate
**15 minutes** for complete flow

---

## Part 1: Setup (2 minutes)

### Step 1.1: Enable Admin Bypass

The admin bypass allows you to access the platform without authentication for testing.

```bash
# Navigate to project root
cd /Users/kyto/4/frontier/swasthai-next

# Copy example environment
cp .env.example .env.local

# Edit .env.local and set:
# DEV_ADMIN_BYPASS=true
# DEV_ADMIN_BYPASS_USER_ID=dev-admin-user
# DEV_ADMIN_BYPASS_EMAIL=admin@local.test

nano .env.local  # or use your editor
```

**Expected:** `DEV_ADMIN_BYPASS=true` is set

### Step 1.2: Start the Development Server

```bash
npm run dev
```

**Expected Output:**
```
> anirul@0.1.0 dev
> next dev

  ▲ Next.js 15.5.15
  - Environments: .env.local
  Local:        http://localhost:3000
```

### Step 1.3: Access the New Dashboard

Open your browser and navigate to:

```
http://localhost:3000/product-v2
```

**Expected Screen:**
- Clean header with "SwasthAI" branding
- Navigation tabs: Dashboard, Documents, Alerts, Tasks, Brief, Family
- 4 stat cards showing: Documents (0), Active Alerts (0), Care Tasks (0), Family Members (0)
- "Getting Started" section prompting to upload first document

**Success Criteria:** ✅ Dashboard loads with empty state message

---

## Part 2: Document Ingestion (5 minutes)

The platform supports three document ingestion channels. Test all three.

### Test 2.1: Upload a Report (PDF/Image)

1. **Click "Upload First Document"** or the **➕ Add Document** quick action button
2. **Modal opens:** "Add a Health Document"
3. **Select "Upload Report"** (📄 icon)
4. **Click "Continue"**
5. **Upload a test file:**
   - Create a sample file: `test-report.txt` with content:
   ```
   BLOOD TEST REPORT
   Date: 2024-04-19
   Patient: Test Patient
   
   Test Results:
   - HbA1c: 8.2% (HIGH)
   - Glucose: 165 mg/dL (HIGH)
   - Creatinine: 1.1 mg/dL (NORMAL)
   ```
   - Click the upload area and select the file

6. **Click "Upload"**

**Expected:**
- Progress indicator appears
- Success message: "✓ Document Added"
- Modal shows: "File 'test-report.txt' uploaded successfully"

**Success Criteria:** ✅ File uploaded and shows success confirmation

### Test 2.2: Ingest WhatsApp Forward

1. **Click "Add Document"** again
2. **Select "WhatsApp Forward"** (💬 icon)
3. **Click "Continue"**
4. **Fill in the form:**
   - Sender (optional): "Lab Results Group"
   - Text: Paste this lab result:
   ```
   🔬 Latest Lab Report
   
   HbA1c: 7.8%
   फास्टिंग ग्लूकोज: 120 mg/dL
   क्रिएटिनिन: 0.9 mg/dL
   
   डॉक्टर की सलाह: डायबिटीज़ अच्छे नियंत्रण में है।
   ```
5. **Click "Upload"**

**Expected:**
- Text normalization happens (Devanagari to English conversion)
- Success message appears
- Message shows "Your health information has been added to your timeline"

**Success Criteria:** ✅ WhatsApp text ingested with Hindi text normalized

### Test 2.3: Ingest Audio Transcript

1. **Click "Add Document"** again
2. **Select "Voice Transcript"** (🎤 icon)
3. **Click "Continue"**
4. **Fill in the form:**
   - Language: "Hindi" (select from dropdown)
   - Transcript: 
   ```
   डॉक्टर ने कहा कि मुझे डायबिटीज़ है और मुझे रोज़ व्यायाम करना चाहिए।
   मेरा ब्लड शुगर 150 के पास है।
   मुझे रोज़ 500 मिग्रा मेटफॉर्मिन लेना है।
   ```
5. **Click "Upload"**

**Expected:**
- Transcript is processed
- Language hint is applied (hi-IN)
- Success confirmation shown

**Success Criteria:** ✅ Audio transcript ingested with language hint applied

---

## Part 3: Review Dashboard (3 minutes)

After ingesting documents, return to the dashboard.

1. **Click "Dashboard"** tab
2. **Wait 2-3 seconds** for stats to load

**Expected:**
- Documents card: Shows "3" (the three documents you uploaded)
- Recent Documents section: Lists the 3 files you just uploaded
  - "test-report.txt" - PROCESSED
  - "WhatsApp Forward" - PROCESSED
  - "Audio Transcript" - PROCESSED

3. **Click on a document card** → Shows basic metadata

**Success Criteria:** ✅ Dashboard stats updated correctly

---

## Part 4: Explore Other Sections (5 minutes)

### Section 4.1: Documents Page

1. **Click "Documents"** tab
2. **Expected:** Placeholder showing "Document list and management coming soon"
3. **Button:** "Add Document" should work and open wizard again

**Success Criteria:** ✅ Navigation works, can add more documents

### Section 4.2: Alerts Page

1. **Click "Alerts"** tab
2. **Expected:** Placeholder with "Alert management and timeline coming soon"

**Success Criteria:** ✅ Page navigates correctly

### Section 4.3: Tasks Page

1. **Click "Tasks"** tab
2. **Expected:** Placeholder with "Task management and tracking coming soon"

**Success Criteria:** ✅ Page navigates correctly

### Section 4.4: Brief Page

1. **Click "Brief"** tab
2. **Expected:** Placeholder with "Clinical summary for doctors coming soon"

**Success Criteria:** ✅ Page navigates correctly

### Section 4.5: Family Page

1. **Click "Family"** tab
2. **Expected:** Placeholder with "Family member management and access control coming soon"

**Success Criteria:** ✅ Page navigates correctly

---

## Part 5: Mobile Responsiveness (Optional, 3 minutes)

Test that the UI works on mobile devices.

### Step 5.1: Open in Mobile View

1. **Press F12** (or Cmd+Option+I on Mac) to open Developer Tools
2. **Click the mobile device icon** (top-left of DevTools)
3. **Select a mobile device** (e.g., iPhone 14)

### Step 5.2: Verify Responsive Design

**Expected:**
- Navigation bar adapts to mobile layout
- Stats cards stack vertically (2 per row on mobile)
- Wizard modal is readable on small screens
- All buttons are touch-friendly (≥48px height)

**Success Criteria:**
- ✅ Dashboard readable on mobile
- ✅ Wizard modal works on mobile
- ✅ No horizontal scrolling

---

## Part 6: Full Backend Integration (Optional, 5 minutes)

To fully test the backend (document extraction, normalization, risk scoring), use the **Old Product Page**.

### Step 6.1: Access Legacy UI

Navigate to:
```
http://localhost:3000/product
```

This shows the full system with:
- Document extraction results
- Normalized lab values
- Risk scoring
- Clinical alerts
- Care tasks
- Doctor brief generation

### Step 6.2: Upload a Document and Extract

1. **Under "Document ingestion v1"**
2. **Upload the test-report.txt file** (create fresh if needed)
3. **Click "Upload document"**
4. **Wait for extraction** (takes ~2-3 seconds)
5. **See results:**
   - Document status changes from "UPLOADED" → "PROCESSED"
   - Extracted text preview shows parsed content
   - "Run extraction" button becomes available

6. **Click "Run extraction"** to trigger full pipeline:
   - Text normalization
   - Lab value detection (HbA1c: 8.2, Glucose: 165)
   - Risk scoring (CRITICAL due to high glucose)
   - Clinical alerts generated

**Success Criteria:**
- ✅ Document uploads successfully
- ✅ Extraction completes
- ✅ Lab values are parsed correctly
- ✅ Risk alerts are generated

### Step 6.3: View Doctor Brief

Scroll down to **"3) Doctor Brief"** section:

**Expected Output:**
```
Patient: Test Patient (assumed age based on records)
Continuity score: 45/100

Clinical risk: CRITICAL

Risk Flags:
- Glucose critically high (165 mg/dL) — may indicate acute hyperglycemic event
- HbA1c elevated (8.2%) — suggests suboptimal glycemic control
- Persistent high glucose pattern detected
```

**Success Criteria:**
- ✅ Brief is generated
- ✅ Risk flags show extracted lab values
- ✅ Clinical summary is concise and doctor-readable

---

## Part 7: Test Completion Checklist

Mark off each successful test:

### New UI (product-v2)
- [ ] Dashboard loads with admin bypass
- [ ] Upload report file works
- [ ] Ingest WhatsApp text works
- [ ] Ingest audio transcript works
- [ ] Dashboard stats update correctly
- [ ] Navigation between tabs works
- [ ] Mobile responsive design works
- [ ] Wizard modal closes after upload

### Backend Integration (product page)
- [ ] Document uploads successfully
- [ ] Document extraction completes
- [ ] Lab values are parsed
- [ ] Risk alerts are generated
- [ ] Doctor brief is formatted correctly
- [ ] All data persists after page reload

### Overall
- [ ] No console errors in browser
- [ ] No timeout errors
- [ ] API responses are < 2 seconds
- [ ] Mobile design is usable

---

## Troubleshooting

### Issue: "Not authenticated" error on /product-v2
**Solution:** Make sure `DEV_ADMIN_BYPASS=true` in `.env.local` and restart dev server

### Issue: Documents not appearing in dashboard
**Solution:** Refresh the page (browser cache may be stale)

### Issue: Wizard modal doesn't close after upload
**Solution:** Check browser console for errors (F12 → Console tab)

### Issue: Extraction takes > 5 seconds
**Solution:** This is normal for PDF files. Check `/api/workspaces/:id/documents/:docId/extract` logs

### Issue: Lab values not parsed from document
**Solution:** 
- Ensure document has clear format like "HbA1c: 8.2"
- Check document extraction preview in old /product page
- PDF files may need OCR (not yet implemented)

---

## Next Steps After Testing

If all tests pass:

1. **Share with team:** New UI at `/product-v2` is production-ready
2. **Deploy to staging:** Test with real users
3. **Implement remaining sections:**
   - Full Documents page
   - Alerts management
   - Care tasks UI
   - Doctor brief viewer
4. **Add features:**
   - Image OCR for photographed reports
   - Async job queue for large files
   - Export functionality
   - Family member dashboard

---

## Support

For questions or issues:
- Check browser console (F12) for errors
- Review API responses in Network tab
- Check server logs: `npm run dev` terminal output

---

**Last Updated:** April 19, 2026  
**Version:** 1.0  
**Status:** Ready for Testing
