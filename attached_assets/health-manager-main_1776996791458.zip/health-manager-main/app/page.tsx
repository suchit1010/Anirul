import { ContactForm } from "@/components/contact-form";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";

const stats = [
  { value: "1", label: "living timeline per patient" },
  { value: "2 min", label: "to generate a doctor brief" },
  { value: "0", label: "raw PHI stored on-chain" }
];

const pillars = [
  {
    title: "Health Memory",
    body: "Every report, prescription, and doctor conversation becomes one living timeline with medically structured context."
  },
  {
    title: "Doctor Briefing",
    body: "Before each consultation, Anirul generates a concise, specialty-aware pre-visit brief so doctors start with full context."
  },
  {
    title: "Risk & Continuity",
    body: "Anirul detects trend drift, missing follow-ups, and likely duplicate tests to prevent avoidable health and cost escalation."
  }
];

const workflow = [
  {
    step: "01",
    title: "Capture",
    body: "Patients or caregivers upload reports, prescriptions, voice notes, and discharge summaries from any device."
  },
  {
    step: "02",
    title: "Structure",
    body: "OCR + AI normalizes every record into a longitudinal health timeline with medications, labs, and diagnoses."
  },
  {
    step: "03",
    title: "Brief",
    body: "Before the consult, Anirul outputs a specialty-aware one-page brief that doctors can scan in seconds."
  },
  {
    step: "04",
    title: "Act",
    body: "Anirul flags drift, duplicate tests, and missed follow-up windows, then routes the patient to the next best action."
  }
];

const benefits = [
  "Reduce repeat diagnostics across fragmented providers",
  "Save doctor time during history reconstruction",
  "Give families a shared health memory",
  "Create trust with consented, auditable sharing"
];

const proof = [
  { value: "0", label: "PHI written to public chain data" },
  { value: "100%", label: "of key artifacts stay source-linked and auditable" },
  { value: "24/7", label: "shared memory available to families and care teams" }
];

const signals = [
  {
    title: "Clinics",
    body: "Want faster intake, fewer repeated questions, and a more consistent first five minutes of every consult."
  },
  {
    title: "Doctors",
    body: "Need concise, specialty-aware context that is trustworthy, source-linked, and easy to override."
  },
  {
    title: "Families",
    body: "Need one shared memory for reports, meds, follow-ups, and the next step when life gets busy."
  }
];

const faqs = [
  {
    question: "Is PHI stored on Solana?",
    answer: "No. All sensitive health data stays encrypted off-chain. Solana stores consent receipts and integrity proofs only."
  },
  {
    question: "Who is the first user?",
    answer: "The first wedge is chronic care clinics and families managing repeat consults for diabetes and hypertension."
  },
  {
    question: "Does Anirul diagnose patients?",
    answer: "No. It assists with organization, summarization, trend detection, and doctor preparation. The clinician stays in control."
  },
  {
    question: "What makes this different from EMRs?",
    answer: "EMRs optimize the clinic. Anirul optimizes the patient journey across every provider, lab, and caregiver."
  }
];

const trustPoints = [
  "PHI stored off-chain with encryption at rest and in transit",
  "Patient-consent receipts and integrity proofs anchored on Solana",
  "Explainable AI outputs with source links and clinician override",
  "India-first multilingual UX for real family caregiving workflows"
];

export default function HomePage() {
  return (
    <main>
      <section className="hero">
        <div className="noise" />
        <SiteHeader />

        <div className="hero-content hero-grid">
          <div className="hero-copy">
            <p className="kicker">Healthcare Continuity Intelligence</p>
            <h1>The health memory layer built for India’s real care journeys.</h1>
            <p className="lede">
              Anirul turns fragmented medical records into a living care memory, doctor-ready briefs,
              and proactive continuity signals—so every consultation starts with truth, not guesswork.
            </p>
            <div className="hero-actions">
              <a className="btn primary" href="#contact">
                Start a pilot
              </a>
              <a className="btn ghost" href="/product">
                Try live product
              </a>
              <a className="btn ghost" href="/platform">
                Explore platform
              </a>
            </div>
            <div className="hero-stats" aria-label="Anirul performance highlights">
              {stats.map((stat) => (
                <div key={stat.label} className="stat-pill">
                  <strong>{stat.value}</strong>
                  <span>{stat.label}</span>
                </div>
              ))}
            </div>
          </div>

          <aside className="hero-panel">
            <p className="panel-kicker">Live care brief</p>
            <div className="panel-card">
              <span className="panel-label">Patient</span>
              <strong>Aarav, 54</strong>
              <p>Diabetes, hypertension, recent HbA1c drift, missing follow-up, one duplicate lab window.</p>
            </div>
            <div className="panel-card muted">
              <span className="panel-label">Anirul insight</span>
              <p>
                Doctor brief generated. Suggested action: confirm medication adherence, compare latest labs,
                and avoid repeating CBC within 6 weeks.
              </p>
            </div>
            <div className="panel-note">
              Built for clinics that want stronger continuity without adding operational drag.
            </div>
          </aside>
        </div>
      </section>

      <section id="solution" className="section dark">
        <div className="section-head">
          <p className="label">What Anirul Does</p>
          <h2>From scattered files to one clinical intelligence surface</h2>
        </div>
        <div className="grid three">
          {pillars.map((pillar) => (
            <article key={pillar.title} className="card">
              <h3>{pillar.title}</h3>
              <p>{pillar.body}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section">
        <div className="section-head">
          <p className="label">How It Works</p>
          <h2>A premium workflow that feels magical to users and obvious to doctors.</h2>
        </div>
        <div className="workflow-grid">
          {workflow.map((item) => (
            <article key={item.step} className="workflow-card">
              <span>{item.step}</span>
              <h3>{item.title}</h3>
              <p>{item.body}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section">
        <div className="section-head">
          <p className="label">Why It Matters</p>
          <h2>India doesn’t need more files. It needs continuity.</h2>
          <p>
            Most costs in chronic care are caused by repeated diagnostics, missing context, and delayed intervention.
            Anirul is designed to collapse these losses while upgrading doctor productivity and patient trust.
          </p>
        </div>
        <div className="benefit-grid">
          {benefits.map((benefit) => (
            <div key={benefit} className="benefit-item">
              {benefit}
            </div>
          ))}
        </div>
      </section>

      <section className="section dark">
        <div className="section-head">
          <p className="label">Proof</p>
          <h2>Why this category can become massive.</h2>
        </div>
        <div className="proof-grid">
          {proof.map((item) => (
            <article key={item.label} className="proof-card">
              <strong>{item.value}</strong>
              <p>{item.label}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section dark">
        <div className="section-head">
          <p className="label">Trust Architecture</p>
          <h2>AI + Solana, used where each is strongest</h2>
        </div>
        <ul className="trust-list">
          {trustPoints.map((point) => (
            <li key={point}>{point}</li>
          ))}
        </ul>
      </section>

      <section className="section">
        <div className="section-head">
          <p className="label">Design Partner Signal</p>
          <h2>Designed around the people who actually live with the system every day.</h2>
        </div>
        <div className="testimonial-grid">
          {signals.map((item) => (
            <article key={item.title} className="testimonial-card">
              <p className="testimonial-title">{item.title}</p>
              <p>{item.body}</p>
            </article>
          ))}
        </div>
      </section>

      <section id="contact" className="section">
        <div className="section-head">
          <p className="label">Pilot Access</p>
          <h2>Bring Anirul to your clinic, hospital, or network</h2>
          <p>
            We are onboarding founding design partners for continuity-first healthcare workflows.
          </p>
        </div>
        <ContactForm />
      </section>

      <section className="section cta-band">
        <div>
          <p className="label">Next Step</p>
          <h2>See the whole care journey before the next visit begins.</h2>
        </div>
        <a className="btn primary" href="/pilots">
          Apply for a pilot
        </a>
      </section>

      <section className="section">
        <div className="section-head">
          <p className="label">FAQ</p>
          <h2>Clear answers for buyers, operators, and partners.</h2>
        </div>
        <div className="faq-grid">
          {faqs.map((item) => (
            <details key={item.question} className="faq-item">
              <summary>{item.question}</summary>
              <p>{item.answer}</p>
            </details>
          ))}
        </div>
      </section>

      <SiteFooter />
    </main>
  );
}
