import { NextResponse } from "next/server";
import { contactSchema, sendContactEmail } from "@/lib/contact";

export async function POST(request: Request) {
  try {
    const input = await request.json();
    const parsed = contactSchema.safeParse(input);

    if (!parsed.success) {
      return NextResponse.json(
        {
          ok: false,
          error: "Invalid request body",
          details: parsed.error.flatten()
        },
        { status: 400 }
      );
    }

    await sendContactEmail(parsed.data);

    return NextResponse.json(
      {
        ok: true,
        message: "Request sent successfully. The Anirul team will contact you shortly."
      },
      { status: 200 }
    );
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        error:
          error instanceof Error
            ? error.message
            : "Unable to process request"
      },
      { status: 500 }
    );
  }
}
