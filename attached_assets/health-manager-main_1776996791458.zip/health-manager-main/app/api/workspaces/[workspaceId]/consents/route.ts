import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requireUserSession } from "@/lib/auth-server";
import { prisma } from "@/lib/prisma";
import { createConsentGrant, listWorkspaceConsents, type ConsentScope, type ConsentStatusValue } from "@/lib/consent-store";

const querySchema = z.object({
  status: z.enum(["ACTIVE", "REVOKED", "EXPIRED", "all"]).optional()
});

const payloadSchema = z.object({
  subjectName: z.string().min(2).max(120),
  subjectContact: z.string().min(3).max(160),
  purpose: z.string().min(6).max(300),
  scopes: z.array(z.enum(["DOCTOR_BRIEF", "FULL_TIMELINE", "LAB_TRENDS", "ALERTS", "DOCUMENTS"])).min(1),
  expiresAt: z.string().datetime()
});

type RouteContext = {
  params: Promise<{
    workspaceId: string;
  }>;
};

export async function GET(request: NextRequest, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  const { workspaceId } = await context.params;
  const member = await prisma.workspaceMember.findUnique({
    where: {
      workspaceId_userId: {
        workspaceId,
        userId: session.user.id
      }
    }
  });

  if (!member) {
    return NextResponse.json({ ok: false, error: "Not a workspace member" }, { status: 403 });
  }

  const parsed = querySchema.safeParse(Object.fromEntries(new URL(request.url).searchParams.entries()));
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: "Invalid query parameters" }, { status: 400 });
  }

  const status = (parsed.data.status ?? "all") as ConsentStatusValue | "all";
  const result = await listWorkspaceConsents(workspaceId, status);

  return NextResponse.json({ ok: true, ...result, status });
}

export async function POST(request: Request, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  const { workspaceId } = await context.params;
  const member = await prisma.workspaceMember.findUnique({
    where: {
      workspaceId_userId: {
        workspaceId,
        userId: session.user.id
      }
    }
  });

  if (!member) {
    return NextResponse.json({ ok: false, error: "Not a workspace member" }, { status: 403 });
  }

  if (member.role === "VIEWER") {
    return NextResponse.json(
      { ok: false, error: "Only owner/editor can manage consent" },
      { status: 403 }
    );
  }

  try {
    const payload = payloadSchema.parse(await request.json());
    const expiresAt = new Date(payload.expiresAt);

    if (Number.isNaN(expiresAt.getTime()) || expiresAt.getTime() <= Date.now()) {
      return NextResponse.json(
        { ok: false, error: "expiresAt must be a valid future datetime" },
        { status: 400 }
      );
    }

    const consent = await createConsentGrant({
      workspaceId,
      grantedById: session.user.id,
      subjectName: payload.subjectName,
      subjectContact: payload.subjectContact,
      purpose: payload.purpose,
      scopes: payload.scopes as ConsentScope[],
      expiresAt
    });

    return NextResponse.json({ ok: true, consent });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        error: error instanceof Error ? error.message : "Unable to create consent"
      },
      { status: 400 }
    );
  }
}
