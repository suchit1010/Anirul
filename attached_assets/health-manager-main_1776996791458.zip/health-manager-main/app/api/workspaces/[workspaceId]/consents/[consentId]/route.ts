import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUserSession } from "@/lib/auth-server";
import { prisma } from "@/lib/prisma";
import { revokeConsentGrant } from "@/lib/consent-store";

const payloadSchema = z.object({
  action: z.enum(["revoke"]),
  reason: z.string().min(3).max(240).optional()
});

type RouteContext = {
  params: Promise<{
    workspaceId: string;
    consentId: string;
  }>;
};

export async function PATCH(request: Request, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  const { workspaceId, consentId } = await context.params;
  const member = await prisma.workspaceMember.findUnique({
    where: {
      workspaceId_userId: {
        workspaceId,
        userId: session.user.id
      }
    }
  });

  if (!member) {
    return NextResponse.json({ ok: false, error: "Not a workspace member" }, { status: 403 });
  }

  if (member.role === "VIEWER") {
    return NextResponse.json(
      { ok: false, error: "Only owner/editor can manage consent" },
      { status: 403 }
    );
  }

  try {
    const payload = payloadSchema.parse(await request.json());

    if (payload.action !== "revoke") {
      return NextResponse.json({ ok: false, error: "Unsupported action" }, { status: 400 });
    }

    const consent = await revokeConsentGrant({
      workspaceId,
      consentId,
      actorUserId: session.user.id,
      reason: payload.reason
    });

    if (!consent) {
      return NextResponse.json({ ok: false, error: "Consent not found" }, { status: 404 });
    }

    return NextResponse.json({ ok: true, consent });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        error: error instanceof Error ? error.message : "Unable to update consent"
      },
      { status: 400 }
    );
  }
}
