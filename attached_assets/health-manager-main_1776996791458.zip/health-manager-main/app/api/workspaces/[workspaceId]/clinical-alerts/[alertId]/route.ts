import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUserSession } from "@/lib/auth-server";
import { prisma } from "@/lib/prisma";
import { acknowledgeAlert, resolveAlert } from "@/lib/risk-store";

const payloadSchema = z.object({
  action: z.enum(["acknowledge", "resolve"])
});

type RouteContext = {
  params: Promise<{
    workspaceId: string;
    alertId: string;
  }>;
};

export async function PATCH(request: Request, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  const { workspaceId, alertId } = await context.params;
  const member = await prisma.workspaceMember.findUnique({
    where: {
      workspaceId_userId: {
        workspaceId,
        userId: session.user.id
      }
    }
  });

  if (!member) {
    return NextResponse.json({ ok: false, error: "Not a workspace member" }, { status: 403 });
  }

  if (member.role === "VIEWER") {
    return NextResponse.json(
      { ok: false, error: "Only owner/editor can resolve alerts" },
      { status: 403 }
    );
  }

  const alert = await prisma.clinicalAlertRecord.findUnique({ where: { id: alertId } });
  if (!alert || alert.workspaceId !== workspaceId) {
    return NextResponse.json({ ok: false, error: "Alert not found" }, { status: 404 });
  }

  try {
    const payload = payloadSchema.parse(await request.json());

    if (payload.action === "acknowledge") {
      if (alert.resolvedAt) {
        return NextResponse.json(
          { ok: false, error: "Cannot acknowledge a resolved alert" },
          { status: 400 }
        );
      }

      const acknowledged = await acknowledgeAlert(alertId, session.user.id);
      return NextResponse.json({ ok: true, alert: acknowledged });
    }

    if (alert.resolvedAt) {
      return NextResponse.json({ ok: true, alert });
    }

    const resolved = await resolveAlert(alertId, session.user.id);
    return NextResponse.json({ ok: true, alert: resolved });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        error: error instanceof Error ? error.message : "Unable to resolve alert"
      },
      { status: 400 }
    );
  }
}