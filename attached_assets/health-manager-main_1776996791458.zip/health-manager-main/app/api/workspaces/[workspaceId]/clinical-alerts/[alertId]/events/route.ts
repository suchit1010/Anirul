import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requireUserSession } from "@/lib/auth-server";
import { prisma } from "@/lib/prisma";
import { listAlertEvents } from "@/lib/risk-store";

const querySchema = z.object({
  action: z.enum(["CREATED", "ACKNOWLEDGED", "RESOLVED", "all"]).optional(),
  from: z.string().datetime().optional(),
  to: z.string().datetime().optional(),
  page: z.coerce.number().int().min(1).optional(),
  pageSize: z.coerce.number().int().min(1).max(100).optional()
});

type RouteContext = {
  params: Promise<{
    workspaceId: string;
    alertId: string;
  }>;
};

export async function GET(request: NextRequest, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  const { workspaceId, alertId } = await context.params;
  const member = await prisma.workspaceMember.findUnique({
    where: {
      workspaceId_userId: {
        workspaceId,
        userId: session.user.id
      }
    }
  });

  if (!member) {
    return NextResponse.json({ ok: false, error: "Not a workspace member" }, { status: 403 });
  }

  const alert = await prisma.clinicalAlertRecord.findUnique({ where: { id: alertId } });
  if (!alert || alert.workspaceId !== workspaceId) {
    return NextResponse.json({ ok: false, error: "Alert not found" }, { status: 404 });
  }

  const parsed = querySchema.safeParse(
    Object.fromEntries(new URL(request.url).searchParams.entries())
  );

  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: "Invalid query parameters" }, { status: 400 });
  }

  const result = await listAlertEvents(workspaceId, alertId, {
    action: parsed.data.action && parsed.data.action !== "all" ? parsed.data.action : undefined,
    from: parsed.data.from ? new Date(parsed.data.from) : undefined,
    to: parsed.data.to ? new Date(parsed.data.to) : undefined,
    page: parsed.data.page,
    pageSize: parsed.data.pageSize
  });
  return NextResponse.json({ ok: true, events: result.events, pagination: result.pagination });
}