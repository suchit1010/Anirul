import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requireUserSession } from "@/lib/auth-server";
import { prisma } from "@/lib/prisma";
import { getActiveAlerts } from "@/lib/risk-store";

const querySchema = z.object({
  patientId: z.string().min(1).optional(),
  severity: z.enum(["LOW", "MODERATE", "HIGH", "CRITICAL"]).optional(),
  status: z.enum(["active", "acknowledged", "resolved", "all"]).optional(),
  includeResolved: z.enum(["true", "false"]).optional()
});

type RouteContext = {
  params: Promise<{
    workspaceId: string;
  }>;
};

export async function GET(request: NextRequest, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  const { workspaceId } = await context.params;
  const member = await prisma.workspaceMember.findUnique({
    where: {
      workspaceId_userId: {
        workspaceId,
        userId: session.user.id
      }
    }
  });

  if (!member) {
    return NextResponse.json({ ok: false, error: "Not a workspace member" }, { status: 403 });
  }

  const parsed = querySchema.safeParse(
    Object.fromEntries(new URL(request.url).searchParams.entries())
  );

  if (!parsed.success) {
    return NextResponse.json(
      { ok: false, error: "Invalid query parameters" },
      { status: 400 }
    );
  }

  const { patientId, severity, status, includeResolved } = parsed.data;

  if (!status && includeResolved !== "true") {
    const alerts = await getActiveAlerts(workspaceId, patientId, severity);
    return NextResponse.json({ ok: true, alerts });
  }

  const effectiveStatus = status ?? (includeResolved === "true" ? "all" : "active");
  const where: {
    workspaceId: string;
    patientId?: string;
    severity?: "LOW" | "MODERATE" | "HIGH" | "CRITICAL";
    acknowledgedAt?: null | { not: null };
    resolvedAt?: null | { not: null };
  } = {
    workspaceId,
    patientId: patientId || undefined,
    severity: severity || undefined
  };

  if (effectiveStatus === "active") {
    where.acknowledgedAt = null;
    where.resolvedAt = null;
  } else if (effectiveStatus === "acknowledged") {
    where.acknowledgedAt = { not: null };
    where.resolvedAt = null;
  } else if (effectiveStatus === "resolved") {
    where.resolvedAt = { not: null };
  }

  const alerts = await prisma.clinicalAlertRecord.findMany({
    where,
    orderBy: { createdAt: "desc" }
  });

  return NextResponse.json({ ok: true, alerts, status: effectiveStatus });
}