import { NextResponse } from "next/server";
import { z } from "zod";
import { type ProductState } from "@/lib/product-engine";
import { loadWorkspace, saveWorkspace } from "@/lib/workspace-store";
import { requireUserSession } from "@/lib/auth-server";

const saveWorkspaceSchema = z.object({
  state: z.custom<ProductState>()
});

type RouteContext = {
  params: Promise<{
    workspaceId: string;
  }>;
};

export async function GET(_: Request, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  const { workspaceId } = await context.params;
  const document = await loadWorkspace(workspaceId, session.user.id);

  if (!document) {
    return NextResponse.json(
      { ok: false, error: "Workspace not found" },
      { status: 404 }
    );
  }

  return NextResponse.json({
    ok: true,
    workspaceId: document.id,
    createdAt: document.createdAt,
    updatedAt: document.updatedAt,
    state: document.state
  });
}

export async function PUT(request: Request, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { workspaceId } = await context.params;
    const payload = saveWorkspaceSchema.parse(await request.json());
    const document = await saveWorkspace(workspaceId, session.user.id, payload.state);

    if (!document) {
      return NextResponse.json(
        { ok: false, error: "Workspace not found" },
        { status: 404 }
      );
    }

    return NextResponse.json({
      ok: true,
      workspaceId: document.id,
      updatedAt: document.updatedAt,
      state: document.state
    });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        error: error instanceof Error ? error.message : "Unable to save workspace"
      },
      { status: 400 }
    );
  }
}