import { NextRequest, NextResponse } from 'next/server';
import { createServerSupabase } from '@/lib/supabase-server';
import { prisma } from '@/lib/prisma';
import { getLabTestReferenceRanges } from '@/lib/normalization-store';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ workspaceId: string }> }
) {
  try {
    // Get session from Supabase
    const supabase = createServerSupabase();
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { workspaceId } = await params;

    // Check workspace membership
    const member = await prisma.workspaceMember.findUnique({
      where: {
        workspaceId_userId: {
          workspaceId,
          userId: user.id,
        },
      },
    });

    if (!member) {
      return NextResponse.json({ error: 'Not a workspace member' }, { status: 403 });
    }

    // Get query parameters
    const { searchParams } = new URL(req.url);
    const labName = searchParams.get('labName');
    const unit = searchParams.get('unit');

    if (!labName) {
      return NextResponse.json(
        { error: 'labName parameter required' },
        { status: 400 }
      );
    }

    const ranges = await getLabTestReferenceRanges(labName, unit || undefined);

    return NextResponse.json({
      labName,
      unit: unit || null,
      ranges,
    });
  } catch (error) {
    console.error('Error fetching reference ranges:', error);
    return NextResponse.json(
      { error: 'Failed to fetch reference ranges' },
      { status: 500 }
    );
  }
}
