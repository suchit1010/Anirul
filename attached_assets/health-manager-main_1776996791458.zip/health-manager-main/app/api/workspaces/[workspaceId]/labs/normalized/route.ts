import { NextRequest, NextResponse } from 'next/server';
import { createServerSupabase } from '@/lib/supabase-server';
import { prisma } from '@/lib/prisma';
import {
  getNormalizedLabValues,
  getAbnormalLabValues,
  getCriticalLabValues,
  getLabSummary,
  getLabValueTrend,
} from '@/lib/normalization-store';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ workspaceId: string }> }
) {
  try {
    // Get session from Supabase
    const supabase = createServerSupabase();
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { workspaceId } = await params;

    // Check workspace membership
    const member = await prisma.workspaceMember.findUnique({
      where: {
        workspaceId_userId: {
          workspaceId,
          userId: user.id,
        },
      },
    });

    if (!member) {
      return NextResponse.json({ error: 'Not a workspace member' }, { status: 403 });
    }

    // Get query parameters
    const { searchParams } = new URL(req.url);
    const type = searchParams.get('type') || 'all'; // all, abnormal, critical, summary, trend
    const patientId = searchParams.get('patientId');
    const labName = searchParams.get('labName');
    const days = parseInt(searchParams.get('days') || '90', 10);

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    let response: any = {};

    switch (type) {
      case 'abnormal':
        response = await getAbnormalLabValues(workspaceId, patientId || undefined, days);
        break;

      case 'critical':
        response = await getCriticalLabValues(workspaceId, patientId || undefined);
        break;

      case 'summary':
        response = await getLabSummary(workspaceId, patientId || undefined, days);
        break;

      case 'trend':
        if (!labName) {
          return NextResponse.json(
            { error: 'labName required for trend query' },
            { status: 400 }
          );
        }
        if (!patientId) {
          return NextResponse.json(
            { error: 'patientId required for trend query' },
            { status: 400 }
          );
        }
        response = await getLabValueTrend(workspaceId, patientId, labName, days);
        break;

      case 'all':
      default:
        response = await getNormalizedLabValues(
          workspaceId,
          patientId || undefined,
          labName || undefined,
          days
        );
        break;
    }

    return NextResponse.json(response);
  } catch (error) {
    console.error('Error fetching normalized labs:', error);
    return NextResponse.json(
      { error: 'Failed to fetch lab data' },
      { status: 500 }
    );
  }
}
