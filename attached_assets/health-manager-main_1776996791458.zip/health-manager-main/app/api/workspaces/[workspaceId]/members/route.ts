import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUserSession } from "@/lib/auth-server";
import {
  addWorkspaceMember,
  listWorkspaceMembers,
  type WorkspaceMemberRole
} from "@/lib/workspace-store";

const addMemberSchema = z.object({
  userId: z.string().min(6).max(128),
  role: z.enum(["EDITOR", "VIEWER"]).default("VIEWER")
});

type RouteContext = {
  params: Promise<{
    workspaceId: string;
  }>;
};

export async function GET(_: Request, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  const { workspaceId } = await context.params;
  const members = await listWorkspaceMembers(workspaceId, session.user.id);

  if (!members) {
    return NextResponse.json({ ok: false, error: "Workspace not found" }, { status: 404 });
  }

  return NextResponse.json({ ok: true, members });
}

export async function POST(request: Request, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { workspaceId } = await context.params;
    const payload = addMemberSchema.parse(await request.json());

    const member = await addWorkspaceMember(
      workspaceId,
      session.user.id,
      payload.userId,
      payload.role as WorkspaceMemberRole
    );

    if (!member) {
      return NextResponse.json({ ok: false, error: "Workspace not found" }, { status: 404 });
    }

    if (member === "forbidden") {
      return NextResponse.json({ ok: false, error: "Only owners can add members" }, { status: 403 });
    }

    return NextResponse.json({ ok: true, member });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        error: error instanceof Error ? error.message : "Unable to add member"
      },
      { status: 400 }
    );
  }
}
