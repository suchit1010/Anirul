import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUserSession } from "@/lib/auth-server";
import {
  removeWorkspaceMember,
  updateWorkspaceMemberRole,
  type WorkspaceMemberRole
} from "@/lib/workspace-store";

const updateMemberSchema = z.object({
  role: z.enum(["EDITOR", "VIEWER"])
});

type RouteContext = {
  params: Promise<{
    workspaceId: string;
    memberUserId: string;
  }>;
};

export async function PATCH(request: Request, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { workspaceId, memberUserId } = await context.params;
    const payload = updateMemberSchema.parse(await request.json());

    const member = await updateWorkspaceMemberRole(
      workspaceId,
      session.user.id,
      memberUserId,
      payload.role as WorkspaceMemberRole
    );

    if (!member) {
      return NextResponse.json({ ok: false, error: "Member not found" }, { status: 404 });
    }

    if (member === "forbidden") {
      return NextResponse.json({ ok: false, error: "Only owners can update members" }, { status: 403 });
    }

    if (member === "owner-protected") {
      return NextResponse.json({ ok: false, error: "Owner role cannot be changed" }, { status: 400 });
    }

    return NextResponse.json({ ok: true, member });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        error: error instanceof Error ? error.message : "Unable to update member"
      },
      { status: 400 }
    );
  }
}

export async function DELETE(_: Request, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  const { workspaceId, memberUserId } = await context.params;
  const removed = await removeWorkspaceMember(workspaceId, session.user.id, memberUserId);

  if (!removed) {
    return NextResponse.json({ ok: false, error: "Member not found" }, { status: 404 });
  }

  if (removed === "forbidden") {
    return NextResponse.json({ ok: false, error: "Only owners can remove members" }, { status: 403 });
  }

  if (removed === "owner-protected") {
    return NextResponse.json({ ok: false, error: "Owner cannot be removed" }, { status: 400 });
  }

  return NextResponse.json({ ok: true, ...removed });
}
