import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUserSession } from "@/lib/auth-server";
import { prisma } from "@/lib/prisma";
import { updateCareTaskStatus } from "@/lib/care-plan-store";

const payloadSchema = z.object({
  action: z.enum(["complete", "skip", "reopen"]),
  note: z.string().min(2).max(240).optional()
});

type RouteContext = {
  params: Promise<{
    workspaceId: string;
    taskId: string;
  }>;
};

export async function PATCH(request: Request, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  const { workspaceId, taskId } = await context.params;
  const member = await prisma.workspaceMember.findUnique({
    where: {
      workspaceId_userId: {
        workspaceId,
        userId: session.user.id
      }
    }
  });

  if (!member) {
    return NextResponse.json({ ok: false, error: "Not a workspace member" }, { status: 403 });
  }

  if (member.role === "VIEWER") {
    return NextResponse.json(
      { ok: false, error: "Only owner/editor can manage care tasks" },
      { status: 403 }
    );
  }

  try {
    const payload = payloadSchema.parse(await request.json());

    const task = await updateCareTaskStatus({
      workspaceId,
      taskId,
      actorUserId: session.user.id,
      action: payload.action,
      note: payload.note
    });

    if (!task) {
      return NextResponse.json({ ok: false, error: "Care task not found" }, { status: 404 });
    }

    return NextResponse.json({ ok: true, task });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        error: error instanceof Error ? error.message : "Unable to update care task"
      },
      { status: 400 }
    );
  }
}
