import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requireUserSession } from "@/lib/auth-server";
import { prisma } from "@/lib/prisma";
import { createCareTask, listCareTasks, type CareTaskPriorityValue, type CareTaskSourceValue } from "@/lib/care-plan-store";

const querySchema = z.object({
  status: z.enum(["PENDING", "COMPLETED", "SKIPPED", "all"]).optional(),
  patientId: z.string().min(1).optional()
});

const payloadSchema = z.object({
  patientId: z.string().min(1).optional(),
  title: z.string().min(3).max(160),
  description: z.string().max(600).optional(),
  dueAt: z.string().datetime().optional(),
  priority: z.enum(["LOW", "MODERATE", "HIGH"]).optional(),
  source: z.enum(["MANUAL", "ALERT_FOLLOWUP", "RISK_FOLLOWUP"]).optional(),
  sourceRefId: z.string().max(120).optional()
});

type RouteContext = {
  params: Promise<{
    workspaceId: string;
  }>;
};

export async function GET(request: NextRequest, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  const { workspaceId } = await context.params;
  const member = await prisma.workspaceMember.findUnique({
    where: {
      workspaceId_userId: {
        workspaceId,
        userId: session.user.id
      }
    }
  });

  if (!member) {
    return NextResponse.json({ ok: false, error: "Not a workspace member" }, { status: 403 });
  }

  const parsed = querySchema.safeParse(Object.fromEntries(new URL(request.url).searchParams.entries()));
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: "Invalid query parameters" }, { status: 400 });
  }

  const status = parsed.data.status ?? "all";
  const result = await listCareTasks(workspaceId, {
    status,
    patientId: parsed.data.patientId
  });

  return NextResponse.json({ ok: true, ...result, status });
}

export async function POST(request: Request, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  const { workspaceId } = await context.params;
  const member = await prisma.workspaceMember.findUnique({
    where: {
      workspaceId_userId: {
        workspaceId,
        userId: session.user.id
      }
    }
  });

  if (!member) {
    return NextResponse.json({ ok: false, error: "Not a workspace member" }, { status: 403 });
  }

  if (member.role === "VIEWER") {
    return NextResponse.json(
      { ok: false, error: "Only owner/editor can manage care tasks" },
      { status: 403 }
    );
  }

  try {
    const payload = payloadSchema.parse(await request.json());

    const task = await createCareTask({
      workspaceId,
      createdById: session.user.id,
      patientId: payload.patientId,
      title: payload.title,
      description: payload.description,
      dueAt: payload.dueAt ? new Date(payload.dueAt) : undefined,
      priority: payload.priority as CareTaskPriorityValue | undefined,
      source: payload.source as CareTaskSourceValue | undefined,
      sourceRefId: payload.sourceRefId
    });

    return NextResponse.json({ ok: true, task });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        error: error instanceof Error ? error.message : "Unable to create care task"
      },
      { status: 400 }
    );
  }
}
