import { NextResponse } from "next/server";
import { requireUserSession } from "@/lib/auth-server";
import { listWorkspaceDocuments, uploadWorkspaceDocument } from "@/lib/document-store";

const MAX_UPLOAD_BYTES = 10 * 1024 * 1024;

type RouteContext = {
  params: Promise<{
    workspaceId: string;
  }>;
};

export async function GET(_: Request, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  const { workspaceId } = await context.params;
  const documents = await listWorkspaceDocuments(workspaceId, session.user.id);

  if (!documents) {
    return NextResponse.json({ ok: false, error: "Workspace not found" }, { status: 404 });
  }

  return NextResponse.json({ ok: true, documents });
}

export async function POST(request: Request, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { workspaceId } = await context.params;
    const formData = await request.formData();
    const uploaded = formData.get("file");

    if (!(uploaded instanceof File)) {
      return NextResponse.json({ ok: false, error: "File is required" }, { status: 400 });
    }

    if (uploaded.size > MAX_UPLOAD_BYTES) {
      return NextResponse.json(
        { ok: false, error: "File exceeds 10MB upload limit" },
        { status: 400 }
      );
    }

    const fileBytes = Buffer.from(await uploaded.arrayBuffer());
    const document = await uploadWorkspaceDocument({
      workspaceId,
      userId: session.user.id,
      fileName: uploaded.name,
      mimeType: uploaded.type || "application/octet-stream",
      fileBytes
    });

    if (!document) {
      return NextResponse.json({ ok: false, error: "Workspace not found" }, { status: 404 });
    }

    return NextResponse.json({ ok: true, document });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        error: error instanceof Error ? error.message : "Unable to upload document"
      },
      { status: 400 }
    );
  }
}
