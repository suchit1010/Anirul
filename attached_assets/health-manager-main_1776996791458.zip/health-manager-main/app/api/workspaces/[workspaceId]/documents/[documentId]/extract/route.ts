import { NextResponse } from "next/server";
import { requireUserSession } from "@/lib/auth-server";
import { runDocumentExtraction } from "@/lib/document-store";

type RouteContext = {
  params: Promise<{
    workspaceId: string;
    documentId: string;
  }>;
};

export async function POST(_: Request, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  const { workspaceId, documentId } = await context.params;
  const result = await runDocumentExtraction({
    workspaceId,
    documentId,
    userId: session.user.id
  });

  if (result === "forbidden") {
    return NextResponse.json({ ok: false, error: "Workspace not found" }, { status: 404 });
  }

  if (result === "not-found") {
    return NextResponse.json({ ok: false, error: "Document not found" }, { status: 404 });
  }

  return NextResponse.json({
    ok: true,
    document: result.document,
    job: result.job
  });
}
