import { NextResponse } from "next/server";
import { requireUserSession } from "@/lib/auth-server";
import { ingestTextChannelDocument } from "@/lib/document-store";
import { normalizeChannelText } from "@/lib/channel-text-normalization";

type RouteContext = {
  params: Promise<{
    workspaceId: string;
  }>;
};

type WhatsappRequestBody = {
  forwardedText?: string;
  senderLabel?: string;
  receivedAt?: string;
};

export async function POST(request: Request, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { workspaceId } = await context.params;
    const body = (await request.json()) as WhatsappRequestBody;
    const forwardedText = body.forwardedText?.trim();

    if (!forwardedText) {
      return NextResponse.json({ ok: false, error: "forwardedText is required" }, { status: 400 });
    }

    const normalized = normalizeChannelText({
      text: forwardedText,
      channel: "whatsapp"
    });

    if (normalized.cleanedText.length < 20) {
      return NextResponse.json(
        { ok: false, error: "Forwarded text is too short for ingestion" },
        { status: 400 }
      );
    }

    const sourceContext = JSON.stringify({
      senderLabel: body.senderLabel?.trim() || null,
      receivedAt: body.receivedAt?.trim() || null,
      channel: "whatsapp",
      detectedScript: normalized.detectedScript,
      normalizationConfidence: normalized.confidence,
      normalizationNotes: normalized.notes,
      originalLength: forwardedText.length,
      normalizedLength: normalized.cleanedText.length
    });

    const document = await ingestTextChannelDocument({
      workspaceId,
      userId: session.user.id,
      fileName: `whatsapp-forward-${new Date().toISOString().replace(/[:.]/g, "-")}.txt`,
      sourceChannel: "WHATSAPP_FORWARD",
      sourceContext,
      textContent: normalized.cleanedText
    });

    if (!document) {
      return NextResponse.json({ ok: false, error: "Workspace not found" }, { status: 404 });
    }

    return NextResponse.json({ ok: true, document });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        error: error instanceof Error ? error.message : "Unable to ingest WhatsApp forward"
      },
      { status: 400 }
    );
  }
}
