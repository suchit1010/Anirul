import { NextResponse } from "next/server";
import { requireUserSession } from "@/lib/auth-server";
import { ingestTextChannelDocument } from "@/lib/document-store";
import { normalizeChannelText } from "@/lib/channel-text-normalization";

type RouteContext = {
  params: Promise<{
    workspaceId: string;
  }>;
};

type AudioTranscriptRequestBody = {
  transcript?: string;
  language?: string;
  durationSeconds?: number;
  recordedAt?: string;
};

export async function POST(request: Request, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { workspaceId } = await context.params;
    const body = (await request.json()) as AudioTranscriptRequestBody;
    const transcript = body.transcript?.trim();

    if (!transcript) {
      return NextResponse.json({ ok: false, error: "transcript is required" }, { status: 400 });
    }

    const normalized = normalizeChannelText({
      text: transcript,
      channel: "audio",
      languageHint: body.language
    });

    if (normalized.cleanedText.length < 20) {
      return NextResponse.json(
        { ok: false, error: "Transcript is too short for ingestion" },
        { status: 400 }
      );
    }

    const sourceContext = JSON.stringify({
      language: normalized.languageHint,
      durationSeconds: typeof body.durationSeconds === "number" ? body.durationSeconds : null,
      recordedAt: body.recordedAt?.trim() || null,
      channel: "audio",
      detectedScript: normalized.detectedScript,
      normalizationConfidence: normalized.confidence,
      normalizationNotes: normalized.notes,
      originalLength: transcript.length,
      normalizedLength: normalized.cleanedText.length
    });

    const document = await ingestTextChannelDocument({
      workspaceId,
      userId: session.user.id,
      fileName: `audio-transcript-${new Date().toISOString().replace(/[:.]/g, "-")}.txt`,
      sourceChannel: "AUDIO_TRANSCRIPT",
      sourceContext,
      textContent: normalized.cleanedText
    });

    if (!document) {
      return NextResponse.json({ ok: false, error: "Workspace not found" }, { status: 404 });
    }

    return NextResponse.json({ ok: true, document });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        error: error instanceof Error ? error.message : "Unable to ingest audio transcript"
      },
      { status: 400 }
    );
  }
}
