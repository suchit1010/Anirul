import { NextRequest, NextResponse } from 'next/server';
import { createServerSupabase } from '@/lib/supabase-server';
import { prisma } from '@/lib/prisma';
import { generateClinicalSummary } from '@/lib/risk-store';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ workspaceId: string }> }
) {
  try {
    const supabase = createServerSupabase();
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { workspaceId } = await params;
    const member = await prisma.workspaceMember.findUnique({
      where: {
        workspaceId_userId: {
          workspaceId,
          userId: user.id,
        },
      },
    });

    if (!member) {
      return NextResponse.json({ error: 'Not a workspace member' }, { status: 403 });
    }

    const { searchParams } = new URL(req.url);
    const patientId = searchParams.get('patientId') || workspaceId;
    const ageYears = searchParams.get('ageYears');
    const sex = searchParams.get('sex') || undefined;

    const summary = await generateClinicalSummary(
      workspaceId,
      patientId,
      ageYears ? Number(ageYears) : undefined,
      sex
    );

    return NextResponse.json({ ok: true, summary });
  } catch (error) {
    console.error('Failed to build clinical summary:', error);
    return NextResponse.json(
      { ok: false, error: 'Failed to build clinical summary' },
      { status: 500 }
    );
  }
}