import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUserSession } from "@/lib/auth-server";
import {
  createWorkspaceInvite,
  listWorkspaceInvites,
  type WorkspaceMemberRole
} from "@/lib/workspace-store";

const createInviteSchema = z.object({
  email: z.string().trim().email(),
  role: z.enum(["EDITOR", "VIEWER"]).default("VIEWER")
});

type RouteContext = {
  params: Promise<{
    workspaceId: string;
  }>;
};

export async function GET(_: Request, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  const { workspaceId } = await context.params;
  const invites = await listWorkspaceInvites(workspaceId, session.user.id);

  if (!invites) {
    return NextResponse.json({ ok: false, error: "Workspace not found" }, { status: 404 });
  }

  return NextResponse.json({ ok: true, invites });
}

export async function POST(request: Request, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { workspaceId } = await context.params;
    const payload = createInviteSchema.parse(await request.json());

    const invite = await createWorkspaceInvite(
      workspaceId,
      session.user.id,
      payload.email,
      payload.role as WorkspaceMemberRole
    );

    if (!invite) {
      return NextResponse.json({ ok: false, error: "Workspace not found" }, { status: 404 });
    }

    if (invite === "forbidden") {
      return NextResponse.json({ ok: false, error: "Only owners can invite members" }, { status: 403 });
    }

    return NextResponse.json({ ok: true, invite });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        error: error instanceof Error ? error.message : "Unable to create invite"
      },
      { status: 400 }
    );
  }
}
