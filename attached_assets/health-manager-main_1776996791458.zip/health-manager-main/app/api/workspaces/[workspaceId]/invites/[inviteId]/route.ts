import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUserSession } from "@/lib/auth-server";
import { resendWorkspaceInvite, revokeWorkspaceInvite } from "@/lib/workspace-store";

const updateInviteSchema = z.object({
  action: z.enum(["revoke", "resend"])
});

type RouteContext = {
  params: Promise<{
    workspaceId: string;
    inviteId: string;
  }>;
};

export async function PATCH(request: Request, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { workspaceId, inviteId } = await context.params;
    const payload = updateInviteSchema.parse(await request.json());

    const invite =
      payload.action === "revoke"
        ? await revokeWorkspaceInvite(workspaceId, session.user.id, inviteId)
        : await resendWorkspaceInvite(workspaceId, session.user.id, inviteId);

    if (!invite) {
      return NextResponse.json({ ok: false, error: "Invite not found" }, { status: 404 });
    }

    if (invite === "forbidden") {
      return NextResponse.json({ ok: false, error: "Only owners can manage invites" }, { status: 403 });
    }

    return NextResponse.json({ ok: true, invite });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        error: error instanceof Error ? error.message : "Unable to update invite"
      },
      { status: 400 }
    );
  }
}
