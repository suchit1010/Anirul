import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requireUserSession } from "@/lib/auth-server";
import { prisma } from "@/lib/prisma";
import { checkDuplicateTest, listDuplicateChecks } from "@/lib/duplicate-test-store";

const querySchema = z.object({
  patientId: z.string().min(1).optional(),
  limit: z.coerce.number().int().min(1).max(100).optional()
});

const payloadSchema = z.object({
  patientId: z.string().min(1).optional(),
  labName: z.string().min(2).max(120),
  lookbackDays: z.number().int().min(1).max(365).optional()
});

type RouteContext = {
  params: Promise<{
    workspaceId: string;
  }>;
};

export async function GET(request: NextRequest, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  const { workspaceId } = await context.params;
  const member = await prisma.workspaceMember.findUnique({
    where: {
      workspaceId_userId: {
        workspaceId,
        userId: session.user.id
      }
    }
  });

  if (!member) {
    return NextResponse.json({ ok: false, error: "Not a workspace member" }, { status: 403 });
  }

  const parsed = querySchema.safeParse(Object.fromEntries(new URL(request.url).searchParams.entries()));
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: "Invalid query parameters" }, { status: 400 });
  }

  const checks = await listDuplicateChecks(
    workspaceId,
    parsed.data.patientId,
    parsed.data.limit ?? 20
  );

  return NextResponse.json({ ok: true, checks });
}

export async function POST(request: Request, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  const { workspaceId } = await context.params;
  const member = await prisma.workspaceMember.findUnique({
    where: {
      workspaceId_userId: {
        workspaceId,
        userId: session.user.id
      }
    }
  });

  if (!member) {
    return NextResponse.json({ ok: false, error: "Not a workspace member" }, { status: 403 });
  }

  if (member.role === "VIEWER") {
    return NextResponse.json(
      { ok: false, error: "Only owner/editor can run duplicate checks" },
      { status: 403 }
    );
  }

  try {
    const payload = payloadSchema.parse(await request.json());

    const check = await checkDuplicateTest({
      workspaceId,
      requestedById: session.user.id,
      patientId: payload.patientId,
      labName: payload.labName,
      lookbackDays: payload.lookbackDays
    });

    return NextResponse.json({ ok: true, check });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        error: error instanceof Error ? error.message : "Unable to run duplicate test check"
      },
      { status: 400 }
    );
  }
}
