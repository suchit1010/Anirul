import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUserSession } from "@/lib/auth-server";
import { prisma } from "@/lib/prisma";
import { revokeFamilyAccess, upsertFamilyAccess } from "@/lib/family-store";

const payloadSchema = z.object({
  action: z.enum(["grant", "revoke"]),
  targetUserId: z.string().min(6).max(128),
  role: z.enum(["MANAGER", "VIEWER"]).optional()
});

type RouteContext = {
  params: Promise<{
    workspaceId: string;
    profileId: string;
  }>;
};

export async function PATCH(request: Request, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  const { workspaceId, profileId } = await context.params;
  const member = await prisma.workspaceMember.findUnique({
    where: {
      workspaceId_userId: {
        workspaceId,
        userId: session.user.id
      }
    }
  });

  if (!member) {
    return NextResponse.json({ ok: false, error: "Not a workspace member" }, { status: 403 });
  }

  if (member.role === "VIEWER") {
    return NextResponse.json(
      { ok: false, error: "Only owner/editor can manage family access" },
      { status: 403 }
    );
  }

  const familyProfile = await prisma.familyProfile.findUnique({ where: { id: profileId } });
  if (!familyProfile || familyProfile.workspaceId !== workspaceId) {
    return NextResponse.json({ ok: false, error: "Family profile not found" }, { status: 404 });
  }

  try {
    const payload = payloadSchema.parse(await request.json());

    const targetMember = await prisma.workspaceMember.findUnique({
      where: {
        workspaceId_userId: {
          workspaceId,
          userId: payload.targetUserId
        }
      }
    });

    if (!targetMember) {
      return NextResponse.json(
        { ok: false, error: "Target user must be a workspace member" },
        { status: 400 }
      );
    }

    if (payload.action === "grant") {
      const access = await upsertFamilyAccess({
        workspaceId,
        profileId,
        targetUserId: payload.targetUserId,
        role: payload.role ?? "VIEWER",
        actorUserId: session.user.id
      });

      return NextResponse.json({ ok: true, access });
    }

    const access = await revokeFamilyAccess({
      workspaceId,
      profileId,
      targetUserId: payload.targetUserId,
      actorUserId: session.user.id
    });

    if (!access) {
      return NextResponse.json({ ok: false, error: "Access not found" }, { status: 404 });
    }

    return NextResponse.json({ ok: true, access });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        error: error instanceof Error ? error.message : "Unable to update family access"
      },
      { status: 400 }
    );
  }
}
