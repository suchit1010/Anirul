import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requireUserSession } from "@/lib/auth-server";
import { prisma } from "@/lib/prisma";
import { createFamilyProfile, listFamilyProfiles } from "@/lib/family-store";

const payloadSchema = z.object({
  fullName: z.string().min(2).max(120),
  ageYears: z.number().int().min(0).max(130).optional(),
  sex: z.string().max(20).optional(),
  relation: z.enum(["SELF", "SPOUSE", "CHILD", "PARENT", "SIBLING", "OTHER"]).optional(),
  notes: z.string().max(300).optional()
});

type RouteContext = {
  params: Promise<{
    workspaceId: string;
  }>;
};

export async function GET(_: NextRequest, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  const { workspaceId } = await context.params;
  const member = await prisma.workspaceMember.findUnique({
    where: {
      workspaceId_userId: {
        workspaceId,
        userId: session.user.id
      }
    }
  });

  if (!member) {
    return NextResponse.json({ ok: false, error: "Not a workspace member" }, { status: 403 });
  }

  const result = await listFamilyProfiles(workspaceId);
  return NextResponse.json({ ok: true, ...result });
}

export async function POST(request: Request, context: RouteContext) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  const { workspaceId } = await context.params;
  const member = await prisma.workspaceMember.findUnique({
    where: {
      workspaceId_userId: {
        workspaceId,
        userId: session.user.id
      }
    }
  });

  if (!member) {
    return NextResponse.json({ ok: false, error: "Not a workspace member" }, { status: 403 });
  }

  if (member.role === "VIEWER") {
    return NextResponse.json(
      { ok: false, error: "Only owner/editor can manage family profiles" },
      { status: 403 }
    );
  }

  try {
    const payload = payloadSchema.parse(await request.json());
    const profile = await createFamilyProfile({
      workspaceId,
      createdById: session.user.id,
      fullName: payload.fullName,
      ageYears: payload.ageYears,
      sex: payload.sex,
      relation: payload.relation,
      notes: payload.notes
    });

    return NextResponse.json({ ok: true, profile });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        error: error instanceof Error ? error.message : "Unable to create family profile"
      },
      { status: 400 }
    );
  }
}
