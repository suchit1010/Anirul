import { NextResponse } from "next/server";
import { z } from "zod";
import { EMPTY_PRODUCT_STATE, type ProductState } from "@/lib/product-engine";
import { createWorkspace } from "@/lib/workspace-store";
import { requireUserSession } from "@/lib/auth-server";

const createWorkspaceSchema = z
  .object({
    state: z.custom<ProductState>().optional()
  })
  .optional();

export async function POST(request: Request) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  try {
    const payload = createWorkspaceSchema.parse(await request.json().catch(() => undefined));
    const document = await createWorkspace(session.user.id, payload?.state ?? EMPTY_PRODUCT_STATE);

    return NextResponse.json({
      ok: true,
      workspaceId: document.id,
      createdAt: document.createdAt,
      updatedAt: document.updatedAt,
      state: document.state
    });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        error: error instanceof Error ? error.message : "Unable to create workspace"
      },
      { status: 400 }
    );
  }
}