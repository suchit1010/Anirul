import { NextResponse } from "next/server";
import { leadSchema, sendLeadToCrm } from "@/lib/lead";

export async function POST(request: Request) {
  try {
    const input = await request.json();
    const parsed = leadSchema.safeParse(input);

    if (!parsed.success) {
      return NextResponse.json(
        {
          ok: false,
          error: "Invalid request body",
          details: parsed.error.flatten()
        },
        { status: 400 }
      );
    }

    await sendLeadToCrm(parsed.data);

    return NextResponse.json(
      {
        ok: true,
        message: "Pilot application submitted. We will contact you within 72 hours."
      },
      { status: 200 }
    );
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        error: error instanceof Error ? error.message : "Unable to submit lead"
      },
      { status: 500 }
    );
  }
}
