import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUserSession } from "@/lib/auth-server";
import { ensureUserProfileFromSession } from "@/lib/user-profile";
import { prisma } from "@/lib/prisma";

const updateProfileSchema = z.object({
  fullName: z.string().trim().min(1).max(120).optional(),
  role: z.enum(["PATIENT", "CAREGIVER", "CLINIC_ADMIN", "CLINIC_STAFF", "DOCTOR", "ADMIN"]).optional()
});

export async function GET() {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  const profile = await ensureUserProfileFromSession(session);

  return NextResponse.json({
    ok: true,
    profile: {
      id: profile.id,
      email: profile.email,
      fullName: profile.fullName,
      role: profile.role,
      createdAt: profile.createdAt,
      updatedAt: profile.updatedAt
    }
  });
}

export async function PUT(request: Request) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  try {
    await ensureUserProfileFromSession(session);
    const payload = updateProfileSchema.parse(await request.json());

    const updated = await prisma.userProfile.update({
      where: { id: session.user.id },
      data: {
        fullName: payload.fullName,
        role: payload.role
      }
    });

    return NextResponse.json({
      ok: true,
      profile: {
        id: updated.id,
        email: updated.email,
        fullName: updated.fullName,
        role: updated.role,
        createdAt: updated.createdAt,
        updatedAt: updated.updatedAt
      }
    });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        error: error instanceof Error ? error.message : "Unable to update profile"
      },
      { status: 400 }
    );
  }
}
