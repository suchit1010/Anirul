import { requireUserSession } from "@/lib/auth-server";

export async function GET() {
  try {
    const session = await requireUserSession();

    if (!session) {
      return Response.json(
        { error: "Not authenticated" },
        { status: 401 }
      );
    }

    return Response.json({
      authenticated: true,
      userId: session.user.id,
      email: session.user.email,
      workspace: null,
    });
  } catch (error) {
    console.error("Session check failed:", error);
    return Response.json(
      { error: "Session check failed" },
      { status: 500 }
    );
  }
}
