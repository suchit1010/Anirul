import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUserSession } from "@/lib/auth-server";
import { acceptWorkspaceInvite } from "@/lib/workspace-store";

const acceptInviteSchema = z.object({
  token: z.string().trim().min(10).max(256)
});

export async function POST(request: Request) {
  const session = await requireUserSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  try {
    const payload = acceptInviteSchema.parse(await request.json());

    const accepted = await acceptWorkspaceInvite(
      payload.token,
      session.user.id,
      session.user.email
    );

    if (accepted === "invalid") {
      return NextResponse.json({ ok: false, error: "Invite is invalid or expired" }, { status: 400 });
    }

    if (accepted === "email-mismatch") {
      return NextResponse.json(
        { ok: false, error: "Invite email does not match signed-in user" },
        { status: 403 }
      );
    }

    return NextResponse.json({
      ok: true,
      invite: accepted,
      workspaceId: accepted.workspaceId
    });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        error: error instanceof Error ? error.message : "Unable to accept invite"
      },
      { status: 400 }
    );
  }
}
