import type { MetadataRoute } from "next";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = "https://anirul.health";
  const now = new Date();

  return ["", "/product", "/platform", "/security", "/pilots", "/about"].map((path) => ({
    url: `${base}${path}`,
    lastModified: now,
    changeFrequency: "weekly",
    priority: path === "" ? 1 : path === "/product" ? 0.95 : 0.8
  }));
}
