import Link from "next/link";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Anirul Login | Access your health intelligence workspace",
  description: "Sign in or sign up to access the Anirul continuity intelligence workspace."
};

export default function AuthPage() {
  return (
    <main className="section auth-shell">
      <section className="section page-hero">
        <p className="kicker">Secure access</p>
        <h1 className="page-title">Sign in to Anirul</h1>
        <p className="lede">
          Access the continuity workspace for patient intake, timeline capture, and doctor-ready summaries.
        </p>
      </section>

      <div className="auth-actions">
        <Link href="/auth/login" className="btn">
          Login with email
        </Link>
        <Link href="/auth/signup" className="btn ghost">
          Create an account
        </Link>
      </div>
    </main>
  );
}
