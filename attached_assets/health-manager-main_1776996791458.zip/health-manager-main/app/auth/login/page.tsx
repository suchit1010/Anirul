"use client";

import { useState, type FormEvent } from "react";
import { createBrowserSupabase } from "@/lib/supabase-client";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setMessage(null);
    setIsSubmitting(true);

    const supabase = createBrowserSupabase();
    const { error: authError } = await supabase.auth.signInWithOtp({
      email,
      options: {
        emailRedirectTo: `${window.location.origin}/product`
      }
    });

    setIsSubmitting(false);

    if (authError) {
      setError(authError.message || "Unable to send login link.");
      return;
    }

    setMessage("Check your inbox for the login link. You will be redirected after signing in.");
  }

  return (
    <main className="section auth-shell">
      <section className="section page-hero">
        <p className="kicker">Login</p>
        <h1 className="page-title">Sign in with email</h1>
        <p className="lede">Enter your email and we’ll send you a secure magic link to access the workspace.</p>
      </section>

      <section className="section auth-card card">
        <form className="contact-form" onSubmit={handleSubmit}>
          <label>
            Email address
            <input
              type="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              placeholder="you@your-domain.com"
              required
            />
          </label>

          <button type="submit" className="btn" disabled={isSubmitting}>
            {isSubmitting ? "Sending link…" : "Send login link"}
          </button>

          {message ? <p className="success-text">{message}</p> : null}
          {error ? <p className="error-text">{error}</p> : null}
        </form>

        <p className="muted-copy">
          Don’t have an account? <a href="/auth/signup">Sign up instead.</a>
        </p>
      </section>
    </main>
  );
}
