"use client";

import { useState, type FormEvent } from "react";
import { createBrowserSupabase } from "@/lib/supabase-client";

export default function SignupPage() {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setMessage(null);
    setIsSubmitting(true);

    const supabase = createBrowserSupabase();
    const { error: authError } = await supabase.auth.signInWithOtp({
      email,
      options: {
        emailRedirectTo: `${window.location.origin}/product`
      }
    });

    setIsSubmitting(false);

    if (authError) {
      setError(authError.message || "Unable to send signup link.");
      return;
    }

    setMessage("A signup link has been sent. Check your inbox to continue.");
  }

  return (
    <main className="section auth-shell">
      <section className="section page-hero">
        <p className="kicker">Sign up</p>
        <h1 className="page-title">Create a new Anirul account</h1>
        <p className="lede">Use your email to register and access the continuity workspace securely.</p>
      </section>

      <section className="section auth-card card">
        <form className="contact-form" onSubmit={handleSubmit}>
          <label>
            Email address
            <input
              type="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              placeholder="you@your-domain.com"
              required
            />
          </label>

          <button type="submit" className="btn" disabled={isSubmitting}>
            {isSubmitting ? "Sending signup link…" : "Send signup link"}
          </button>

          {message ? <p className="success-text">{message}</p> : null}
          {error ? <p className="error-text">{error}</p> : null}
        </form>

        <p className="muted-copy">
          Already registered? <a href="/auth/login">Login instead.</a>
        </p>
      </section>
    </main>
  );
}
