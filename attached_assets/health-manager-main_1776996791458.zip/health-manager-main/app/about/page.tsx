import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";

export const metadata: Metadata = {
  title: "About Anirul | Company",
  description:
    "Learn the mission behind Anirul and why healthcare continuity is the highest-leverage problem in India."
};

const values = [
  {
    title: "Continuity over storage",
    body: "The product is built to help people move through care, not just archive files."
  },
  {
    title: "Trust over opacity",
    body: "Every sensitive action should be auditable, explainable, and easy to revoke."
  },
  {
    title: "Clinical reality over demos",
    body: "We optimize for the messy, multilingual, family-driven workflows that actually exist."
  }
];

const facts = [
  { value: "India-first", label: "product design for real caregiving patterns" },
  { value: "AI-native", label: "summaries, trend detection, and doctor briefs" },
  { value: "Consent-governed", label: "sharing that stays under patient control" }
];

export default function AboutPage() {
  return (
    <main>
      <SiteHeader />
      <section className="section page-hero">
        <p className="kicker">About</p>
        <h1 className="page-title">We build the continuity layer healthcare forgot.</h1>
        <p className="lede">
          India has massive medical talent and growing digital rails, but the patient context layer is still broken.
          Anirul exists to make every doctor interaction context-rich and every family care journey coordinated.
        </p>
      </section>

      <section className="section dark">
        <div className="section-head">
          <p className="label">Mission</p>
          <h2>Make healthcare memory native to every patient journey</h2>
          <p>
            We are building an AI-native, consent-governed, India-first platform that reduces avoidable medical costs,
            improves doctor productivity, and strengthens long-term outcomes in chronic care.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="section-head">
          <p className="label">What We Value</p>
          <h2>Principles that shape every product decision</h2>
        </div>
        <div className="badge-grid">
          {values.map((item) => (
            <article key={item.title} className="badge-card">
              <h3>{item.title}</h3>
              <p>{item.body}</p>
            </article>
          ))}
        </div>
        <div className="stat-row">
          {facts.map((item) => (
            <div key={item.value} className="stat-block">
              <strong>{item.value}</strong>
              <span>{item.label}</span>
            </div>
          ))}
        </div>
      </section>
      <SiteFooter />
    </main>
  );
}
