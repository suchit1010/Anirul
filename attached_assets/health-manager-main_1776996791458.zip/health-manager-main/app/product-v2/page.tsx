"use client";

import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { DashboardPage } from "@/components/dashboard-page";
import { IngestionWizard } from "@/components/ingestion-wizard";

type Page = "dashboard" | "documents" | "ingestion" | "alerts" | "tasks" | "family" | "brief" | "consent";

function ProductPageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [workspaceId, setWorkspaceId] = useState("");
  const [currentPage, setCurrentPage] = useState<Page>("dashboard");
  const [showIngestionWizard, setShowIngestionWizard] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authError, setAuthError] = useState("");

  useEffect(() => {
    const checkAuth = async () => {
      try {
        // Since this is a client component, we can't directly call requireUserSession
        // Instead, we'll make an API call to verify auth
        const response = await fetch("/api/auth/session", { method: "GET" });
        if (!response.ok) {
          setAuthError("Please sign in to continue");
          router.push("/auth/login");
          return;
        }
        const data = (await response.json()) as { workspace?: string };
        setIsAuthenticated(true);

        // Get workspace from URL or create one
        const wsFromUrl = searchParams.get("ws");
        if (wsFromUrl) {
          setWorkspaceId(wsFromUrl);
        } else if (data.workspace) {
          setWorkspaceId(data.workspace);
        } else {
          // Create a new workspace
          const createRes = await fetch("/api/workspaces", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name: "My Health Records" }),
          });
          if (createRes.ok) {
            const created = (await createRes.json()) as { id?: string };
            if (created.id) {
              setWorkspaceId(created.id);
            }
          }
        }
      } catch (error) {
        console.error("Auth check failed:", error);
        setAuthError("Authentication check failed");
      }
    };

    void checkAuth();
  }, [router, searchParams]);

  if (!isAuthenticated) {
    return (
      <div style={{ padding: "2rem", textAlign: "center" }}>
        <p>{authError || "Loading..."}</p>
      </div>
    );
  }

  if (!workspaceId) {
    return (
      <div style={{ padding: "2rem", textAlign: "center" }}>
        <p>Setting up your workspace...</p>
      </div>
    );
  }

  return (
    <main className="product-main">
      {/* Navigation Bar */}
      <nav className="product-nav">
        <div className="product-nav-content">
          <h1 className="product-nav-title">SwasthAI</h1>
          <div className="product-nav-links">
            <button
              className={`nav-link ${currentPage === "dashboard" ? "active" : ""}`}
              onClick={() => setCurrentPage("dashboard")}
            >
              Dashboard
            </button>
            <button
              className={`nav-link ${currentPage === "documents" ? "active" : ""}`}
              onClick={() => setCurrentPage("documents")}
            >
              Documents
            </button>
            <button
              className={`nav-link ${currentPage === "alerts" ? "active" : ""}`}
              onClick={() => setCurrentPage("alerts")}
            >
              Alerts
            </button>
            <button
              className={`nav-link ${currentPage === "tasks" ? "active" : ""}`}
              onClick={() => setCurrentPage("tasks")}
            >
              Tasks
            </button>
            <button
              className={`nav-link ${currentPage === "brief" ? "active" : ""}`}
              onClick={() => setCurrentPage("brief")}
            >
              Brief
            </button>
            <button
              className={`nav-link ${currentPage === "family" ? "active" : ""}`}
              onClick={() => setCurrentPage("family")}
            >
              Family
            </button>
          </div>
          <div className="product-nav-actions">
            <button className="btn-icon" onClick={() => router.push("/auth/logout")}>
              Sign Out
            </button>
          </div>
        </div>
      </nav>

      {/* Content */}
      <div className="product-content">
        {currentPage === "dashboard" && (
          <DashboardPage
            workspaceId={workspaceId}
            onNavigate={(section) => {
              if (section === "ingestion") {
                setShowIngestionWizard(true);
              } else {
                setCurrentPage(section as Page);
              }
            }}
          />
        )}

        {currentPage === "documents" && (
          <div className="placeholder-section">
            <h2>Documents</h2>
            <p>Document list and management coming soon</p>
            <button
              className="btn primary-action"
              onClick={() => setShowIngestionWizard(true)}
            >
              Add Document
            </button>
          </div>
        )}

        {currentPage === "alerts" && (
          <div className="placeholder-section">
            <h2>Clinical Alerts</h2>
            <p>Alert management and timeline coming soon</p>
          </div>
        )}

        {currentPage === "tasks" && (
          <div className="placeholder-section">
            <h2>Care Tasks</h2>
            <p>Task management and tracking coming soon</p>
          </div>
        )}

        {currentPage === "brief" && (
          <div className="placeholder-section">
            <h2>Doctor Brief</h2>
            <p>Clinical summary for doctors coming soon</p>
          </div>
        )}

        {currentPage === "family" && (
          <div className="placeholder-section">
            <h2>Family & Sharing</h2>
            <p>Family member management and access control coming soon</p>
          </div>
        )}
      </div>

      {/* Ingestion Wizard Modal */}
      {showIngestionWizard && (
        <IngestionWizard
          workspaceId={workspaceId}
          onSuccess={() => {
            setShowIngestionWizard(false);
            setCurrentPage("documents");
          }}
          onCancel={() => setShowIngestionWizard(false)}
        />
      )}
    </main>
  );
}

export default function ProductPage() {
  return (
    <Suspense fallback={<div style={{ padding: "2rem" }}>Loading...</div>}>
      <ProductPageContent />
    </Suspense>
  );
}
