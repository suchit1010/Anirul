import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { LeadForm } from "@/components/lead-form";

export const metadata: Metadata = {
  title: "Anirul Pilots | Partner with us",
  description:
    "Apply for an Anirul pilot to deploy healthcare continuity intelligence in your clinic, hospital, or care network."
};

const outcomes = [
  "Reduce duplicate diagnostics across repeat consults",
  "Cut doctor history-reconstruction time during OPD",
  "Increase chronic follow-up adherence",
  "Create consent-governed patient context sharing"
];

const fit = [
  {
    title: "Clinics with repeat consults",
    body: "Best for teams that see the same patients often enough for continuity to matter."
  },
  {
    title: "Networks managing chronic care",
    body: "Strong fit for providers coordinating diabetes, hypertension, and long-running treatment plans."
  },
  {
    title: "Families carrying fragmented records",
    body: "Useful wherever reports, prescriptions, and follow-ups are spread across many channels."
  }
];

export default function PilotsPage() {
  return (
    <main>
      <SiteHeader />
      <section className="section page-hero">
        <p className="kicker">Pilot Program</p>
        <h1 className="page-title">Deploy Anirul in real care workflows.</h1>
        <p className="lede">
          We onboard design partners who want continuity-first operations in chronic care and longitudinal case management.
        </p>
      </section>

      <section className="section dark">
        <div className="section-head">
          <p className="label">Pilot Outcomes</p>
          <h2>What we target during the first 90 days</h2>
        </div>
        <ul className="trust-list">
          {outcomes.map((outcome) => (
            <li key={outcome}>{outcome}</li>
          ))}
        </ul>
      </section>

      <section className="section">
        <div className="section-head">
          <p className="label">Best Fit</p>
          <h2>Who should apply for a pilot</h2>
        </div>
        <div className="badge-grid">
          {fit.map((item) => (
            <article key={item.title} className="badge-card">
              <h3>{item.title}</h3>
              <p>{item.body}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section">
        <div className="section-head">
          <p className="label">Apply</p>
          <h2>Apply for implementation planning</h2>
          <p>Share your organization profile and pilot objective. We respond within 72 hours and can scope data flow, workflow fit, and pilot success metrics.
          </p>
        </div>
        <LeadForm />
      </section>
      <SiteFooter />
    </main>
  );
}
