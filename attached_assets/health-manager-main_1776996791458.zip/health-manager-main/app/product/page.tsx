import type { Metadata } from "next";
import { Suspense } from "react";
import { ProductWorkspace } from "@/components/product-workspace";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";
import { redirect } from "next/navigation";
import { requireUserSession } from "@/lib/auth-server";

export const metadata: Metadata = {
  title: "Anirul Product | Live Continuity Workspace",
  description:
    "Use the live Anirul product workspace to capture patient context, build a timeline, and generate doctor-ready continuity briefs."
};

export const dynamic = "force-dynamic";

export default async function ProductPage() {
  const session = await requireUserSession();

  if (!session) {
    redirect("/auth/login");
  }
  return (
    <main>
      <SiteHeader />

      <section className="section page-hero">
        <p className="kicker">Live Product</p>
        <h1 className="page-title">Anirul workspace: intake, timeline, and doctor briefing.</h1>
        <p className="lede">
          This is a working MVP flow for continuity intelligence. Add a patient profile, ingest records,
          generate a consult-ready brief, and share the same workspace with your team or judges.
        </p>
      </section>

      <Suspense
        fallback={
          <section className="section product-shell">
            <div className="section-head">
              <p className="label">Product Workspace</p>
              <h2>Loading workspace...</h2>
            </div>
          </section>
        }
      >
        <ProductWorkspace />
      </Suspense>
      <SiteFooter />
    </main>
  );
}