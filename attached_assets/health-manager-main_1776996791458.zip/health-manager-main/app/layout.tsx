import type { Metadata } from "next";
import Script from "next/script";
import "./globals.css";

export const metadata: Metadata = {
  title: "Anirul | The Health Continuity Intelligence Company",
  description:
    "Anirul builds India-first healthcare continuity infrastructure: AI health memory, doctor briefs, and consented secure sharing.",
  metadataBase: new URL("https://anirul.health"),
  openGraph: {
    title: "Anirul | The Health Continuity Intelligence Company",
    description:
      "Anirul turns fragmented medical records into continuity intelligence for doctors, patients, and care networks.",
    url: "https://anirul.health",
    siteName: "Anirul",
    type: "website"
  },
  twitter: {
    card: "summary_large_image",
    title: "Anirul | The Health Continuity Intelligence Company",
    description:
      "Anirul turns fragmented medical records into continuity intelligence for doctors, patients, and care networks."
  }
};

export default function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  const plausibleDomain = process.env.NEXT_PUBLIC_PLAUSIBLE_DOMAIN;
  const gaId = process.env.NEXT_PUBLIC_GA_ID;

  return (
    <html lang="en">
      <body>
        {plausibleDomain ? (
          <Script
            defer
            data-domain={plausibleDomain}
            src="https://plausible.io/js/script.js"
          />
        ) : null}
        {gaId ? (
          <>
            <Script
              src={`https://www.googletagmanager.com/gtag/js?id=${gaId}`}
              strategy="afterInteractive"
            />
            <Script id="ga-init" strategy="afterInteractive">
              {`
                window.dataLayer = window.dataLayer || [];
                function gtag(){dataLayer.push(arguments);}
                gtag('js', new Date());
                gtag('config', '${gaId}');
              `}
            </Script>
          </>
        ) : null}
        {children}
      </body>
    </html>
  );
}
