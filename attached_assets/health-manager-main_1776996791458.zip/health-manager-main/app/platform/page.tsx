import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";

export const metadata: Metadata = {
  title: "Anirul Platform | Health Continuity Infrastructure",
  description:
    "Understand Anirul’s platform modules: health memory, doctor briefing, continuity signals, and consented sharing."
};

const modules = [
  {
    title: "Universal Ingestion",
    body: "Ingest PDFs, images, and voice notes; normalize all records into one clinically structured timeline."
  },
  {
    title: "Doctor Brief Engine",
    body: "Create context-specific summaries before every consult to reduce history reconstruction time."
  },
  {
    title: "Continuity Signals",
    body: "Detect trend drift, missing follow-up, and duplicate diagnostics across fragmented providers."
  },
  {
    title: "Consent & Sharing",
    body: "Patient-controlled sharing with verifiable audit trails and revocable access controls."
  }
];

const outcomes = [
  {
    title: "Faster intake",
    body: "Turn messy record collection into a guided workflow that creates usable context before the consult begins."
  },
  {
    title: "Cleaner care continuity",
    body: "Keep labs, prescriptions, and follow-up plans in one longitudinal memory across providers and family caregivers."
  },
  {
    title: "Lower operational waste",
    body: "Reduce repeated questions, duplicate diagnostics, and the overhead of reconstructing history from scratch."
  }
];

export default function PlatformPage() {
  return (
    <main>
      <SiteHeader />
      <section className="section page-hero">
        <p className="kicker">Platform</p>
        <h1 className="page-title">Clinical continuity infrastructure built for Indian healthcare.</h1>
        <p className="lede">
          Anirul layers intelligence on top of existing records so every consultation starts with context,
          and every care journey keeps continuity across time and providers.
        </p>
      </section>

      <section className="section dark">
        <div className="section-head">
          <p className="label">Platform Modules</p>
          <h2>What powers Anirul in production workflows</h2>
        </div>
        <div className="grid three">
          {modules.map((module) => (
            <article className="card" key={module.title}>
              <h3>{module.title}</h3>
              <p>{module.body}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section">
        <div className="section-head">
          <p className="label">Operational Outcome</p>
          <h2>Built to help teams move from record chaos to clinical clarity</h2>
        </div>
        <div className="badge-grid">
          {outcomes.map((item) => (
            <article key={item.title} className="badge-card">
              <h3>{item.title}</h3>
              <p>{item.body}</p>
            </article>
          ))}
        </div>
      </section>
      <SiteFooter />
    </main>
  );
}
