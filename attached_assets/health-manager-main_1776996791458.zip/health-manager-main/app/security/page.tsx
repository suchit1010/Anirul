import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";

export const metadata: Metadata = {
  title: "Anirul Security | Privacy, Consent, and Trust",
  description:
    "Security architecture of Anirul: encrypted PHI, off-chain storage, Solana consent receipts, and verifiable audit trails."
};

const controls = [
  "PHI encrypted at rest and in transit",
  "Role-scoped access and least-privilege service boundaries",
  "Immutable consent receipts and access attestations",
  "Off-chain PHI with on-chain integrity hash anchoring",
  "Explainable AI outputs with human override pathways"
];

const principles = [
  {
    title: "Data plane stays private",
    body: "Clinical artifacts remain encrypted off-chain so access can be controlled, revoked, and audited."
  },
  {
    title: "Trust plane stays verifiable",
    body: "Consent receipts and integrity proofs live where they can be independently checked without exposing PHI."
  },
  {
    title: "Clinician judgment stays central",
    body: "AI summarizes and organizes context, but the doctor decides what matters and what action comes next."
  }
];

export default function SecurityPage() {
  return (
    <main>
      <SiteHeader />
      <section className="section page-hero">
        <p className="kicker">Security & Trust</p>
        <h1 className="page-title">Built for healthcare-grade trust, not growth hacks.</h1>
        <p className="lede">
          Anirul uses a trust-plane/data-plane model: sensitive clinical data remains encrypted off-chain,
          while consent and integrity are verifiable through cryptographic proofs.
        </p>
      </section>

      <section className="section dark">
        <div className="section-head">
          <p className="label">Security Controls</p>
          <h2>Production controls designed for high-trust healthcare adoption</h2>
        </div>
        <ul className="trust-list">
          {controls.map((control) => (
            <li key={control}>{control}</li>
          ))}
        </ul>
      </section>

      <section className="section">
        <div className="section-head">
          <p className="label">Trust Model</p>
          <h2>A simple architecture that keeps sensitive care data where it belongs</h2>
        </div>
        <div className="badge-grid">
          {principles.map((item) => (
            <article key={item.title} className="badge-card">
              <h3>{item.title}</h3>
              <p>{item.body}</p>
            </article>
          ))}
        </div>
      </section>
      <SiteFooter />
    </main>
  );
}
