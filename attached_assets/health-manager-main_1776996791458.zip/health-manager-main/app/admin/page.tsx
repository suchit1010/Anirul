import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { isDevAdminBypassEnabled, requireUserSession } from "@/lib/auth-server";
import { ensureUserProfileFromSession } from "@/lib/user-profile";

export const metadata: Metadata = {
  title: "Admin Access | Anirul",
  description: "Admin route to access and test the full product workspace."
};

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const session = await requireUserSession();

  if (!session) {
    redirect("/auth/login");
  }

  if (isDevAdminBypassEnabled()) {
    redirect("/product");
  }

  const profile = await ensureUserProfileFromSession(session);

  if (profile.role === "ADMIN") {
    redirect("/product");
  }

  return (
    <main>
      <section className="section page-hero">
        <p className="kicker">Admin Access</p>
        <h1 className="page-title">Admin role required</h1>
        <p className="lede">
          This route is reserved for admins. Your current role is <strong>{profile.role}</strong>.
          Update your role to <strong>ADMIN</strong> and revisit <code>/admin</code> to enter the full
          product test flow.
        </p>
        <p>
          <Link href="/product">Go to product directly</Link>
        </p>
      </section>
    </main>
  );
}
