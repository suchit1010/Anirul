"use client";

import { useState, type FormEvent } from "react";

type MonthlyPatients = "lt_1000" | "1k_5k" | "5k_20k" | "20k_plus";

type LeadState = {
  fullName: string;
  workEmail: string;
  organization: string;
  role: string;
  monthlyPatients: MonthlyPatients;
  objective: string;
};

const initialState: LeadState = {
  fullName: "",
  workEmail: "",
  organization: "",
  role: "",
  monthlyPatients: "lt_1000",
  objective: ""
};

export function LeadForm() {
  const [state, setState] = useState<LeadState>(initialState);
  const [status, setStatus] = useState<"idle" | "submitting" | "success" | "error">("idle");
  const [feedback, setFeedback] = useState("");

  function update<K extends keyof LeadState>(key: K, value: LeadState[K]) {
    setState((previous: LeadState) => ({ ...previous, [key]: value }));
  }

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus("submitting");
    setFeedback("");

    try {
      const response = await fetch("/api/lead", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(state)
      });

      const body = (await response.json()) as {
        ok: boolean;
        message?: string;
        error?: string;
      };

      if (!response.ok || !body.ok) {
        throw new Error(body.error || "Unable to submit request");
      }

      setStatus("success");
      setFeedback(body.message || "Pilot request submitted.");
      setState(initialState);
    } catch (error) {
      setStatus("error");
      setFeedback(error instanceof Error ? error.message : "Something went wrong");
    }
  }

  return (
    <form id="lead" className="contact-form" onSubmit={onSubmit}>
      <div className="field-grid">
        <label>
          Full name
          <input
            required
            value={state.fullName}
            onChange={(event) => update("fullName", event.target.value)}
            placeholder="Your full name"
          />
        </label>

        <label>
          Work email
          <input
            required
            type="email"
            value={state.workEmail}
            onChange={(event) => update("workEmail", event.target.value)}
            placeholder="name@organization.com"
          />
        </label>
      </div>

      <div className="field-grid">
        <label>
          Organization
          <input
            required
            value={state.organization}
            onChange={(event) => update("organization", event.target.value)}
            placeholder="Clinic / hospital / network"
          />
        </label>

        <label>
          Role
          <input
            required
            value={state.role}
            onChange={(event) => update("role", event.target.value)}
            placeholder="Founder, COO, CMIO, etc."
          />
        </label>
      </div>

      <div className="field-grid">
        <label>
          Monthly patient volume
          <select
            value={state.monthlyPatients}
            onChange={(event) => update("monthlyPatients", event.target.value as MonthlyPatients)}
          >
            <option value="lt_1000">&lt; 1,000</option>
            <option value="1k_5k">1,000–5,000</option>
            <option value="5k_20k">5,000–20,000</option>
            <option value="20k_plus">20,000+</option>
          </select>
        </label>
      </div>

      <label>
        Pilot objective
        <textarea
          required
          minLength={25}
          value={state.objective}
          onChange={(event) => update("objective", event.target.value)}
          placeholder="What continuity problem do you need solved first?"
        />
      </label>

      <button type="submit" disabled={status === "submitting"}>
        {status === "submitting" ? "Submitting..." : "Submit pilot application"}
      </button>

      {feedback ? (
        <p className={`feedback ${status === "error" ? "error" : "success"}`}>{feedback}</p>
      ) : null}
    </form>
  );
}
