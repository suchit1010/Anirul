"use client";

import {
  useEffect,
  useMemo,
  useState,
  type FormEvent
} from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import {
  buildDoctorBrief,
  DEMO_PRODUCT_STATE,
  EMPTY_PRODUCT_STATE,
  PRODUCT_STORAGE_KEY,
  sortRecords,
  updateProductState,
  type ClinicalSummarySnapshot,
  type ProductState,
  type RecordType,
  type TimelineRecord
} from "@/lib/product-engine";

type PatientDraft = {
  fullName: string;
  age: string;
  conditions: string;
  primaryDoctor: string;
};

type RecordDraft = {
  date: string;
  type: RecordType;
  title: string;
  summary: string;
  source: string;
  labValue: string;
  unit: string;
};

const initialPatientDraft: PatientDraft = {
  fullName: "",
  age: "",
  conditions: "",
  primaryDoctor: ""
};

const initialRecordDraft: RecordDraft = {
  date: new Date().toISOString().slice(0, 10),
  type: "note",
  title: "",
  summary: "",
  source: "",
  labValue: "",
  unit: ""
};

function parsePersistedState(raw: string | null): ProductState {
  if (!raw) {
    return EMPTY_PRODUCT_STATE;
  }

  try {
    return JSON.parse(raw) as ProductState;
  } catch {
    return EMPTY_PRODUCT_STATE;
  }
}

function toOptionalNumber(value: string): number | undefined {
  const normalized = value.trim();
  if (!normalized) {
    return undefined;
  }
  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : undefined;
}

function escapeCsvCell(value: string): string {
  if (/[",\n]/.test(value)) {
    return `"${value.replace(/"/g, '""')}"`;
  }
  return value;
}

function riskLevelTone(level?: "LOW" | "MODERATE" | "HIGH" | "CRITICAL" | null): string {
  if (!level) {
    return "neutral";
  }

  if (level === "CRITICAL") {
    return "critical";
  }

  if (level === "HIGH") {
    return "high";
  }

  if (level === "MODERATE") {
    return "moderate";
  }

  return "low";
}

type WorkspacePayload = {
  ok: boolean;
  workspaceId?: string;
  state?: ProductState;
  error?: string;
};

type WorkspaceMember = {
  userId: string;
  email: string | null;
  fullName: string | null;
  role: "OWNER" | "EDITOR" | "VIEWER";
  invitedById: string | null;
  createdAt: string;
  updatedAt: string;
};

type WorkspaceMembersPayload = {
  ok: boolean;
  members?: WorkspaceMember[];
  member?: WorkspaceMember;
  removedUserId?: string;
  error?: string;
};

type WorkspaceInvite = {
  id: string;
  workspaceId: string;
  email: string;
  role: "OWNER" | "EDITOR" | "VIEWER";
  token: string;
  status: "PENDING" | "ACCEPTED" | "REVOKED" | "EXPIRED";
  invitedById: string;
  acceptedById: string | null;
  expiresAt: string;
  acceptedAt: string | null;
  revokedAt: string | null;
  createdAt: string;
  updatedAt: string;
};

type WorkspaceInvitesPayload = {
  ok: boolean;
  invites?: WorkspaceInvite[];
  invite?: WorkspaceInvite;
  workspaceId?: string;
  error?: string;
};

type WorkspaceDocument = {
  id: string;
  workspaceId: string;
  uploadedById: string;
  sourceChannel: "DIRECT_UPLOAD" | "WHATSAPP_FORWARD" | "AUDIO_TRANSCRIPT";
  sourceContext: string | null;
  originalName: string;
  mimeType: string;
  sizeBytes: number;
  status: "UPLOADED" | "PROCESSED" | "FAILED";
  extractionNote: string | null;
  extractedTextPreview: string | null;
  extractedData: unknown;
  createdAt: string;
  updatedAt: string;
};

type ExtractionJob = {
  id: string;
  documentId: string;
  requestedBy: string;
  status: "QUEUED" | "PROCESSING" | "COMPLETED" | "FAILED";
  error: string | null;
  startedAt: string | null;
  finishedAt: string | null;
  createdAt: string;
  updatedAt: string;
};

type WorkspaceDocumentsPayload = {
  ok: boolean;
  documents?: WorkspaceDocument[];
  document?: WorkspaceDocument;
  job?: ExtractionJob;
  error?: string;
};

type ClinicalSummaryPayload = {
  ok: boolean;
  summary?: ClinicalSummarySnapshot;
  error?: string;
};

type ClinicalAlertLifecycleStatus = "active" | "acknowledged" | "resolved";

type ClinicalAlertItem = {
  id: string;
  title: string;
  severity: "LOW" | "MODERATE" | "HIGH" | "CRITICAL";
  description: string;
  actionItems: string[];
  acknowledgedAt: string | null;
  acknowledgedById: string | null;
  resolvedAt: string | null;
  createdAt: string;
};

type ClinicalAlertsPayload = {
  ok: boolean;
  alerts?: ClinicalAlertItem[];
  status?: ClinicalAlertLifecycleStatus | "all";
  error?: string;
};

type ClinicalAlertEventItem = {
  id: string;
  alertId: string;
  action: "CREATED" | "ACKNOWLEDGED" | "RESOLVED";
  actorUserId: string | null;
  actorDisplay: string | null;
  actorLabel: string;
  note: string | null;
  createdAt: string;
};

type ClinicalAlertEventsPayload = {
  ok: boolean;
  events?: ClinicalAlertEventItem[];
  pagination?: {
    page: number;
    pageSize: number;
    total: number;
    totalPages: number;
    hasMore: boolean;
  };
  error?: string;
};

type ConsentScope = "DOCTOR_BRIEF" | "FULL_TIMELINE" | "LAB_TRENDS" | "ALERTS" | "DOCUMENTS";

type ConsentItem = {
  id: string;
  workspaceId: string;
  grantedById: string;
  subjectName: string;
  subjectContact: string;
  purpose: string;
  scopes: ConsentScope[];
  status: "ACTIVE" | "REVOKED" | "EXPIRED";
  expiresAt: string;
  revokedAt: string | null;
  revokeReason: string | null;
  createdAt: string;
  updatedAt: string;
};

type ConsentEventItem = {
  id: string;
  consentId: string;
  workspaceId: string;
  action: "CREATED" | "REVOKED" | "EXPIRED";
  actorUserId: string | null;
  actorDisplay: string | null;
  actorLabel: string;
  note: string | null;
  createdAt: string;
};

type WorkspaceConsentsPayload = {
  ok: boolean;
  status?: "ACTIVE" | "REVOKED" | "EXPIRED" | "all";
  consents?: ConsentItem[];
  events?: ConsentEventItem[];
  consent?: ConsentItem;
  error?: string;
};

type CareTaskItem = {
  id: string;
  workspaceId: string;
  patientId: string | null;
  title: string;
  description: string | null;
  dueAt: string | null;
  priority: "LOW" | "MODERATE" | "HIGH";
  status: "PENDING" | "COMPLETED" | "SKIPPED";
  source: "MANUAL" | "ALERT_FOLLOWUP" | "RISK_FOLLOWUP";
  sourceRefId: string | null;
  createdById: string;
  completedAt: string | null;
  completedById: string | null;
  createdAt: string;
  updatedAt: string;
};

type CareTaskEventItem = {
  id: string;
  taskId: string;
  workspaceId: string;
  action: "CREATED" | "COMPLETED" | "SKIPPED" | "REOPENED";
  actorUserId: string | null;
  actorDisplay: string | null;
  actorLabel: string;
  note: string | null;
  createdAt: string;
};

type WorkspaceCareTasksPayload = {
  ok: boolean;
  status?: "PENDING" | "COMPLETED" | "SKIPPED" | "all";
  tasks?: CareTaskItem[];
  events?: CareTaskEventItem[];
  task?: CareTaskItem;
  error?: string;
};

type DuplicateTestCheckItem = {
  id: string;
  workspaceId: string;
  patientId: string | null;
  requestedLabName: string;
  normalizedLabName: string;
  lookbackDays: number;
  isDuplicate: boolean;
  recommendation: string;
  rationale: string;
  recentTestDate: string | null;
  recentTestValue: number | null;
  recentTestStatus: "NORMAL" | "LOW" | "HIGH" | "CRITICAL" | null;
  requestedAt: string;
};

type DuplicateTestCheckPayload = {
  ok: boolean;
  check?: DuplicateTestCheckItem;
  checks?: DuplicateTestCheckItem[];
  error?: string;
};

type FamilyAccessItem = {
  id: string;
  workspaceId: string;
  profileId: string;
  userId: string;
  role: "MANAGER" | "VIEWER";
  status: "ACTIVE" | "REVOKED";
  grantedById: string;
  revokedAt: string | null;
  createdAt: string;
  updatedAt: string;
};

type FamilyProfileItem = {
  id: string;
  workspaceId: string;
  fullName: string;
  ageYears: number | null;
  sex: string | null;
  relation: "SELF" | "SPOUSE" | "CHILD" | "PARENT" | "SIBLING" | "OTHER";
  notes: string | null;
  createdById: string;
  createdAt: string;
  updatedAt: string;
  accesses: FamilyAccessItem[];
};

type FamilyAccessEventItem = {
  id: string;
  workspaceId: string;
  profileId: string;
  accessId: string;
  action: "GRANTED" | "REVOKED";
  actorUserId: string | null;
  actorDisplay: string | null;
  actorLabel: string;
  note: string | null;
  createdAt: string;
};

type WorkspaceFamilyProfilesPayload = {
  ok: boolean;
  profile?: FamilyProfileItem;
  profiles?: FamilyProfileItem[];
  events?: FamilyAccessEventItem[];
  access?: FamilyAccessItem;
  error?: string;
};

export function ProductWorkspace() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [state, setState] = useState<ProductState>(EMPTY_PRODUCT_STATE);
  const [patientDraft, setPatientDraft] = useState<PatientDraft>(initialPatientDraft);
  const [recordDraft, setRecordDraft] = useState<RecordDraft>(initialRecordDraft);
  const [copied, setCopied] = useState(false);
  const [workspaceCopied, setWorkspaceCopied] = useState(false);
  const [workspaceId, setWorkspaceId] = useState("");
  const [workspaceInput, setWorkspaceInput] = useState("");
  const [inviteEmailInput, setInviteEmailInput] = useState("");
  const [inviteRoleInput, setInviteRoleInput] = useState<"EDITOR" | "VIEWER">("VIEWER");
  const [invites, setInvites] = useState<WorkspaceInvite[]>([]);
  const [invitesMessage, setInvitesMessage] = useState("");
  const [memberUserIdInput, setMemberUserIdInput] = useState("");
  const [memberRoleInput, setMemberRoleInput] = useState<"EDITOR" | "VIEWER">("VIEWER");
  const [members, setMembers] = useState<WorkspaceMember[]>([]);
  const [membersMessage, setMembersMessage] = useState("");
  const [documents, setDocuments] = useState<WorkspaceDocument[]>([]);
  const [documentsMessage, setDocumentsMessage] = useState("");
  const [consents, setConsents] = useState<ConsentItem[]>([]);
  const [consentEvents, setConsentEvents] = useState<ConsentEventItem[]>([]);
  const [consentsMessage, setConsentsMessage] = useState("");
  const [consentActionMessage, setConsentActionMessage] = useState("");
  const [consentSubjectName, setConsentSubjectName] = useState("");
  const [consentSubjectContact, setConsentSubjectContact] = useState("");
  const [consentPurpose, setConsentPurpose] = useState("");
  const [consentExpiresOn, setConsentExpiresOn] = useState("");
  const [consentScopes, setConsentScopes] = useState<ConsentScope[]>(["DOCTOR_BRIEF", "LAB_TRENDS"]);
  const [consentStatusFilter, setConsentStatusFilter] = useState<"ACTIVE" | "REVOKED" | "EXPIRED" | "all">("all");
  const [workingConsentId, setWorkingConsentId] = useState<string | null>(null);
  const [careTasks, setCareTasks] = useState<CareTaskItem[]>([]);
  const [careTaskEvents, setCareTaskEvents] = useState<CareTaskEventItem[]>([]);
  const [careTasksMessage, setCareTasksMessage] = useState("");
  const [careTaskActionMessage, setCareTaskActionMessage] = useState("");
  const [careTaskTitle, setCareTaskTitle] = useState("");
  const [careTaskDescription, setCareTaskDescription] = useState("");
  const [careTaskDueOn, setCareTaskDueOn] = useState("");
  const [careTaskPriority, setCareTaskPriority] = useState<"LOW" | "MODERATE" | "HIGH">("MODERATE");
  const [careTaskSource, setCareTaskSource] = useState<"MANUAL" | "ALERT_FOLLOWUP" | "RISK_FOLLOWUP">("MANUAL");
  const [careTaskStatusFilter, setCareTaskStatusFilter] = useState<"PENDING" | "COMPLETED" | "SKIPPED" | "all">("all");
  const [workingCareTaskId, setWorkingCareTaskId] = useState<string | null>(null);
  const [duplicateLabName, setDuplicateLabName] = useState("HbA1c");
  const [duplicateLookbackDays, setDuplicateLookbackDays] = useState("90");
  const [duplicateChecks, setDuplicateChecks] = useState<DuplicateTestCheckItem[]>([]);
  const [latestDuplicateCheck, setLatestDuplicateCheck] = useState<DuplicateTestCheckItem | null>(null);
  const [duplicateCheckMessage, setDuplicateCheckMessage] = useState("");
  const [familyProfiles, setFamilyProfiles] = useState<FamilyProfileItem[]>([]);
  const [familyAccessEvents, setFamilyAccessEvents] = useState<FamilyAccessEventItem[]>([]);
  const [familyMessage, setFamilyMessage] = useState("");
  const [familyActionMessage, setFamilyActionMessage] = useState("");
  const [familyFullName, setFamilyFullName] = useState("");
  const [familyAgeYears, setFamilyAgeYears] = useState("");
  const [familySex, setFamilySex] = useState("");
  const [familyRelation, setFamilyRelation] = useState<"SELF" | "SPOUSE" | "CHILD" | "PARENT" | "SIBLING" | "OTHER">("OTHER");
  const [familyNotes, setFamilyNotes] = useState("");
  const [familySelectedProfileId, setFamilySelectedProfileId] = useState("");
  const [familyTargetUserId, setFamilyTargetUserId] = useState("");
  const [familyTargetRole, setFamilyTargetRole] = useState<"MANAGER" | "VIEWER">("VIEWER");
  const [pendingFile, setPendingFile] = useState<File | null>(null);
  const [whatsappForwardedText, setWhatsappForwardedText] = useState("");
  const [whatsappSenderLabel, setWhatsappSenderLabel] = useState("");
  const [audioTranscriptText, setAudioTranscriptText] = useState("");
  const [audioLanguage, setAudioLanguage] = useState("en-IN");
  const [audioDurationSeconds, setAudioDurationSeconds] = useState("");
  const [extractingDocumentId, setExtractingDocumentId] = useState<string | null>(null);
  const [clinicalSummary, setClinicalSummary] = useState<ClinicalSummarySnapshot | null>(null);
  const [clinicalSummaryMessage, setClinicalSummaryMessage] = useState("");
  const [alertStatusTab, setAlertStatusTab] = useState<ClinicalAlertLifecycleStatus>("active");
  const [lifecycleAlerts, setLifecycleAlerts] = useState<ClinicalAlertItem[]>([]);
  const [lifecycleAlertsMessage, setLifecycleAlertsMessage] = useState("");
  const [expandedAlertTimelineId, setExpandedAlertTimelineId] = useState<string | null>(null);
  const [loadingAlertTimelineId, setLoadingAlertTimelineId] = useState<string | null>(null);
  const [alertTimelineById, setAlertTimelineById] = useState<Record<string, ClinicalAlertEventItem[]>>({});
  const [alertTimelineMessage, setAlertTimelineMessage] = useState("");
  const [timelineActionFilter, setTimelineActionFilter] = useState<"all" | "CREATED" | "ACKNOWLEDGED" | "RESOLVED">("all");
  const [timelineFromDate, setTimelineFromDate] = useState("");
  const [timelineToDate, setTimelineToDate] = useState("");
  const [timelinePage, setTimelinePage] = useState(1);
  const [timelinePageSize, setTimelinePageSize] = useState(10);
  const [timelinePagination, setTimelinePagination] = useState<{
    page: number;
    pageSize: number;
    total: number;
    totalPages: number;
    hasMore: boolean;
  } | null>(null);
  const [timelineExportMessage, setTimelineExportMessage] = useState("");
  const [alertActionMessage, setAlertActionMessage] = useState("");
  const [workingAlertId, setWorkingAlertId] = useState<string | null>(null);
  const [syncState, setSyncState] = useState<"idle" | "dirty" | "syncing" | "synced" | "error">("idle");
  const [syncMessage, setSyncMessage] = useState("Local-only mode");

  useEffect(() => {
    const restored = parsePersistedState(localStorage.getItem(PRODUCT_STORAGE_KEY));
    setState(restored);

    const urlWorkspaceId = searchParams.get("ws");
    if (urlWorkspaceId) {
      setWorkspaceId(urlWorkspaceId);
      setWorkspaceInput(urlWorkspaceId);
      void loadWorkspace(urlWorkspaceId);
    }

    const inviteToken = searchParams.get("invite");
    if (inviteToken) {
      void acceptInvite(inviteToken);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    localStorage.setItem(PRODUCT_STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  const sortedRecords = useMemo(() => sortRecords(state.records), [state.records]);
  const brief = useMemo(
    () => buildDoctorBrief(state, clinicalSummary ?? undefined),
    [state, clinicalSummary]
  );
  const topRiskScores = useMemo(
    () =>
      [...(clinicalSummary?.riskScores ?? [])]
        .sort((first, second) => second.score - first.score)
        .slice(0, 4),
    [clinicalSummary]
  );
  const lifecycleAlertPreview = useMemo(() => lifecycleAlerts.slice(0, 6), [lifecycleAlerts]);
  const worseningTrendPreview = useMemo(
    () => clinicalSummary?.trends.worseningTrends.slice(0, 4) ?? [],
    [clinicalSummary]
  );

  useEffect(() => {
    if (!workspaceId || !state.patient) {
      setClinicalSummary(null);
      setClinicalSummaryMessage("");
      setLifecycleAlerts([]);
      setLifecycleAlertsMessage("");
      return;
    }

    void loadClinicalSummary(workspaceId, state.patient.fullName, state.patient.age);
    void loadLifecycleAlerts(workspaceId, state.patient.fullName, alertStatusTab);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [workspaceId, state.patient, state.records, alertStatusTab]);

  function markDirty() {
    if (workspaceId) {
      setSyncState("dirty");
      setSyncMessage("Unsynced changes");
    }
  }

  function updateUrlWorkspace(nextWorkspaceId: string) {
    const params = new URLSearchParams(searchParams.toString());
    params.set("ws", nextWorkspaceId);
    router.replace(`${pathname}?${params.toString()}`);
  }

  async function createSharedWorkspace() {
    setSyncState("syncing");
    setSyncMessage("Creating workspace...");

    try {
      const response = await fetch("/api/workspaces", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ state })
      });

      const body = (await response.json()) as WorkspacePayload;
      if (!response.ok || !body.ok || !body.workspaceId) {
        throw new Error(body.error || "Unable to create workspace");
      }

      setWorkspaceId(body.workspaceId);
      setWorkspaceInput(body.workspaceId);
      updateUrlWorkspace(body.workspaceId);
      await loadMembers(body.workspaceId);
      await loadInvites(body.workspaceId);
      await loadConsents(body.workspaceId, "all");
      await loadCareTasks(body.workspaceId, "all");
      await loadDuplicateChecks(body.workspaceId);
      await loadFamilyProfiles(body.workspaceId);
      await loadDocuments(body.workspaceId);
      setSyncState("synced");
      setSyncMessage("Workspace created and synced");
    } catch (error) {
      setSyncState("error");
      setSyncMessage(error instanceof Error ? error.message : "Create failed");
    }
  }

  async function loadWorkspace(id: string) {
    const candidate = id.trim();
    if (!candidate) {
      return;
    }

    setSyncState("syncing");
    setSyncMessage("Loading workspace...");

    try {
      const response = await fetch(`/api/workspaces/${encodeURIComponent(candidate)}`);
      const body = (await response.json()) as WorkspacePayload;

      if (!response.ok || !body.ok || !body.state || !body.workspaceId) {
        throw new Error(body.error || "Unable to load workspace");
      }

      setState(body.state);
      setWorkspaceId(body.workspaceId);
      setWorkspaceInput(body.workspaceId);
      updateUrlWorkspace(body.workspaceId);
      await loadMembers(body.workspaceId);
      await loadInvites(body.workspaceId);
      await loadConsents(body.workspaceId, "all");
      await loadCareTasks(body.workspaceId, "all");
      await loadDuplicateChecks(body.workspaceId);
      await loadFamilyProfiles(body.workspaceId);
      await loadDocuments(body.workspaceId);
      setSyncState("synced");
      setSyncMessage("Workspace loaded");
    } catch (error) {
      setSyncState("error");
      setSyncMessage(error instanceof Error ? error.message : "Load failed");
    }
  }

  async function syncWorkspace() {
    if (!workspaceId) {
      return;
    }

    setSyncState("syncing");
    setSyncMessage("Syncing workspace...");

    try {
      const response = await fetch(`/api/workspaces/${encodeURIComponent(workspaceId)}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ state })
      });

      const body = (await response.json()) as WorkspacePayload;
      if (!response.ok || !body.ok) {
        throw new Error(body.error || "Sync failed");
      }

      setSyncState("synced");
      setSyncMessage("Workspace synced");
    } catch (error) {
      setSyncState("error");
      setSyncMessage(error instanceof Error ? error.message : "Sync failed");
    }
  }

  async function loadMembers(id: string) {
    try {
      const response = await fetch(`/api/workspaces/${encodeURIComponent(id)}/members`);
      const body = (await response.json()) as WorkspaceMembersPayload;

      if (!response.ok || !body.ok || !body.members) {
        throw new Error(body.error || "Unable to load members");
      }

      setMembers(body.members);
      setMembersMessage(`Members: ${body.members.length}`);
    } catch (error) {
      setMembers([]);
      setMembersMessage(error instanceof Error ? error.message : "Unable to load members");
    }
  }

  async function loadInvites(id: string) {
    try {
      const response = await fetch(`/api/workspaces/${encodeURIComponent(id)}/invites`);
      const body = (await response.json()) as WorkspaceInvitesPayload;

      if (!response.ok || !body.ok || !body.invites) {
        throw new Error(body.error || "Unable to load invites");
      }

      setInvites(body.invites);
      setInvitesMessage(`Invites: ${body.invites.length}`);
    } catch (error) {
      setInvites([]);
      setInvitesMessage(error instanceof Error ? error.message : "Unable to load invites");
    }
  }

  async function loadDocuments(id: string) {
    try {
      const response = await fetch(`/api/workspaces/${encodeURIComponent(id)}/documents`);
      const body = (await response.json()) as WorkspaceDocumentsPayload;

      if (!response.ok || !body.ok || !body.documents) {
        throw new Error(body.error || "Unable to load documents");
      }

      setDocuments(body.documents);
      setDocumentsMessage(`Documents: ${body.documents.length}`);
    } catch (error) {
      setDocuments([]);
      setDocumentsMessage(error instanceof Error ? error.message : "Unable to load documents");
    }
  }

  async function loadConsents(
    id: string,
    status: "ACTIVE" | "REVOKED" | "EXPIRED" | "all" = consentStatusFilter
  ) {
    try {
      setConsentsMessage("Loading consents...");
      const query = new URLSearchParams({ status });
      const response = await fetch(
        `/api/workspaces/${encodeURIComponent(id)}/consents?${query.toString()}`
      );
      const body = (await response.json()) as WorkspaceConsentsPayload;

      if (!response.ok || !body.ok || !body.consents || !body.events) {
        throw new Error(body.error || "Unable to load consents");
      }

      setConsents(body.consents);
      setConsentEvents(body.events);
      setConsentsMessage(
        `Consents: ${body.consents.length} · Events: ${body.events.length}`
      );
    } catch (error) {
      setConsents([]);
      setConsentEvents([]);
      setConsentsMessage(error instanceof Error ? error.message : "Unable to load consents");
    }
  }

  async function createConsent(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!workspaceId || !consentSubjectName.trim() || !consentSubjectContact.trim() || !consentPurpose.trim()) {
      return;
    }

    if (!consentExpiresOn) {
      setConsentActionMessage("Set consent expiry date");
      return;
    }

    if (consentScopes.length === 0) {
      setConsentActionMessage("Select at least one consent scope");
      return;
    }

    try {
      setConsentActionMessage("Creating consent...");
      const expiresAt = new Date(`${consentExpiresOn}T23:59:59.999Z`).toISOString();
      const response = await fetch(`/api/workspaces/${encodeURIComponent(workspaceId)}/consents`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          subjectName: consentSubjectName.trim(),
          subjectContact: consentSubjectContact.trim(),
          purpose: consentPurpose.trim(),
          scopes: consentScopes,
          expiresAt
        })
      });

      const body = (await response.json()) as WorkspaceConsentsPayload;
      if (!response.ok || !body.ok || !body.consent) {
        throw new Error(body.error || "Unable to create consent");
      }

      setConsentSubjectName("");
      setConsentSubjectContact("");
      setConsentPurpose("");
      setConsentExpiresOn("");
      setConsentScopes(["DOCTOR_BRIEF", "LAB_TRENDS"]);
      await loadConsents(workspaceId);
      setConsentActionMessage("Consent created");
    } catch (error) {
      setConsentActionMessage(error instanceof Error ? error.message : "Unable to create consent");
    }
  }

  async function revokeConsent(consentId: string) {
    if (!workspaceId) {
      return;
    }

    try {
      setWorkingConsentId(consentId);
      setConsentActionMessage("Revoking consent...");

      const response = await fetch(
        `/api/workspaces/${encodeURIComponent(workspaceId)}/consents/${encodeURIComponent(consentId)}`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            action: "revoke",
            reason: "Revoked from workspace consent panel"
          })
        }
      );

      const body = (await response.json()) as WorkspaceConsentsPayload;
      if (!response.ok || !body.ok) {
        throw new Error(body.error || "Unable to revoke consent");
      }

      await loadConsents(workspaceId);
      setConsentActionMessage("Consent revoked");
    } catch (error) {
      setConsentActionMessage(error instanceof Error ? error.message : "Unable to revoke consent");
    } finally {
      setWorkingConsentId(null);
    }
  }

  function toggleConsentScope(scope: ConsentScope) {
    setConsentScopes((previous) =>
      previous.includes(scope)
        ? previous.filter((value) => value !== scope)
        : [...previous, scope]
    );
  }

  useEffect(() => {
    if (!workspaceId) {
      return;
    }

    void loadConsents(workspaceId, consentStatusFilter);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [workspaceId, consentStatusFilter]);

  async function loadCareTasks(
    id: string,
    status: "PENDING" | "COMPLETED" | "SKIPPED" | "all" = careTaskStatusFilter
  ) {
    try {
      setCareTasksMessage("Loading care tasks...");
      const query = new URLSearchParams({ status });
      const response = await fetch(
        `/api/workspaces/${encodeURIComponent(id)}/care-tasks?${query.toString()}`
      );
      const body = (await response.json()) as WorkspaceCareTasksPayload;

      if (!response.ok || !body.ok || !body.tasks || !body.events) {
        throw new Error(body.error || "Unable to load care tasks");
      }

      setCareTasks(body.tasks);
      setCareTaskEvents(body.events);
      setCareTasksMessage(`Tasks: ${body.tasks.length} · Events: ${body.events.length}`);
    } catch (error) {
      setCareTasks([]);
      setCareTaskEvents([]);
      setCareTasksMessage(error instanceof Error ? error.message : "Unable to load care tasks");
    }
  }

  async function createCareTask(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!workspaceId || !careTaskTitle.trim()) {
      return;
    }

    try {
      setCareTaskActionMessage("Creating care task...");
      const response = await fetch(`/api/workspaces/${encodeURIComponent(workspaceId)}/care-tasks`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          patientId: state.patient?.fullName || undefined,
          title: careTaskTitle.trim(),
          description: careTaskDescription.trim() || undefined,
          dueAt: careTaskDueOn ? new Date(`${careTaskDueOn}T23:59:59.999Z`).toISOString() : undefined,
          priority: careTaskPriority,
          source: careTaskSource
        })
      });

      const body = (await response.json()) as WorkspaceCareTasksPayload;
      if (!response.ok || !body.ok || !body.task) {
        throw new Error(body.error || "Unable to create care task");
      }

      setCareTaskTitle("");
      setCareTaskDescription("");
      setCareTaskDueOn("");
      setCareTaskPriority("MODERATE");
      setCareTaskSource("MANUAL");
      await loadCareTasks(workspaceId);
      setCareTaskActionMessage("Care task created");
    } catch (error) {
      setCareTaskActionMessage(error instanceof Error ? error.message : "Unable to create care task");
    }
  }

  async function updateCareTask(taskId: string, action: "complete" | "skip" | "reopen") {
    if (!workspaceId) {
      return;
    }

    try {
      setWorkingCareTaskId(taskId);
      setCareTaskActionMessage(
        action === "complete"
          ? "Completing task..."
          : action === "skip"
            ? "Skipping task..."
            : "Reopening task..."
      );

      const response = await fetch(
        `/api/workspaces/${encodeURIComponent(workspaceId)}/care-tasks/${encodeURIComponent(taskId)}`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({ action })
        }
      );

      const body = (await response.json()) as WorkspaceCareTasksPayload;
      if (!response.ok || !body.ok) {
        throw new Error(body.error || "Unable to update care task");
      }

      await loadCareTasks(workspaceId);
      setCareTaskActionMessage(
        action === "complete"
          ? "Task completed"
          : action === "skip"
            ? "Task skipped"
            : "Task reopened"
      );
    } catch (error) {
      setCareTaskActionMessage(error instanceof Error ? error.message : "Unable to update care task");
    } finally {
      setWorkingCareTaskId(null);
    }
  }

  useEffect(() => {
    if (!workspaceId) {
      return;
    }

    void loadCareTasks(workspaceId, careTaskStatusFilter);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [workspaceId, careTaskStatusFilter]);

  async function loadDuplicateChecks(id: string) {
    try {
      setDuplicateCheckMessage("Loading duplicate checks...");
      const query = new URLSearchParams();
      if (state.patient?.fullName) {
        query.set("patientId", state.patient.fullName);
      }

      const response = await fetch(
        `/api/workspaces/${encodeURIComponent(id)}/duplicate-test-check?${query.toString()}`
      );
      const body = (await response.json()) as DuplicateTestCheckPayload;

      if (!response.ok || !body.ok || !body.checks) {
        throw new Error(body.error || "Unable to load duplicate checks");
      }

      setDuplicateChecks(body.checks);
      setDuplicateCheckMessage(`Duplicate checks: ${body.checks.length}`);
    } catch (error) {
      setDuplicateChecks([]);
      setDuplicateCheckMessage(
        error instanceof Error ? error.message : "Unable to load duplicate checks"
      );
    }
  }

  async function runDuplicateCheck(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!workspaceId || !duplicateLabName.trim()) {
      return;
    }

    try {
      setDuplicateCheckMessage("Running duplicate check...");
      const lookback = Number(duplicateLookbackDays);

      const response = await fetch(
        `/api/workspaces/${encodeURIComponent(workspaceId)}/duplicate-test-check`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            patientId: state.patient?.fullName || undefined,
            labName: duplicateLabName.trim(),
            lookbackDays: Number.isFinite(lookback) && lookback > 0 ? lookback : 90
          })
        }
      );

      const body = (await response.json()) as DuplicateTestCheckPayload;
      if (!response.ok || !body.ok || !body.check) {
        throw new Error(body.error || "Unable to run duplicate check");
      }

      setLatestDuplicateCheck(body.check);
      await loadDuplicateChecks(workspaceId);
      setDuplicateCheckMessage(body.check.isDuplicate ? "Potential duplicate found" : "No duplicate in lookback window");
    } catch (error) {
      setDuplicateCheckMessage(
        error instanceof Error ? error.message : "Unable to run duplicate check"
      );
    }
  }

  async function loadFamilyProfiles(id: string) {
    try {
      setFamilyMessage("Loading family profiles...");
      const response = await fetch(`/api/workspaces/${encodeURIComponent(id)}/family-profiles`);
      const body = (await response.json()) as WorkspaceFamilyProfilesPayload;

      if (!response.ok || !body.ok || !body.profiles || !body.events) {
        throw new Error(body.error || "Unable to load family profiles");
      }

      setFamilyProfiles(body.profiles);
      setFamilyAccessEvents(body.events);
      if (!familySelectedProfileId && body.profiles.length > 0) {
        setFamilySelectedProfileId(body.profiles[0].id);
      }
      setFamilyMessage(`Profiles: ${body.profiles.length} · Events: ${body.events.length}`);
    } catch (error) {
      setFamilyProfiles([]);
      setFamilyAccessEvents([]);
      setFamilyMessage(error instanceof Error ? error.message : "Unable to load family profiles");
    }
  }

  async function createFamilyProfile(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!workspaceId || !familyFullName.trim()) {
      return;
    }

    try {
      setFamilyActionMessage("Creating family profile...");
      const age = Number(familyAgeYears);
      const response = await fetch(`/api/workspaces/${encodeURIComponent(workspaceId)}/family-profiles`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          fullName: familyFullName.trim(),
          ageYears: Number.isFinite(age) && age >= 0 ? age : undefined,
          sex: familySex.trim() || undefined,
          relation: familyRelation,
          notes: familyNotes.trim() || undefined
        })
      });

      const body = (await response.json()) as WorkspaceFamilyProfilesPayload;
      if (!response.ok || !body.ok || !body.profile) {
        throw new Error(body.error || "Unable to create family profile");
      }

      setFamilyFullName("");
      setFamilyAgeYears("");
      setFamilySex("");
      setFamilyRelation("OTHER");
      setFamilyNotes("");
      setFamilySelectedProfileId(body.profile.id);
      await loadFamilyProfiles(workspaceId);
      setFamilyActionMessage("Family profile created");
    } catch (error) {
      setFamilyActionMessage(error instanceof Error ? error.message : "Unable to create family profile");
    }
  }

  async function grantFamilyAccess(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!workspaceId || !familySelectedProfileId || !familyTargetUserId.trim()) {
      return;
    }

    try {
      setFamilyActionMessage("Granting delegated access...");
      const response = await fetch(
        `/api/workspaces/${encodeURIComponent(workspaceId)}/family-profiles/${encodeURIComponent(familySelectedProfileId)}/access`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            action: "grant",
            targetUserId: familyTargetUserId.trim(),
            role: familyTargetRole
          })
        }
      );

      const body = (await response.json()) as WorkspaceFamilyProfilesPayload;
      if (!response.ok || !body.ok || !body.access) {
        throw new Error(body.error || "Unable to grant family access");
      }

      setFamilyTargetUserId("");
      await loadFamilyProfiles(workspaceId);
      setFamilyActionMessage("Delegated access granted");
    } catch (error) {
      setFamilyActionMessage(error instanceof Error ? error.message : "Unable to grant family access");
    }
  }

  async function revokeFamilyAccess(profileId: string, targetUserId: string) {
    if (!workspaceId) {
      return;
    }

    try {
      setFamilyActionMessage("Revoking delegated access...");
      const response = await fetch(
        `/api/workspaces/${encodeURIComponent(workspaceId)}/family-profiles/${encodeURIComponent(profileId)}/access`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            action: "revoke",
            targetUserId
          })
        }
      );

      const body = (await response.json()) as WorkspaceFamilyProfilesPayload;
      if (!response.ok || !body.ok || !body.access) {
        throw new Error(body.error || "Unable to revoke family access");
      }

      await loadFamilyProfiles(workspaceId);
      setFamilyActionMessage("Delegated access revoked");
    } catch (error) {
      setFamilyActionMessage(error instanceof Error ? error.message : "Unable to revoke family access");
    }
  }

  async function loadClinicalSummary(id: string, patientId: string, ageYears?: number) {
    try {
      setClinicalSummaryMessage("Loading clinical summary...");
      const query = new URLSearchParams({
        patientId,
        ageYears: ageYears ? String(ageYears) : ""
      });

      const response = await fetch(
        `/api/workspaces/${encodeURIComponent(id)}/clinical-summary?${query.toString()}`
      );
      const body = (await response.json()) as ClinicalSummaryPayload;

      if (!response.ok || !body.ok || !body.summary) {
        throw new Error(body.error || "Unable to load clinical summary");
      }

      setClinicalSummary(body.summary);
      setClinicalSummaryMessage(
        `Clinical risk: ${body.summary.overallRiskLevel.toLowerCase()} · ${body.summary.summary.activeAlerts} alerts`
      );
    } catch (error) {
      setClinicalSummary(null);
      setClinicalSummaryMessage(
        error instanceof Error ? error.message : "Unable to load clinical summary"
      );
    }
  }

  async function loadLifecycleAlerts(
    id: string,
    patientId: string,
    status: ClinicalAlertLifecycleStatus
  ) {
    try {
      setLifecycleAlertsMessage("Loading alerts...");
      const query = new URLSearchParams({
        patientId,
        status
      });

      const response = await fetch(
        `/api/workspaces/${encodeURIComponent(id)}/clinical-alerts?${query.toString()}`
      );
      const body = (await response.json()) as ClinicalAlertsPayload;

      if (!response.ok || !body.ok || !body.alerts) {
        throw new Error(body.error || "Unable to load alerts");
      }

      setLifecycleAlerts(body.alerts);
      setLifecycleAlertsMessage(`${body.alerts.length} ${status} alert${body.alerts.length === 1 ? "" : "s"}`);
      setExpandedAlertTimelineId(null);
      setAlertTimelineMessage("");
    } catch (error) {
      setLifecycleAlerts([]);
      setLifecycleAlertsMessage(error instanceof Error ? error.message : "Unable to load alerts");
    }
  }

  async function loadAlertTimeline(alertId: string, page = timelinePage) {
    if (!workspaceId) {
      return;
    }

    try {
      setLoadingAlertTimelineId(alertId);
      setAlertTimelineMessage("Loading timeline...");

      const query = new URLSearchParams();
      if (timelineActionFilter !== "all") {
        query.set("action", timelineActionFilter);
      }
      if (timelineFromDate) {
        query.set("from", new Date(`${timelineFromDate}T00:00:00.000Z`).toISOString());
      }
      if (timelineToDate) {
        query.set("to", new Date(`${timelineToDate}T23:59:59.999Z`).toISOString());
      }
      query.set("page", String(page));
      query.set("pageSize", String(timelinePageSize));

      const response = await fetch(
        `/api/workspaces/${encodeURIComponent(workspaceId)}/clinical-alerts/${encodeURIComponent(alertId)}/events?${query.toString()}`
      );
      const body = (await response.json()) as ClinicalAlertEventsPayload;

      if (!response.ok || !body.ok || !body.events) {
        throw new Error(body.error || "Unable to load alert timeline");
      }

      setAlertTimelineById((previous) => ({
        ...previous,
        [alertId]: body.events ?? []
      }));
      setTimelinePagination(body.pagination ?? null);
      setAlertTimelineMessage(
        `${body.events.length} timeline event${body.events.length === 1 ? "" : "s"} (page ${body.pagination?.page ?? page})`
      );
    } catch (error) {
      setAlertTimelineMessage(
        error instanceof Error ? error.message : "Unable to load alert timeline"
      );
    } finally {
      setLoadingAlertTimelineId(null);
    }
  }

  async function toggleAlertTimeline(alertId: string) {
    if (expandedAlertTimelineId === alertId) {
      setExpandedAlertTimelineId(null);
      setTimelinePagination(null);
      return;
    }

    setExpandedAlertTimelineId(alertId);
    setTimelinePage(1);
    setTimelineExportMessage("");
  }

  async function copyExpandedTimeline() {
    if (!expandedAlertTimelineId) {
      return;
    }

    const events = alertTimelineById[expandedAlertTimelineId] ?? [];
    if (events.length === 0) {
      setTimelineExportMessage("No timeline events to copy");
      return;
    }

    const lines = events.map((event) => {
      const parts = [
        new Date(event.createdAt).toLocaleString(),
        event.action,
        event.actorLabel ? `by ${event.actorLabel}` : "",
        event.note || ""
      ].filter(Boolean);
      return `- ${parts.join(" · ")}`;
    });

    const content = [
      `Alert timeline (${expandedAlertTimelineId})`,
      `Filter action: ${timelineActionFilter}`,
      `Filter from: ${timelineFromDate || "n/a"}`,
      `Filter to: ${timelineToDate || "n/a"}`,
      `Page: ${timelinePagination?.page ?? timelinePage}`,
      `Page size: ${timelinePagination?.pageSize ?? timelinePageSize}`,
      "",
      ...lines
    ].join("\n");

    await navigator.clipboard.writeText(content);
    setTimelineExportMessage("Timeline copied");
  }

  function downloadExpandedTimelineJson() {
    if (!expandedAlertTimelineId) {
      return;
    }

    const events = alertTimelineById[expandedAlertTimelineId] ?? [];
    const payload = {
      alertId: expandedAlertTimelineId,
      filters: {
        action: timelineActionFilter,
        from: timelineFromDate || null,
        to: timelineToDate || null
      },
      pagination: timelinePagination,
      events
    };

    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: "application/json"
    });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `alert-timeline-${expandedAlertTimelineId}.json`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
    setTimelineExportMessage("Timeline downloaded");
  }

  function downloadExpandedTimelineCsv() {
    if (!expandedAlertTimelineId) {
      return;
    }

    const events = alertTimelineById[expandedAlertTimelineId] ?? [];
    if (events.length === 0) {
      setTimelineExportMessage("No timeline events to export");
      return;
    }

    const header = ["event_id", "action", "created_at", "actor", "note"];
    const rows = events.map((event) => [
      event.id,
      event.action,
      new Date(event.createdAt).toISOString(),
      event.actorLabel || "",
      event.note || ""
    ]);

    const csv = [header, ...rows]
      .map((row) => row.map((cell) => escapeCsvCell(String(cell))).join(","))
      .join("\n");

    const blob = new Blob([csv], {
      type: "text/csv;charset=utf-8"
    });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `alert-timeline-${expandedAlertTimelineId}-page-${timelinePagination?.page ?? timelinePage}.csv`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
    setTimelineExportMessage("CSV downloaded");
  }

  useEffect(() => {
    if (!expandedAlertTimelineId) {
      return;
    }

    setTimelinePage(1);
  }, [expandedAlertTimelineId, timelineActionFilter, timelineFromDate, timelineToDate, timelinePageSize]);

  useEffect(() => {
    if (!expandedAlertTimelineId) {
      return;
    }

    void loadAlertTimeline(expandedAlertTimelineId, timelinePage);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [expandedAlertTimelineId, timelineActionFilter, timelineFromDate, timelineToDate, timelinePage, timelinePageSize]);

  async function mutateClinicalAlert(alertId: string, action: "acknowledge" | "resolve") {
    if (!workspaceId) {
      return;
    }

    try {
      setWorkingAlertId(alertId);
      setAlertActionMessage(action === "acknowledge" ? "Acknowledging alert..." : "Resolving alert...");

      const response = await fetch(
        `/api/workspaces/${encodeURIComponent(workspaceId)}/clinical-alerts/${encodeURIComponent(alertId)}`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({ action })
        }
      );

      const body = (await response.json()) as { ok: boolean; error?: string };
      if (!response.ok || !body.ok) {
        throw new Error(body.error || "Unable to update alert");
      }

      if (state.patient) {
        await loadClinicalSummary(workspaceId, state.patient.fullName, state.patient.age);
        await loadLifecycleAlerts(workspaceId, state.patient.fullName, alertStatusTab);
        await loadAlertTimeline(alertId);
      }

      setAlertActionMessage(action === "acknowledge" ? "Alert acknowledged" : "Alert resolved");
    } catch (error) {
      setAlertActionMessage(error instanceof Error ? error.message : "Unable to update alert");
    } finally {
      setWorkingAlertId(null);
    }
  }

  async function resolveClinicalAlert(alertId: string) {
    await mutateClinicalAlert(alertId, "resolve");
  }

  async function acknowledgeClinicalAlert(alertId: string) {
    await mutateClinicalAlert(alertId, "acknowledge");
  }

  async function uploadDocument(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!workspaceId || !pendingFile) {
      return;
    }

    setDocumentsMessage("Uploading document...");

    try {
      const formData = new FormData();
      formData.append("file", pendingFile);

      const response = await fetch(`/api/workspaces/${encodeURIComponent(workspaceId)}/documents`, {
        method: "POST",
        body: formData
      });

      const body = (await response.json()) as WorkspaceDocumentsPayload;
      if (!response.ok || !body.ok) {
        throw new Error(body.error || "Unable to upload document");
      }

      setPendingFile(null);
      await loadDocuments(workspaceId);
      setDocumentsMessage("Document uploaded");
    } catch (error) {
      setDocumentsMessage(error instanceof Error ? error.message : "Unable to upload document");
    }
  }

  async function extractDocument(documentId: string) {
    if (!workspaceId) {
      return;
    }

    setExtractingDocumentId(documentId);
    setDocumentsMessage("Extracting structured data...");

    try {
      const response = await fetch(
        `/api/workspaces/${encodeURIComponent(workspaceId)}/documents/${encodeURIComponent(documentId)}/extract`,
        {
          method: "POST"
        }
      );

      const body = (await response.json()) as WorkspaceDocumentsPayload;
      if (!response.ok || !body.ok) {
        throw new Error(body.error || "Unable to extract document");
      }

      await loadDocuments(workspaceId);
      if (state.patient) {
        await loadClinicalSummary(workspaceId, state.patient.fullName, state.patient.age);
      }
      setDocumentsMessage("Extraction complete");
    } catch (error) {
      setDocumentsMessage(error instanceof Error ? error.message : "Unable to extract document");
    } finally {
      setExtractingDocumentId(null);
    }
  }

  async function ingestWhatsappForward(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!workspaceId || !whatsappForwardedText.trim()) {
      return;
    }

    setDocumentsMessage("Ingesting WhatsApp forward...");

    try {
      const response = await fetch(
        `/api/workspaces/${encodeURIComponent(workspaceId)}/documents/channels/whatsapp`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            forwardedText: whatsappForwardedText.trim(),
            senderLabel: whatsappSenderLabel.trim() || undefined
          })
        }
      );

      const body = (await response.json()) as WorkspaceDocumentsPayload;
      if (!response.ok || !body.ok) {
        throw new Error(body.error || "Unable to ingest WhatsApp forward");
      }

      setWhatsappForwardedText("");
      setWhatsappSenderLabel("");
      await loadDocuments(workspaceId);
      if (state.patient) {
        await loadClinicalSummary(workspaceId, state.patient.fullName, state.patient.age);
      }
      setDocumentsMessage("WhatsApp forward ingested");
    } catch (error) {
      setDocumentsMessage(error instanceof Error ? error.message : "Unable to ingest WhatsApp forward");
    }
  }

  async function ingestAudioTranscript(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!workspaceId || !audioTranscriptText.trim()) {
      return;
    }

    setDocumentsMessage("Ingesting audio transcript...");

    try {
      const durationSeconds = Number(audioDurationSeconds);
      const response = await fetch(
        `/api/workspaces/${encodeURIComponent(workspaceId)}/documents/channels/audio`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            transcript: audioTranscriptText.trim(),
            language: audioLanguage.trim() || undefined,
            durationSeconds: Number.isFinite(durationSeconds) && durationSeconds > 0 ? durationSeconds : undefined
          })
        }
      );

      const body = (await response.json()) as WorkspaceDocumentsPayload;
      if (!response.ok || !body.ok) {
        throw new Error(body.error || "Unable to ingest audio transcript");
      }

      setAudioTranscriptText("");
      setAudioDurationSeconds("");
      await loadDocuments(workspaceId);
      if (state.patient) {
        await loadClinicalSummary(workspaceId, state.patient.fullName, state.patient.age);
      }
      setDocumentsMessage("Audio transcript ingested");
    } catch (error) {
      setDocumentsMessage(error instanceof Error ? error.message : "Unable to ingest audio transcript");
    }
  }

  async function createInvite(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!workspaceId || !inviteEmailInput.trim()) {
      return;
    }

    setInvitesMessage("Creating invite...");

    try {
      const response = await fetch(`/api/workspaces/${encodeURIComponent(workspaceId)}/invites`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          email: inviteEmailInput.trim(),
          role: inviteRoleInput
        })
      });

      const body = (await response.json()) as WorkspaceInvitesPayload;
      if (!response.ok || !body.ok || !body.invite) {
        throw new Error(body.error || "Unable to create invite");
      }

      setInviteEmailInput("");
      await loadInvites(workspaceId);
      await loadMembers(workspaceId);
      setInvitesMessage("Invite created");
    } catch (error) {
      setInvitesMessage(error instanceof Error ? error.message : "Unable to create invite");
    }
  }

  async function acceptInvite(token: string) {
    setInvitesMessage("Accepting invite...");

    try {
      const response = await fetch("/api/workspace-invites/accept", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ token })
      });

      const body = (await response.json()) as WorkspaceInvitesPayload;
      if (!response.ok || !body.ok || !body.workspaceId) {
        throw new Error(body.error || "Unable to accept invite");
      }

      await loadWorkspace(body.workspaceId);
      setInvitesMessage("Invite accepted. Workspace loaded.");
    } catch (error) {
      setInvitesMessage(error instanceof Error ? error.message : "Unable to accept invite");
    }
  }

  async function copyInviteLink(token: string, workspaceForInvite: string) {
    const url = `${window.location.origin}${pathname}?ws=${encodeURIComponent(workspaceForInvite)}&invite=${encodeURIComponent(token)}`;
    await navigator.clipboard.writeText(url);
    setInvitesMessage("Invite link copied");
  }

  async function manageInvite(inviteId: string, action: "revoke" | "resend") {
    if (!workspaceId) {
      return;
    }

    setInvitesMessage(action === "revoke" ? "Revoking invite..." : "Resending invite...");

    try {
      const response = await fetch(
        `/api/workspaces/${encodeURIComponent(workspaceId)}/invites/${encodeURIComponent(inviteId)}`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({ action })
        }
      );

      const body = (await response.json()) as WorkspaceInvitesPayload;
      if (!response.ok || !body.ok) {
        throw new Error(body.error || "Unable to update invite");
      }

      await loadInvites(workspaceId);
      setInvitesMessage(action === "revoke" ? "Invite revoked" : "Invite resent");
    } catch (error) {
      setInvitesMessage(error instanceof Error ? error.message : "Unable to update invite");
    }
  }

  async function addMember(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!workspaceId || !memberUserIdInput.trim()) {
      return;
    }

    setMembersMessage("Adding member...");

    try {
      const response = await fetch(`/api/workspaces/${encodeURIComponent(workspaceId)}/members`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          userId: memberUserIdInput.trim(),
          role: memberRoleInput
        })
      });

      const body = (await response.json()) as WorkspaceMembersPayload;
      if (!response.ok || !body.ok) {
        throw new Error(body.error || "Unable to add member");
      }

      setMemberUserIdInput("");
      await loadMembers(workspaceId);
      setMembersMessage("Member added");
    } catch (error) {
      setMembersMessage(error instanceof Error ? error.message : "Unable to add member");
    }
  }

  async function updateMemberRole(userId: string, role: "EDITOR" | "VIEWER") {
    if (!workspaceId) {
      return;
    }

    setMembersMessage("Updating member role...");
    try {
      const response = await fetch(
        `/api/workspaces/${encodeURIComponent(workspaceId)}/members/${encodeURIComponent(userId)}`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({ role })
        }
      );

      const body = (await response.json()) as WorkspaceMembersPayload;
      if (!response.ok || !body.ok) {
        throw new Error(body.error || "Unable to update member");
      }

      await loadMembers(workspaceId);
      setMembersMessage("Member role updated");
    } catch (error) {
      setMembersMessage(error instanceof Error ? error.message : "Unable to update member");
    }
  }

  async function removeMember(userId: string) {
    if (!workspaceId) {
      return;
    }

    setMembersMessage("Removing member...");
    try {
      const response = await fetch(
        `/api/workspaces/${encodeURIComponent(workspaceId)}/members/${encodeURIComponent(userId)}`,
        {
          method: "DELETE"
        }
      );

      const body = (await response.json()) as WorkspaceMembersPayload;
      if (!response.ok || !body.ok) {
        throw new Error(body.error || "Unable to remove member");
      }

      await loadMembers(workspaceId);
      setMembersMessage("Member removed");
    } catch (error) {
      setMembersMessage(error instanceof Error ? error.message : "Unable to remove member");
    }
  }

  async function copyWorkspaceLink() {
    if (!workspaceId) {
      return;
    }
    const url = `${window.location.origin}${pathname}?ws=${encodeURIComponent(workspaceId)}`;
    await navigator.clipboard.writeText(url);
    setWorkspaceCopied(true);
    window.setTimeout(() => setWorkspaceCopied(false), 1500);
  }

  function exportWorkspaceJson() {
    const content = JSON.stringify(state, null, 2);
    const blob = new Blob([content], { type: "application/json" });
    const href = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = href;
    anchor.download = `anirul-workspace-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(href);
  }

  function savePatient(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const age = Number(patientDraft.age);
    if (!patientDraft.fullName.trim() || !Number.isFinite(age) || age <= 0) {
      return;
    }

    const nextPatient = {
      fullName: patientDraft.fullName.trim(),
      age,
      conditions: patientDraft.conditions
        .split(",")
        .map((entry) => entry.trim())
        .filter(Boolean),
      primaryDoctor: patientDraft.primaryDoctor.trim() || "Not set"
    };

    setState((previous) => updateProductState(previous, { patient: nextPatient }));
    markDirty();
    setPatientDraft(initialPatientDraft);
    if (workspaceId) {
      void loadClinicalSummary(workspaceId, nextPatient.fullName, nextPatient.age);
    }
  }

  function addRecord(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!recordDraft.title.trim() || !recordDraft.summary.trim() || !recordDraft.source.trim()) {
      return;
    }

    const record: TimelineRecord = {
      id: typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}`,
      createdAt: new Date().toISOString(),
      date: recordDraft.date,
      type: recordDraft.type,
      title: recordDraft.title.trim(),
      summary: recordDraft.summary.trim(),
      source: recordDraft.source.trim(),
      labValue: toOptionalNumber(recordDraft.labValue),
      unit: recordDraft.unit.trim() || undefined
    };

    setState((previous) =>
      updateProductState(previous, {
        records: [record, ...previous.records]
      })
    );
    markDirty();
    setRecordDraft(initialRecordDraft);
    if (workspaceId && state.patient) {
      void loadClinicalSummary(workspaceId, state.patient.fullName, state.patient.age);
    }
  }

  function loadDemo() {
    setState(DEMO_PRODUCT_STATE);
    markDirty();
  }

  function resetWorkspace() {
    setState(EMPTY_PRODUCT_STATE);
    setPatientDraft(initialPatientDraft);
    setRecordDraft(initialRecordDraft);
    markDirty();
  }

  async function copyBrief() {
    if (!brief) {
      return;
    }

    const content = [
      `Doctor Brief — ${new Date(brief.generatedAt).toLocaleString()}`,
      `Patient: ${brief.patientLine}`,
      `Continuity score: ${brief.continuityScore}/100`,
      "",
      "Recent highlights:",
      ...brief.recentHighlights.map((line) => `- ${line}`),
      "",
      "Risk flags:",
      ...brief.riskFlags.map((line) => `- ${line}`),
      "",
      "Suggested actions:",
      ...brief.suggestedActions.map((line) => `- ${line}`)
    ].join("\n");

    await navigator.clipboard.writeText(content);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1500);
  }

  return (
    <section className="section product-shell">
      <div className="section-head">
        <p className="label">Product Workspace</p>
        <h2>Capture context, build timeline, generate clinician-ready brief</h2>
        <p>
          Workspace can run local-first, or be shared with judges/clinics through a workspace ID.
        </p>
      </div>

      <div className="workspace-sync-bar">
        <label>
          Workspace ID
          <input
            value={workspaceInput}
            onChange={(event) => setWorkspaceInput(event.target.value)}
            placeholder="ws_xxxxxxxxxxxxx"
          />
        </label>
        <div className="workspace-sync-actions">
          <button type="button" className="btn ghost" onClick={() => loadWorkspace(workspaceInput)}>
            Load workspace
          </button>
          <button type="button" className="btn ghost" onClick={createSharedWorkspace}>
            Create shared workspace
          </button>
          <button type="button" className="btn ghost" onClick={syncWorkspace} disabled={!workspaceId}>
            Sync now
          </button>
          <button type="button" className="btn ghost" onClick={copyWorkspaceLink} disabled={!workspaceId}>
            {workspaceCopied ? "Link copied" : "Copy share link"}
          </button>
        </div>
        <p className={`sync-indicator ${syncState}`}>{syncMessage}</p>
      </div>

      <article className="card">
        <h3>Workspace sharing</h3>
        {workspaceId ? (
          <>
            <form className="contact-form" onSubmit={createInvite}>
              <div className="field-grid">
                <label>
                  Invite by email
                  <input
                    type="email"
                    value={inviteEmailInput}
                    onChange={(event) => setInviteEmailInput(event.target.value)}
                    placeholder="doctor@clinic.com"
                    required
                  />
                </label>
                <label>
                  Invite role
                  <select
                    value={inviteRoleInput}
                    onChange={(event) =>
                      setInviteRoleInput(event.target.value as "EDITOR" | "VIEWER")
                    }
                  >
                    <option value="VIEWER">Viewer</option>
                    <option value="EDITOR">Editor</option>
                  </select>
                </label>
              </div>

              <button type="submit">Send invite</button>
            </form>

            {invitesMessage ? <p className="muted-copy">{invitesMessage}</p> : null}

            <div className="record-list">
              {invites.map((invite) => (
                <div className="record-item" key={invite.id}>
                  <p className="record-title">{invite.email}</p>
                  <p className="record-meta">Role: {invite.role} · Status: {invite.status}</p>
                  <p className="record-meta">Expires: {new Date(invite.expiresAt).toLocaleString()}</p>
                  <div className="workspace-sync-actions">
                    <button
                      type="button"
                      className="btn ghost"
                      onClick={() => copyInviteLink(invite.token, invite.workspaceId)}
                    >
                      Copy invite link
                    </button>
                    <button
                      type="button"
                      className="btn ghost"
                      onClick={() => manageInvite(invite.id, "resend")}
                    >
                      Resend
                    </button>
                    {invite.status === "PENDING" ? (
                      <button
                        type="button"
                        className="btn ghost"
                        onClick={() => manageInvite(invite.id, "revoke")}
                      >
                        Revoke
                      </button>
                    ) : null}
                  </div>
                </div>
              ))}
            </div>

            <form className="contact-form" onSubmit={addMember}>
              <div className="field-grid">
                <label>
                  Member user ID (Supabase UID)
                  <input
                    value={memberUserIdInput}
                    onChange={(event) => setMemberUserIdInput(event.target.value)}
                    placeholder="00000000-0000-0000-0000-000000000000"
                    required
                  />
                </label>
                <label>
                  Role
                  <select
                    value={memberRoleInput}
                    onChange={(event) =>
                      setMemberRoleInput(event.target.value as "EDITOR" | "VIEWER")
                    }
                  >
                    <option value="VIEWER">Viewer</option>
                    <option value="EDITOR">Editor</option>
                  </select>
                </label>
              </div>

              <button type="submit">Add member</button>
            </form>

            {membersMessage ? <p className="muted-copy">{membersMessage}</p> : null}

            <div className="record-list">
              {members.map((member) => (
                <div className="record-item" key={member.userId}>
                  <p className="record-title">{member.fullName || member.email || member.userId}</p>
                  <p className="record-meta">Role: {member.role}</p>
                  <p className="record-meta">User ID: {member.userId}</p>
                  {member.role !== "OWNER" ? (
                    <div className="workspace-sync-actions">
                      <button
                        type="button"
                        className="btn ghost"
                        onClick={() => updateMemberRole(member.userId, "EDITOR")}
                        disabled={member.role === "EDITOR"}
                      >
                        Set editor
                      </button>
                      <button
                        type="button"
                        className="btn ghost"
                        onClick={() => updateMemberRole(member.userId, "VIEWER")}
                        disabled={member.role === "VIEWER"}
                      >
                        Set viewer
                      </button>
                      <button
                        type="button"
                        className="btn ghost"
                        onClick={() => removeMember(member.userId)}
                      >
                        Remove
                      </button>
                    </div>
                  ) : null}
                </div>
              ))}
            </div>
          </>
        ) : (
          <p className="muted-copy">Create or load a workspace to manage members.</p>
        )}
      </article>

      <article className="card">
        <h3>Document ingestion v1</h3>
        {workspaceId ? (
          <>
            <form className="contact-form" onSubmit={uploadDocument}>
              <label>
                Upload report (PDF/text/image)
                <input
                  type="file"
                  onChange={(event) => setPendingFile(event.target.files?.[0] ?? null)}
                  required
                />
              </label>

              <button type="submit" disabled={!pendingFile}>
                Upload document
              </button>
            </form>

            <form className="contact-form" onSubmit={ingestWhatsappForward}>
              <div className="field-grid">
                <label>
                  WhatsApp sender label (optional)
                  <input
                    value={whatsappSenderLabel}
                    onChange={(event) => setWhatsappSenderLabel(event.target.value)}
                    placeholder="Family group"
                  />
                </label>
              </div>
              <label>
                WhatsApp forwarded clinical text
                <textarea
                  rows={4}
                  value={whatsappForwardedText}
                  onChange={(event) => setWhatsappForwardedText(event.target.value)}
                  placeholder="Paste forwarded lab/result summary text"
                  required
                />
              </label>
              <button type="submit" disabled={!whatsappForwardedText.trim()}>
                Ingest WhatsApp forward
              </button>
            </form>

            <form className="contact-form" onSubmit={ingestAudioTranscript}>
              <div className="field-grid">
                <label>
                  Transcript language
                  <input
                    value={audioLanguage}
                    onChange={(event) => setAudioLanguage(event.target.value)}
                    placeholder="hi-IN"
                  />
                </label>
                <label>
                  Duration (seconds, optional)
                  <input
                    type="number"
                    value={audioDurationSeconds}
                    onChange={(event) => setAudioDurationSeconds(event.target.value)}
                    min={1}
                    step={1}
                    placeholder="75"
                  />
                </label>
              </div>
              <label>
                Audio transcript text
                <textarea
                  rows={4}
                  value={audioTranscriptText}
                  onChange={(event) => setAudioTranscriptText(event.target.value)}
                  placeholder="Paste transcript from voice note"
                  required
                />
              </label>
              <button type="submit" disabled={!audioTranscriptText.trim()}>
                Ingest audio transcript
              </button>
            </form>

            {documentsMessage ? <p className="muted-copy">{documentsMessage}</p> : null}

            <div className="record-list">
              {documents.map((document) => (
                <div className="record-item" key={document.id}>
                  <p className="record-title">{document.originalName}</p>
                  <p className="record-meta">
                    Status: {document.status} · Size: {Math.ceil(document.sizeBytes / 1024)} KB
                  </p>
                  <p className="record-meta">Source: {document.sourceChannel}</p>
                  {document.sourceContext ? (
                    <p className="record-meta">Source context: {document.sourceContext}</p>
                  ) : null}
                  {document.extractionNote ? (
                    <p className="record-meta">Note: {document.extractionNote}</p>
                  ) : null}
                  {document.extractedTextPreview ? (
                    <p className="record-summary">{document.extractedTextPreview}</p>
                  ) : null}
                  <div className="workspace-sync-actions">
                    <button
                      type="button"
                      className="btn ghost"
                      onClick={() => extractDocument(document.id)}
                      disabled={extractingDocumentId === document.id}
                    >
                      {extractingDocumentId === document.id ? "Extracting..." : "Run extraction"}
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <article className="card">
              <h3>Consent management v1</h3>
              {workspaceId ? (
                <>
                  <form className="contact-form" onSubmit={createConsent}>
                    <div className="field-grid">
                      <label>
                        Recipient name
                        <input
                          value={consentSubjectName}
                          onChange={(event) => setConsentSubjectName(event.target.value)}
                          placeholder="Dr. Mehta"
                          required
                        />
                      </label>
                      <label>
                        Recipient contact
                        <input
                          value={consentSubjectContact}
                          onChange={(event) => setConsentSubjectContact(event.target.value)}
                          placeholder="doctor@clinic.com"
                          required
                        />
                      </label>
                    </div>

                    <div className="field-grid">
                      <label>
                        Purpose
                        <input
                          value={consentPurpose}
                          onChange={(event) => setConsentPurpose(event.target.value)}
                          placeholder="Cardiology consult preparation"
                          required
                        />
                      </label>
                      <label>
                        Expires on
                        <input
                          type="date"
                          value={consentExpiresOn}
                          onChange={(event) => setConsentExpiresOn(event.target.value)}
                          required
                        />
                      </label>
                    </div>

                    <div className="consent-scope-grid">
                      {(["DOCTOR_BRIEF", "FULL_TIMELINE", "LAB_TRENDS", "ALERTS", "DOCUMENTS"] as ConsentScope[]).map(
                        (scope) => (
                          <label key={scope} className="consent-scope-item">
                            <input
                              type="checkbox"
                              checked={consentScopes.includes(scope)}
                              onChange={() => toggleConsentScope(scope)}
                            />
                            <span>{scope}</span>
                          </label>
                        )
                      )}
                    </div>

                    <button type="submit">Create consent</button>
                  </form>

                  <div className="workspace-sync-bar">
                    <label>
                      Filter status
                      <select
                        value={consentStatusFilter}
                        onChange={(event) =>
                          setConsentStatusFilter(
                            event.target.value as "ACTIVE" | "REVOKED" | "EXPIRED" | "all"
                          )
                        }
                      >
                        <option value="all">All</option>
                        <option value="ACTIVE">Active</option>
                        <option value="REVOKED">Revoked</option>
                        <option value="EXPIRED">Expired</option>
                      </select>
                    </label>
                  </div>

                  {consentsMessage ? <p className="muted-copy">{consentsMessage}</p> : null}
                  {consentActionMessage ? <p className="muted-copy">{consentActionMessage}</p> : null}

                  <div className="record-list">
                    {consents.map((consent) => (
                      <div className="record-item" key={consent.id}>
                        <p className="record-title">{consent.subjectName}</p>
                        <p className="record-meta">Contact: {consent.subjectContact}</p>
                        <p className="record-meta">Purpose: {consent.purpose}</p>
                        <p className="record-meta">
                          Scopes: {consent.scopes.join(", ")} · Status: {consent.status}
                        </p>
                        <p className="record-meta">Expires: {new Date(consent.expiresAt).toLocaleString()}</p>
                        {consent.revokedAt ? (
                          <p className="record-meta">Revoked: {new Date(consent.revokedAt).toLocaleString()}</p>
                        ) : null}
                        {consent.status === "ACTIVE" ? (
                          <div className="workspace-sync-actions">
                            <button
                              type="button"
                              className="btn ghost"
                              onClick={() => revokeConsent(consent.id)}
                              disabled={workingConsentId === consent.id}
                            >
                              {workingConsentId === consent.id ? "Revoking..." : "Revoke"}
                            </button>
                          </div>
                        ) : null}
                      </div>
                    ))}
                  </div>

                  <p className="brief-heading">Consent events</p>
                  {consentEvents.length > 0 ? (
                    <ul className="alert-timeline-list">
                      {consentEvents.map((event) => (
                        <li key={event.id}>
                          <span className="alert-timeline-action">{event.action.toLowerCase()}</span>
                          <span>
                            {new Date(event.createdAt).toLocaleString()}
                            {event.actorLabel ? ` by ${event.actorLabel}` : ""}
                          </span>
                          {event.note ? <span>{event.note}</span> : null}
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="muted-copy">No consent events yet.</p>
                  )}
                </>
              ) : (
                <p className="muted-copy">Create or load a workspace to manage consent.</p>
              )}
            </article>
          </>
        ) : (
          <p className="muted-copy">Create or load a workspace to ingest reports.</p>
        )}
      </article>

      <article className="card">
        <h3>Care plan reminders v1</h3>
        {workspaceId ? (
          <>
            <form className="contact-form" onSubmit={createCareTask}>
              <div className="field-grid">
                <label>
                  Task title
                  <input
                    value={careTaskTitle}
                    onChange={(event) => setCareTaskTitle(event.target.value)}
                    placeholder="Repeat HbA1c test"
                    required
                  />
                </label>
                <label>
                  Due date
                  <input
                    type="date"
                    value={careTaskDueOn}
                    onChange={(event) => setCareTaskDueOn(event.target.value)}
                  />
                </label>
              </div>

              <div className="field-grid">
                <label>
                  Priority
                  <select
                    value={careTaskPriority}
                    onChange={(event) =>
                      setCareTaskPriority(event.target.value as "LOW" | "MODERATE" | "HIGH")
                    }
                  >
                    <option value="LOW">Low</option>
                    <option value="MODERATE">Moderate</option>
                    <option value="HIGH">High</option>
                  </select>
                </label>
                <label>
                  Source
                  <select
                    value={careTaskSource}
                    onChange={(event) =>
                      setCareTaskSource(
                        event.target.value as "MANUAL" | "ALERT_FOLLOWUP" | "RISK_FOLLOWUP"
                      )
                    }
                  >
                    <option value="MANUAL">Manual</option>
                    <option value="ALERT_FOLLOWUP">Alert follow-up</option>
                    <option value="RISK_FOLLOWUP">Risk follow-up</option>
                  </select>
                </label>
              </div>

              <label>
                Description
                <input
                  value={careTaskDescription}
                  onChange={(event) => setCareTaskDescription(event.target.value)}
                  placeholder="Schedule doctor follow-up after receiving result"
                />
              </label>

              <button type="submit">Create care task</button>
            </form>

            <div className="workspace-sync-bar">
              <label>
                Filter status
                <select
                  value={careTaskStatusFilter}
                  onChange={(event) =>
                    setCareTaskStatusFilter(
                      event.target.value as "PENDING" | "COMPLETED" | "SKIPPED" | "all"
                    )
                  }
                >
                  <option value="all">All</option>
                  <option value="PENDING">Pending</option>
                  <option value="COMPLETED">Completed</option>
                  <option value="SKIPPED">Skipped</option>
                </select>
              </label>
            </div>

            {careTasksMessage ? <p className="muted-copy">{careTasksMessage}</p> : null}
            {careTaskActionMessage ? <p className="muted-copy">{careTaskActionMessage}</p> : null}

            <div className="record-list">
              {careTasks.map((task) => (
                <div className="record-item" key={task.id}>
                  <p className="record-title">{task.title}</p>
                  <p className="record-meta">
                    Status: {task.status} · Priority: {task.priority} · Source: {task.source}
                  </p>
                  {task.patientId ? <p className="record-meta">Patient: {task.patientId}</p> : null}
                  {task.description ? <p className="record-summary">{task.description}</p> : null}
                  {task.dueAt ? <p className="record-meta">Due: {new Date(task.dueAt).toLocaleString()}</p> : null}
                  <div className="workspace-sync-actions">
                    {task.status === "PENDING" ? (
                      <>
                        <button
                          type="button"
                          className="btn ghost"
                          onClick={() => updateCareTask(task.id, "complete")}
                          disabled={workingCareTaskId === task.id}
                        >
                          {workingCareTaskId === task.id ? "Working..." : "Complete"}
                        </button>
                        <button
                          type="button"
                          className="btn ghost"
                          onClick={() => updateCareTask(task.id, "skip")}
                          disabled={workingCareTaskId === task.id}
                        >
                          {workingCareTaskId === task.id ? "Working..." : "Skip"}
                        </button>
                      </>
                    ) : (
                      <button
                        type="button"
                        className="btn ghost"
                        onClick={() => updateCareTask(task.id, "reopen")}
                        disabled={workingCareTaskId === task.id}
                      >
                        {workingCareTaskId === task.id ? "Working..." : "Reopen"}
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <p className="brief-heading">Care task events</p>
            {careTaskEvents.length > 0 ? (
              <ul className="alert-timeline-list">
                {careTaskEvents.map((event) => (
                  <li key={event.id}>
                    <span className="alert-timeline-action">{event.action.toLowerCase()}</span>
                    <span>
                      {new Date(event.createdAt).toLocaleString()}
                      {event.actorLabel ? ` by ${event.actorLabel}` : ""}
                    </span>
                    {event.note ? <span>{event.note}</span> : null}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="muted-copy">No care task events yet.</p>
            )}
          </>
        ) : (
          <p className="muted-copy">Create or load a workspace to manage care tasks.</p>
        )}
      </article>

      <article className="card">
        <h3>Duplicate test prevention v1</h3>
        {workspaceId ? (
          <>
            <form className="contact-form" onSubmit={runDuplicateCheck}>
              <div className="field-grid">
                <label>
                  Test name
                  <input
                    value={duplicateLabName}
                    onChange={(event) => setDuplicateLabName(event.target.value)}
                    placeholder="HbA1c"
                    required
                  />
                </label>
                <label>
                  Lookback days
                  <input
                    type="number"
                    min={1}
                    max={365}
                    value={duplicateLookbackDays}
                    onChange={(event) => setDuplicateLookbackDays(event.target.value)}
                  />
                </label>
              </div>
              <button type="submit">Run duplicate check</button>
            </form>

            {latestDuplicateCheck ? (
              <div className="record-item">
                <p className="record-title">
                  {latestDuplicateCheck.isDuplicate
                    ? "Potential duplicate detected"
                    : "No duplicate detected"}
                </p>
                <p className="record-meta">
                  Requested test: {latestDuplicateCheck.requestedLabName} · Window: {latestDuplicateCheck.lookbackDays} days
                </p>
                <p className="record-summary">{latestDuplicateCheck.recommendation}</p>
                <p className="record-meta">{latestDuplicateCheck.rationale}</p>
                {latestDuplicateCheck.recentTestDate ? (
                  <p className="record-meta">
                    Recent result: {new Date(latestDuplicateCheck.recentTestDate).toLocaleString()}
                    {latestDuplicateCheck.recentTestValue !== null
                      ? ` · value ${latestDuplicateCheck.recentTestValue}`
                      : ""}
                    {latestDuplicateCheck.recentTestStatus
                      ? ` · status ${latestDuplicateCheck.recentTestStatus}`
                      : ""}
                  </p>
                ) : null}
              </div>
            ) : null}

            {duplicateCheckMessage ? <p className="muted-copy">{duplicateCheckMessage}</p> : null}

            <div className="record-list">
              {duplicateChecks.map((check) => (
                <div className="record-item" key={check.id}>
                  <p className="record-title">{check.requestedLabName}</p>
                  <p className="record-meta">
                    {new Date(check.requestedAt).toLocaleString()} · {check.isDuplicate ? "duplicate" : "clear"}
                  </p>
                  <p className="record-summary">{check.recommendation}</p>
                </div>
              ))}
            </div>
          </>
        ) : (
          <p className="muted-copy">Create or load a workspace to run duplicate test checks.</p>
        )}
      </article>

      <article className="card">
        <h3>Family accounts + delegation v1</h3>
        {workspaceId ? (
          <>
            <form className="contact-form" onSubmit={createFamilyProfile}>
              <div className="field-grid">
                <label>
                  Family member name
                  <input
                    value={familyFullName}
                    onChange={(event) => setFamilyFullName(event.target.value)}
                    placeholder="Meera Sharma"
                    required
                  />
                </label>
                <label>
                  Relation
                  <select
                    value={familyRelation}
                    onChange={(event) =>
                      setFamilyRelation(
                        event.target.value as "SELF" | "SPOUSE" | "CHILD" | "PARENT" | "SIBLING" | "OTHER"
                      )
                    }
                  >
                    <option value="SELF">Self</option>
                    <option value="SPOUSE">Spouse</option>
                    <option value="CHILD">Child</option>
                    <option value="PARENT">Parent</option>
                    <option value="SIBLING">Sibling</option>
                    <option value="OTHER">Other</option>
                  </select>
                </label>
              </div>
              <div className="field-grid">
                <label>
                  Age
                  <input
                    type="number"
                    min={0}
                    max={130}
                    value={familyAgeYears}
                    onChange={(event) => setFamilyAgeYears(event.target.value)}
                    placeholder="62"
                  />
                </label>
                <label>
                  Sex
                  <input
                    value={familySex}
                    onChange={(event) => setFamilySex(event.target.value)}
                    placeholder="F"
                  />
                </label>
              </div>
              <label>
                Notes
                <input
                  value={familyNotes}
                  onChange={(event) => setFamilyNotes(event.target.value)}
                  placeholder="Hypertension follow-up managed by daughter"
                />
              </label>
              <button type="submit">Create family profile</button>
            </form>

            <form className="contact-form" onSubmit={grantFamilyAccess}>
              <div className="field-grid">
                <label>
                  Profile
                  <select
                    value={familySelectedProfileId}
                    onChange={(event) => setFamilySelectedProfileId(event.target.value)}
                  >
                    <option value="">Select profile</option>
                    {familyProfiles.map((profile) => (
                      <option key={profile.id} value={profile.id}>
                        {profile.fullName} ({profile.relation.toLowerCase()})
                      </option>
                    ))}
                  </select>
                </label>
                <label>
                  Delegate user ID
                  <input
                    value={familyTargetUserId}
                    onChange={(event) => setFamilyTargetUserId(event.target.value)}
                    placeholder="00000000-0000-0000-0000-000000000000"
                    required
                  />
                </label>
              </div>
              <div className="field-grid">
                <label>
                  Delegate role
                  <select
                    value={familyTargetRole}
                    onChange={(event) =>
                      setFamilyTargetRole(event.target.value as "MANAGER" | "VIEWER")
                    }
                  >
                    <option value="VIEWER">Viewer</option>
                    <option value="MANAGER">Manager</option>
                  </select>
                </label>
              </div>
              <button type="submit">Grant delegated access</button>
            </form>

            {familyMessage ? <p className="muted-copy">{familyMessage}</p> : null}
            {familyActionMessage ? <p className="muted-copy">{familyActionMessage}</p> : null}

            <div className="record-list">
              {familyProfiles.map((profile) => (
                <div className="record-item" key={profile.id}>
                  <p className="record-title">{profile.fullName}</p>
                  <p className="record-meta">
                    Relation: {profile.relation} {profile.ageYears !== null ? `· Age: ${profile.ageYears}` : ""}
                  </p>
                  {profile.notes ? <p className="record-summary">{profile.notes}</p> : null}
                  <p className="record-meta">Delegated access:</p>
                  {profile.accesses.length > 0 ? (
                    <ul className="alert-timeline-list">
                      {profile.accesses.map((access) => (
                        <li key={access.id}>
                          <span>{access.userId}</span>
                          <span>
                            {access.role} · {access.status}
                          </span>
                          {access.status === "ACTIVE" ? (
                            <button
                              type="button"
                              className="btn ghost"
                              onClick={() => revokeFamilyAccess(profile.id, access.userId)}
                            >
                              Revoke
                            </button>
                          ) : null}
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="muted-copy">No delegated users yet.</p>
                  )}
                </div>
              ))}
            </div>

            <p className="brief-heading">Family access events</p>
            {familyAccessEvents.length > 0 ? (
              <ul className="alert-timeline-list">
                {familyAccessEvents.map((event) => (
                  <li key={event.id}>
                    <span className="alert-timeline-action">{event.action.toLowerCase()}</span>
                    <span>
                      {new Date(event.createdAt).toLocaleString()}
                      {event.actorLabel ? ` by ${event.actorLabel}` : ""}
                    </span>
                    {event.note ? <span>{event.note}</span> : null}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="muted-copy">No family access events yet.</p>
            )}
          </>
        ) : (
          <p className="muted-copy">Create or load a workspace to manage family accounts.</p>
        )}
      </article>

      <div className="product-actions">
        <button type="button" className="btn ghost" onClick={loadDemo}>
          Load demo patient
        </button>
        <button type="button" className="btn ghost" onClick={exportWorkspaceJson}>
          Export JSON
        </button>
        <button type="button" className="btn ghost" onClick={resetWorkspace}>
          Reset workspace
        </button>
      </div>

      <div className="product-grid">
        <div className="product-column">
          <article className="card">
            <h3>1) Patient intake</h3>
            <form className="contact-form" onSubmit={savePatient}>
              <div className="field-grid">
                <label>
                  Full name
                  <input
                    value={patientDraft.fullName}
                    onChange={(event) =>
                      setPatientDraft((previous) => ({ ...previous, fullName: event.target.value }))
                    }
                    placeholder="Aarav Mehta"
                    required
                  />
                </label>
                <label>
                  Age
                  <input
                    type="number"
                    min={1}
                    value={patientDraft.age}
                    onChange={(event) =>
                      setPatientDraft((previous) => ({ ...previous, age: event.target.value }))
                    }
                    placeholder="54"
                    required
                  />
                </label>
              </div>

              <div className="field-grid">
                <label>
                  Conditions (comma-separated)
                  <input
                    value={patientDraft.conditions}
                    onChange={(event) =>
                      setPatientDraft((previous) => ({ ...previous, conditions: event.target.value }))
                    }
                    placeholder="Type 2 Diabetes, Hypertension"
                  />
                </label>
                <label>
                  Primary doctor
                  <input
                    value={patientDraft.primaryDoctor}
                    onChange={(event) =>
                      setPatientDraft((previous) => ({ ...previous, primaryDoctor: event.target.value }))
                    }
                    placeholder="Dr. R. Iyer"
                  />
                </label>
              </div>

              <button type="submit">Save patient profile</button>
            </form>
          </article>

          <article className="card">
            <h3>2) Timeline ingestion</h3>
            <form className="contact-form" onSubmit={addRecord}>
              <div className="field-grid">
                <label>
                  Date
                  <input
                    type="date"
                    value={recordDraft.date}
                    onChange={(event) =>
                      setRecordDraft((previous) => ({ ...previous, date: event.target.value }))
                    }
                    required
                  />
                </label>

                <label>
                  Record type
                  <select
                    value={recordDraft.type}
                    onChange={(event) =>
                      setRecordDraft((previous) => ({ ...previous, type: event.target.value as RecordType }))
                    }
                  >
                    <option value="note">Note</option>
                    <option value="visit">Visit</option>
                    <option value="prescription">Prescription</option>
                    <option value="lab">Lab</option>
                  </select>
                </label>
              </div>

              <label>
                Title
                <input
                  value={recordDraft.title}
                  onChange={(event) =>
                    setRecordDraft((previous) => ({ ...previous, title: event.target.value }))
                  }
                  placeholder="HbA1c"
                  required
                />
              </label>

              <label>
                Summary
                <textarea
                  value={recordDraft.summary}
                  onChange={(event) =>
                    setRecordDraft((previous) => ({ ...previous, summary: event.target.value }))
                  }
                  placeholder="Quarterly glycemic marker"
                  required
                />
              </label>

              <div className="field-grid">
                <label>
                  Source
                  <input
                    value={recordDraft.source}
                    onChange={(event) =>
                      setRecordDraft((previous) => ({ ...previous, source: event.target.value }))
                    }
                    placeholder="City Diagnostics"
                    required
                  />
                </label>
                <label>
                  Lab value (optional)
                  <input
                    value={recordDraft.labValue}
                    onChange={(event) =>
                      setRecordDraft((previous) => ({ ...previous, labValue: event.target.value }))
                    }
                    placeholder="8.2"
                  />
                </label>
              </div>

              <button type="submit">Add to timeline</button>
            </form>
          </article>
        </div>

        <div className="product-column">
          <article className="card">
            <h3>Current patient</h3>
            {state.patient ? (
              <div className="product-patient">
                <p>
                  <strong>{state.patient.fullName}</strong> ({state.patient.age})
                </p>
                <p>Conditions: {state.patient.conditions.join(", ") || "Not provided"}</p>
                <p>Primary doctor: {state.patient.primaryDoctor}</p>
              </div>
            ) : (
              <p className="muted-copy">No patient profile saved yet.</p>
            )}
          </article>

          <article className="card clinical-dashboard">
            <div className="clinical-dashboard-head">
              <h3>Clinical dashboard</h3>
              <span className={`risk-pill ${riskLevelTone(clinicalSummary?.overallRiskLevel ?? null)}`}>
                {clinicalSummary?.overallRiskLevel ?? "PENDING"}
              </span>
            </div>

            {clinicalSummary ? (
              <>
                <div className="clinical-metrics-grid">
                  <div className="clinical-metric-item">
                    <p className="clinical-metric-label">Critical values</p>
                    <p className="clinical-metric-value">{clinicalSummary.summary.criticalValues}</p>
                  </div>
                  <div className="clinical-metric-item">
                    <p className="clinical-metric-label">Active alerts</p>
                    <p className="clinical-metric-value">{clinicalSummary.summary.activeAlerts}</p>
                  </div>
                  <div className="clinical-metric-item">
                    <p className="clinical-metric-label">Worsening trends</p>
                    <p className="clinical-metric-value">{clinicalSummary.summary.worseningTrends}</p>
                  </div>
                  <div className="clinical-metric-item">
                    <p className="clinical-metric-label">Clinical patterns</p>
                    <p className="clinical-metric-value">{clinicalSummary.summary.clinicalPatterns}</p>
                  </div>
                </div>

                <p className="brief-heading">Risk categories</p>
                {topRiskScores.length > 0 ? (
                  <div className="clinical-score-list">
                    {topRiskScores.map((score) => (
                      <div className="clinical-score-item" key={`${score.category}-${score.level}`}>
                        <p>
                          <strong>{score.category}</strong> — {Math.round(score.score)}/{score.maxScore}
                        </p>
                        <span className={`risk-pill ${riskLevelTone(score.level)}`}>{score.level}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="muted-copy">No risk categories scored yet.</p>
                )}

                <p className="brief-heading">Active alerts</p>
                <div className="clinical-tabs">
                  <button
                    type="button"
                    className={`clinical-tab ${alertStatusTab === "active" ? "active" : ""}`}
                    onClick={() => setAlertStatusTab("active")}
                  >
                    Active
                  </button>
                  <button
                    type="button"
                    className={`clinical-tab ${alertStatusTab === "acknowledged" ? "active" : ""}`}
                    onClick={() => setAlertStatusTab("acknowledged")}
                  >
                    Acknowledged
                  </button>
                  <button
                    type="button"
                    className={`clinical-tab ${alertStatusTab === "resolved" ? "active" : ""}`}
                    onClick={() => setAlertStatusTab("resolved")}
                  >
                    Resolved
                  </button>
                </div>
                {lifecycleAlertPreview.length > 0 ? (
                  <ul className="brief-list">
                    {lifecycleAlertPreview.map((alert) => (
                      <li key={alert.id}>
                        <strong>{alert.title}</strong> ({alert.severity.toLowerCase()}) — {alert.description}
                        <div className="workspace-sync-actions alert-actions">
                          <button
                            type="button"
                            className="btn ghost"
                            onClick={() => void toggleAlertTimeline(alert.id)}
                            disabled={loadingAlertTimelineId === alert.id}
                          >
                            {expandedAlertTimelineId === alert.id ? "Hide timeline" : "View timeline"}
                          </button>
                        </div>
                        {alertStatusTab === "active" ? (
                          <div className="workspace-sync-actions alert-actions">
                            <button
                              type="button"
                              className="btn ghost"
                              onClick={() => acknowledgeClinicalAlert(alert.id)}
                              disabled={workingAlertId === alert.id}
                            >
                              {workingAlertId === alert.id ? "Working..." : "Acknowledge"}
                            </button>
                            <button
                              type="button"
                              className="btn ghost"
                              onClick={() => resolveClinicalAlert(alert.id)}
                              disabled={workingAlertId === alert.id}
                            >
                              {workingAlertId === alert.id ? "Working..." : "Resolve"}
                            </button>
                          </div>
                        ) : null}
                        {alertStatusTab === "acknowledged" ? (
                          <div className="workspace-sync-actions alert-actions">
                            <button
                              type="button"
                              className="btn ghost"
                              onClick={() => resolveClinicalAlert(alert.id)}
                              disabled={workingAlertId === alert.id}
                            >
                              {workingAlertId === alert.id ? "Working..." : "Resolve"}
                            </button>
                          </div>
                        ) : null}
                        {expandedAlertTimelineId === alert.id ? (
                          <div className="alert-timeline">
                            <div className="alert-timeline-toolbar">
                              <div className="alert-timeline-filters">
                                <label>
                                  Action
                                  <select
                                    value={timelineActionFilter}
                                    onChange={(event) =>
                                      setTimelineActionFilter(
                                        event.target.value as "all" | "CREATED" | "ACKNOWLEDGED" | "RESOLVED"
                                      )
                                    }
                                  >
                                    <option value="all">All</option>
                                    <option value="CREATED">Created</option>
                                    <option value="ACKNOWLEDGED">Acknowledged</option>
                                    <option value="RESOLVED">Resolved</option>
                                  </select>
                                </label>
                                <label>
                                  From
                                  <input
                                    type="date"
                                    value={timelineFromDate}
                                    onChange={(event) => setTimelineFromDate(event.target.value)}
                                  />
                                </label>
                                <label>
                                  To
                                  <input
                                    type="date"
                                    value={timelineToDate}
                                    onChange={(event) => setTimelineToDate(event.target.value)}
                                  />
                                </label>
                                <label>
                                  Page size
                                  <select
                                    value={timelinePageSize}
                                    onChange={(event) => setTimelinePageSize(Number(event.target.value))}
                                  >
                                    <option value={5}>5</option>
                                    <option value={10}>10</option>
                                    <option value={20}>20</option>
                                    <option value={50}>50</option>
                                  </select>
                                </label>
                              </div>
                              <div className="workspace-sync-actions alert-timeline-export">
                                <button type="button" className="btn ghost" onClick={() => void copyExpandedTimeline()}>
                                  Copy timeline
                                </button>
                                <button type="button" className="btn ghost" onClick={downloadExpandedTimelineJson}>
                                  Download JSON
                                </button>
                                <button type="button" className="btn ghost" onClick={downloadExpandedTimelineCsv}>
                                  Download CSV
                                </button>
                              </div>
                            </div>
                            {(alertTimelineById[alert.id] ?? []).length > 0 ? (
                              <ul className="alert-timeline-list">
                                {(alertTimelineById[alert.id] ?? []).map((event) => (
                                  <li key={event.id}>
                                    <span className="alert-timeline-action">{event.action.toLowerCase()}</span>
                                    <span>
                                      {new Date(event.createdAt).toLocaleString()}
                                      {event.actorLabel ? ` by ${event.actorLabel}` : ""}
                                    </span>
                                    {event.note ? <span>{event.note}</span> : null}
                                  </li>
                                ))}
                              </ul>
                            ) : (
                              <p className="muted-copy">No timeline events.</p>
                            )}
                            <div className="alert-timeline-pagination">
                              <span>
                                Page {timelinePagination?.page ?? timelinePage} of {timelinePagination?.totalPages ?? 1}
                                {` · ${timelinePagination?.total ?? 0} event${(timelinePagination?.total ?? 0) === 1 ? "" : "s"}`}
                              </span>
                              <div className="workspace-sync-actions">
                                <button
                                  type="button"
                                  className="btn ghost"
                                  onClick={() => setTimelinePage((previous) => Math.max(1, previous - 1))}
                                  disabled={(timelinePagination?.page ?? timelinePage) <= 1 || loadingAlertTimelineId === alert.id}
                                >
                                  Previous
                                </button>
                                <button
                                  type="button"
                                  className="btn ghost"
                                  onClick={() => setTimelinePage((previous) => previous + 1)}
                                  disabled={!timelinePagination?.hasMore || loadingAlertTimelineId === alert.id}
                                >
                                  Next
                                </button>
                              </div>
                            </div>
                            {timelineExportMessage ? <p className="muted-copy">{timelineExportMessage}</p> : null}
                          </div>
                        ) : null}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="muted-copy">No {alertStatusTab} alerts.</p>
                )}
                {lifecycleAlertsMessage ? <p className="muted-copy">{lifecycleAlertsMessage}</p> : null}
                {alertTimelineMessage ? <p className="muted-copy">{alertTimelineMessage}</p> : null}
                {alertActionMessage ? <p className="muted-copy">{alertActionMessage}</p> : null}

                <p className="brief-heading">Worsening trends</p>
                {worseningTrendPreview.length > 0 ? (
                  <ul className="brief-list">
                    {worseningTrendPreview.map((trend) => (
                      <li key={`${trend.labName}-${trend.trend}`}>
                        <strong>{trend.labName}</strong> — {trend.trend}
                        {trend.trendStrength ? ` (${trend.trendStrength})` : ""}
                        {trend.acceleration ? `, ${trend.acceleration}` : ""}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="muted-copy">No worsening trends detected.</p>
                )}
              </>
            ) : (
              <p className="muted-copy">
                {clinicalSummaryMessage || "Clinical summary will appear after synced clinical data is available."}
              </p>
            )}
          </article>

          <article className="card">
            <h3>3) Doctor brief</h3>
            {brief ? (
              <div className="brief-box">
                <p>
                  <strong>Patient:</strong> {brief.patientLine}
                </p>
                <p>
                  <strong>Continuity score:</strong> {brief.continuityScore}/100
                </p>
                <p>
                  <strong>Clinical risk:</strong> {clinicalSummary?.overallRiskLevel ?? "Pending"}
                </p>
                {clinicalSummary ? (
                  <div className="brief-risk-summary">
                    <p className="brief-heading">Clinical summary</p>
                    <ul className="brief-list">
                      <li>{clinicalSummary.summary.criticalValues} critical values</li>
                      <li>{clinicalSummary.summary.worseningTrends} worsening trends</li>
                      <li>{clinicalSummary.summary.activeAlerts} active alerts</li>
                      <li>{clinicalSummary.summary.clinicalPatterns} clinical patterns</li>
                    </ul>
                  </div>
                ) : (
                  <p className="muted-copy">
                    {clinicalSummaryMessage || "Clinical summary will load after workspace data is available."}
                  </p>
                )}
                <p className="brief-heading">Recent highlights</p>
                <ul className="brief-list">
                  {brief.recentHighlights.map((line) => (
                    <li key={line}>{line}</li>
                  ))}
                </ul>
                <p className="brief-heading">Risk flags</p>
                <ul className="brief-list">
                  {brief.riskFlags.map((line) => (
                    <li key={line}>{line}</li>
                  ))}
                </ul>
                <p className="brief-heading">Suggested actions</p>
                <ul className="brief-list">
                  {brief.suggestedActions.map((line) => (
                    <li key={line}>{line}</li>
                  ))}
                </ul>
                <button type="button" onClick={copyBrief}>
                  {copied ? "Copied" : "Copy brief"}
                </button>
              </div>
            ) : (
              <p className="muted-copy">Add a patient to generate the brief.</p>
            )}
          </article>

          <article className="card">
            <h3>Timeline records ({sortedRecords.length})</h3>
            {sortedRecords.length > 0 ? (
              <div className="record-list">
                {sortedRecords.map((record) => (
                  <div key={record.id} className="record-item">
                    <p className="record-meta">
                      {record.date} · {record.type}
                    </p>
                    <p className="record-title">{record.title}</p>
                    <p className="record-summary">{record.summary}</p>
                    <p className="record-meta">Source: {record.source}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="muted-copy">No records added yet.</p>
            )}
          </article>
        </div>
      </div>
    </section>
  );
}