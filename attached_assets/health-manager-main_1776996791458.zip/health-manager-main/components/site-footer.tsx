import Link from "next/link";

export function SiteFooter() {
  return (
    <footer className="footer">
      <div>
        <p>© {new Date().getFullYear()} Anirul Health Intelligence Pvt. Ltd.</p>
        <p>Built for high-trust healthcare systems.</p>
      </div>
      <div className="footer-links">
        <Link href="/product">Product</Link>
        <Link href="/platform">Platform</Link>
        <Link href="/security">Security</Link>
        <Link href="/pilots">Pilots</Link>
        <Link href="/about">About</Link>
      </div>
    </footer>
  );
}
