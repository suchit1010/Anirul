"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { createBrowserSupabase } from "@/lib/supabase-client";

const navItems = [
  { href: "/product", label: "Product" },
  { href: "/platform", label: "Platform" },
  { href: "/security", label: "Security" },
  { href: "/pilots", label: "Pilots" },
  { href: "/about", label: "About" }
];

export function SiteHeader() {
  const pathname = usePathname();
  const router = useRouter();
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [loadingUser, setLoadingUser] = useState(true);

  useEffect(() => {
    const supabase = createBrowserSupabase();
    supabase.auth.getSession().then(({ data }) => {
      setUserEmail(data.session?.user.email ?? null);
      setLoadingUser(false);
    });
  }, []);

  async function signOut() {
    const supabase = createBrowserSupabase();
    await supabase.auth.signOut();
    router.push("/auth/login");
  }

  return (
    <header className="site-header-wrap">
      <nav className="topbar">
        <Link href="/" className="brand-link">
          <span className="brand">ANIRUL</span>
        </Link>

        <div className="nav-links">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              aria-current={pathname === item.href ? "page" : undefined}
              className={pathname === item.href ? "active" : undefined}
            >
              {item.label}
            </Link>
          ))}
        </div>

        {loadingUser ? null : userEmail ? (
          <button type="button" className="header-cta" onClick={signOut}>
            Logout
          </button>
        ) : (
          <Link href="/auth/login" className="header-cta">
            Login
          </Link>
        )}
      </nav>
    </header>
  );
}
