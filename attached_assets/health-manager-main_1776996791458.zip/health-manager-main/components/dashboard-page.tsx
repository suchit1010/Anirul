"use client";

import { useEffect, useState } from "react";
import type { WorkspaceDocumentSummary } from "@/lib/document-store";

type DashboardProps = {
  workspaceId: string;
  onNavigate: (section: string) => void;
};

type QuickStats = {
  documentsIngested: number;
  activeAlerts: number;
  careTasks: number;
  familyMembers: number;
};

export function DashboardPage({ workspaceId, onNavigate }: DashboardProps) {
  const [stats, setStats] = useState<QuickStats>({
    documentsIngested: 0,
    activeAlerts: 0,
    careTasks: 0,
    familyMembers: 0,
  });
  const [recentDocuments, setRecentDocuments] = useState<WorkspaceDocumentSummary[]>([]);
  const [loadingStats, setLoadingStats] = useState(true);

  useEffect(() => {
    const loadStats = async () => {
      try {
        setLoadingStats(true);
        
        // Load documents
        const docsRes = await fetch(`/api/workspaces/${workspaceId}/documents`, {
          method: "GET",
        });
        if (docsRes.ok) {
          const data = (await docsRes.json()) as { documents?: WorkspaceDocumentSummary[] };
          const docs = data.documents ?? [];
          setRecentDocuments(docs.slice(0, 3));
          setStats((prev) => ({ ...prev, documentsIngested: docs.length }));
        }

        // Load alerts
        const alertsRes = await fetch(
          `/api/workspaces/${workspaceId}/clinical-alerts?status=active&pageSize=1`,
          { method: "GET" }
        );
        if (alertsRes.ok) {
          const data = (await alertsRes.json()) as { 
            pagination?: { total?: number } 
          };
          setStats((prev) => ({
            ...prev,
            activeAlerts: data.pagination?.total ?? 0,
          }));
        }

        // Load care tasks
        const tasksRes = await fetch(
          `/api/workspaces/${workspaceId}/care-tasks?status=PENDING&pageSize=1`,
          { method: "GET" }
        );
        if (tasksRes.ok) {
          const data = (await tasksRes.json()) as { 
            pagination?: { total?: number } 
          };
          setStats((prev) => ({
            ...prev,
            careTasks: data.pagination?.total ?? 0,
          }));
        }

        // Load family members
        const familyRes = await fetch(
          `/api/workspaces/${workspaceId}/family-profiles`,
          { method: "GET" }
        );
        if (familyRes.ok) {
          const data = (await familyRes.json()) as { profiles?: unknown[] };
          setStats((prev) => ({
            ...prev,
            familyMembers: data.profiles?.length ?? 0,
          }));
        }
      } catch (error) {
        console.error("Failed to load dashboard stats:", error);
      } finally {
        setLoadingStats(false);
      }
    };

    if (workspaceId) {
      void loadStats();
    }
  }, [workspaceId]);

  return (
    <div className="dashboard-page">
      <div className="dashboard-header">
        <h2>Health Dashboard</h2>
        <p className="muted-copy">Quick overview and shortcuts to key workflows</p>
      </div>

      {/* Quick Stats */}
      <div className="dashboard-stats">
        <div className="stat-card" onClick={() => onNavigate("documents")}>
          <p className="stat-label">Documents</p>
          <p className="stat-value">{loadingStats ? "..." : stats.documentsIngested}</p>
          <p className="stat-action">View all</p>
        </div>
        <div className="stat-card alert" onClick={() => onNavigate("alerts")}>
          <p className="stat-label">Active Alerts</p>
          <p className="stat-value">{loadingStats ? "..." : stats.activeAlerts}</p>
          <p className="stat-action">Review now</p>
        </div>
        <div className="stat-card task" onClick={() => onNavigate("tasks")}>
          <p className="stat-label">Care Tasks</p>
          <p className="stat-value">{loadingStats ? "..." : stats.careTasks}</p>
          <p className="stat-action">Check list</p>
        </div>
        <div className="stat-card family" onClick={() => onNavigate("family")}>
          <p className="stat-label">Family Members</p>
          <p className="stat-value">{loadingStats ? "..." : stats.familyMembers}</p>
          <p className="stat-action">Manage</p>
        </div>
      </div>

      {/* Recent Documents */}
      {recentDocuments.length > 0 && (
        <div className="dashboard-section">
          <div className="section-header">
            <h3>Recent Documents</h3>
            <button className="link-button" onClick={() => onNavigate("documents")}>
              View all →
            </button>
          </div>
          <div className="document-list-compact">
            {recentDocuments.map((doc) => (
              <div key={doc.id} className="document-item-compact">
                <div className="document-item-icon">
                  {doc.mimeType?.startsWith("image/") ? "📷" : "📄"}
                </div>
                <div className="document-item-info">
                  <p className="document-item-name">{doc.originalName}</p>
                  <p className="document-item-meta">
                    {doc.status} • {new Date(doc.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick Actions */}
      <div className="dashboard-section">
        <h3>Quick Actions</h3>
        <div className="quick-actions">
          <button
            className="action-button primary"
            onClick={() => onNavigate("ingestion")}
          >
            ➕ Add Document
          </button>
          <button
            className="action-button"
            onClick={() => onNavigate("alerts")}
          >
            🔔 View Alerts
          </button>
          <button
            className="action-button"
            onClick={() => onNavigate("tasks")}
          >
            ✓ Manage Tasks
          </button>
          <button
            className="action-button"
            onClick={() => onNavigate("brief")}
          >
            📋 Doctor Brief
          </button>
        </div>
      </div>

      {/* Getting Started */}
      {stats.documentsIngested === 0 && (
        <div className="getting-started">
          <h3>Getting Started</h3>
          <p>No documents yet. Start by uploading your first health report.</p>
          <button className="btn primary-action" onClick={() => onNavigate("ingestion")}>
            Upload First Document
          </button>
        </div>
      )}
    </div>
  );
}
