"use client";

import { useState } from "react";

type IngestionWizardProps = {
  workspaceId: string;
  onSuccess: () => void;
  onCancel: () => void;
};

type IngestionStep = "select" | "upload" | "review" | "complete";

export function IngestionWizard({
  workspaceId,
  onSuccess,
  onCancel,
}: IngestionWizardProps) {
  const [step, setStep] = useState<IngestionStep>("select");
  const [selectedType, setSelectedType] = useState<
    "report" | "whatsapp" | "audio"
  >("report");
  const [file, setFile] = useState<File | null>(null);
  const [whatsappText, setWhatsappText] = useState("");
  const [whatsappSender, setWhatsappSender] = useState("");
  const [audioText, setAudioText] = useState("");
  const [audioLanguage, setAudioLanguage] = useState("en-IN");
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");

  const canProceed = () => {
    if (selectedType === "report") return file !== null;
    if (selectedType === "whatsapp") return whatsappText.trim().length > 0;
    if (selectedType === "audio") return audioText.trim().length > 0;
    return false;
  };

  const handleUpload = async () => {
    setError("");
    setUploading(true);

    try {
      if (selectedType === "report" && file) {
        const formData = new FormData();
        formData.append("file", file);

        const res = await fetch(
          `/api/workspaces/${workspaceId}/documents`,
          {
            method: "POST",
            body: formData,
          }
        );

        if (!res.ok) {
          const errData = (await res.json()) as { error?: string };
          throw new Error(errData.error || "Failed to upload document");
        }

        setStep("complete");
      } else if (selectedType === "whatsapp") {
        const res = await fetch(
          `/api/workspaces/${workspaceId}/documents/channels/whatsapp`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              forwardedText: whatsappText,
              senderLabel: whatsappSender || undefined,
            }),
          }
        );

        if (!res.ok) {
          const errData = (await res.json()) as { error?: string };
          throw new Error(errData.error || "Failed to ingest WhatsApp message");
        }

        setStep("complete");
      } else if (selectedType === "audio") {
        const res = await fetch(
          `/api/workspaces/${workspaceId}/documents/channels/audio`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              transcriptText: audioText,
              languageHint: audioLanguage,
            }),
          }
        );

        if (!res.ok) {
          const errData = (await res.json()) as { error?: string };
          throw new Error(errData.error || "Failed to ingest audio transcript");
        }

        setStep("complete");
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Unknown error";
      setError(msg);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="wizard-overlay">
      <div className="wizard-modal">
        {/* Step: Select Type */}
        {step === "select" && (
          <>
            <h2>Add a Health Document</h2>
            <p className="wizard-subtitle">
              Choose how you want to share your health information
            </p>

            <div className="wizard-options">
              <button
                className={`wizard-option ${selectedType === "report" ? "active" : ""}`}
                onClick={() => setSelectedType("report")}
              >
                <span className="option-icon">📄</span>
                <span className="option-title">Upload Report</span>
                <span className="option-desc">PDF, image, or document</span>
              </button>

              <button
                className={`wizard-option ${selectedType === "whatsapp" ? "active" : ""}`}
                onClick={() => setSelectedType("whatsapp")}
              >
                <span className="option-icon">💬</span>
                <span className="option-title">WhatsApp Forward</span>
                <span className="option-desc">Lab result text from WhatsApp</span>
              </button>

              <button
                className={`wizard-option ${selectedType === "audio" ? "active" : ""}`}
                onClick={() => setSelectedType("audio")}
              >
                <span className="option-icon">🎤</span>
                <span className="option-title">Voice Transcript</span>
                <span className="option-desc">Transcribed voice note</span>
              </button>
            </div>

            <div className="wizard-actions">
              <button className="btn secondary" onClick={onCancel}>
                Cancel
              </button>
              <button className="btn primary" onClick={() => setStep("upload")}>
                Continue
              </button>
            </div>
          </>
        )}

        {/* Step: Upload */}
        {step === "upload" && (
          <>
            <h2>
              {selectedType === "report"
                ? "Upload Report"
                : selectedType === "whatsapp"
                  ? "Paste WhatsApp Text"
                  : "Paste Audio Transcript"}
            </h2>

            {selectedType === "report" && (
              <div className="upload-area">
                <input
                  type="file"
                  onChange={(e) => setFile(e.target.files?.[0] ?? null)}
                  accept=".pdf,.jpg,.jpeg,.png,.txt"
                  id="file-input"
                  style={{ display: "none" }}
                />
                <label htmlFor="file-input" className="upload-label">
                  {file ? (
                    <>
                      <span className="upload-icon">✓</span>
                      <span className="upload-filename">{file.name}</span>
                      <span className="upload-size">
                        {(file.size / 1024).toFixed(1)} KB
                      </span>
                    </>
                  ) : (
                    <>
                      <span className="upload-icon">⬆️</span>
                      <span className="upload-text">
                        Click to select or drag file here
                      </span>
                      <span className="upload-hint">
                        PDF, JPEG, PNG, or TXT
                      </span>
                    </>
                  )}
                </label>
              </div>
            )}

            {selectedType === "whatsapp" && (
              <>
                <div className="form-group">
                  <label>Sender (optional)</label>
                  <input
                    type="text"
                    value={whatsappSender}
                    onChange={(e) => setWhatsappSender(e.target.value)}
                    placeholder="e.g., Family group, Dr. Smith"
                  />
                </div>
                <div className="form-group">
                  <label>Lab Results Text *</label>
                  <textarea
                    value={whatsappText}
                    onChange={(e) => setWhatsappText(e.target.value)}
                    placeholder="Paste the lab result text from WhatsApp"
                    rows={6}
                  />
                </div>
              </>
            )}

            {selectedType === "audio" && (
              <>
                <div className="form-group">
                  <label>Language</label>
                  <select
                    value={audioLanguage}
                    onChange={(e) => setAudioLanguage(e.target.value)}
                  >
                    <option value="en-IN">English (India)</option>
                    <option value="hi-IN">Hindi</option>
                    <option value="en-US">English (US)</option>
                    <option value="en-GB">English (UK)</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>Transcript Text *</label>
                  <textarea
                    value={audioText}
                    onChange={(e) => setAudioText(e.target.value)}
                    placeholder="Paste the transcribed text from your voice note"
                    rows={6}
                  />
                </div>
              </>
            )}

            {error && <div className="error-message">{error}</div>}

            <div className="wizard-actions">
              <button
                className="btn secondary"
                onClick={() => setStep("select")}
                disabled={uploading}
              >
                Back
              </button>
              <button
                className="btn primary"
                onClick={handleUpload}
                disabled={!canProceed() || uploading}
              >
                {uploading ? "Processing..." : "Upload"}
              </button>
            </div>
          </>
        )}

        {/* Step: Complete */}
        {step === "complete" && (
          <>
            <h2>✓ Document Added</h2>
            <p className="wizard-subtitle">
              Your document has been uploaded and will be processed automatically.
            </p>

            <div className="success-message">
              <p>
                {selectedType === "report" && file
                  ? `File "${file.name}" uploaded successfully`
                  : "Your health information has been added to your timeline"}
              </p>
            </div>

            <div className="wizard-actions">
              <button
                className="btn primary"
                onClick={() => {
                  onSuccess();
                  setStep("select");
                  setFile(null);
                  setWhatsappText("");
                  setAudioText("");
                }}
              >
                Done
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
