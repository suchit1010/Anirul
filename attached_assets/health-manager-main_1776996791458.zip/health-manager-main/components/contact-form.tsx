"use client";

import { useMemo, useState, type FormEvent } from "react";

type Interest = "pilot" | "clinic" | "enterprise" | "investor" | "media" | "other";

type FormState = {
  name: string;
  email: string;
  company: string;
  interest: Interest;
  message: string;
};

const initialState: FormState = {
  name: "",
  email: "",
  company: "",
  interest: "pilot",
  message: ""
};

export function ContactForm() {
  const [state, setState] = useState<FormState>(initialState);
  const [status, setStatus] = useState<"idle" | "submitting" | "success" | "error">("idle");
  const [feedback, setFeedback] = useState("");

  const disabled = useMemo(() => {
    return status === "submitting";
  }, [status]);

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus("submitting");
    setFeedback("");

    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(state)
      });

      const body = (await response.json()) as {
        ok: boolean;
        message?: string;
        error?: string;
      };

      if (!response.ok || !body.ok) {
        throw new Error(body.error || "Unable to send request.");
      }

      setStatus("success");
      setFeedback(body.message || "Request sent successfully.");
      setState(initialState);
    } catch (error) {
      setStatus("error");
      setFeedback(error instanceof Error ? error.message : "Something went wrong.");
    }
  }

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setState((previous: FormState) => ({ ...previous, [key]: value }));
  }

  return (
    <form className="contact-form" onSubmit={onSubmit}>
      <div className="field-grid">
        <label>
          Name
          <input
            required
            value={state.name}
            onChange={(event) => update("name", event.target.value)}
            placeholder="Enter your full name"
          />
        </label>

        <label>
          Work email
          <input
            required
            type="email"
            value={state.email}
            onChange={(event) => update("email", event.target.value)}
            placeholder="name@company.com"
          />
        </label>
      </div>

      <div className="field-grid">
        <label>
          Organization
          <input
            value={state.company}
            onChange={(event) => update("company", event.target.value)}
            placeholder="Clinic, hospital, or company"
          />
        </label>

        <label>
          Interest
          <select
            value={state.interest}
            onChange={(event) => update("interest", event.target.value as Interest)}
          >
            <option value="pilot">Pilot deployment</option>
            <option value="clinic">Clinic onboarding</option>
            <option value="enterprise">Enterprise partnership</option>
            <option value="investor">Investor conversation</option>
            <option value="media">Media request</option>
            <option value="other">Other</option>
          </select>
        </label>
      </div>

      <label>
        Message
        <textarea
          required
          minLength={20}
          value={state.message}
          onChange={(event) => update("message", event.target.value)}
          placeholder="Tell us what you want to build with Anirul or what problem you're solving."
        />
      </label>

      <button disabled={disabled} type="submit">
        {status === "submitting" ? "Sending..." : "Request access"}
      </button>

      {feedback && (
        <p className={`feedback ${status === "error" ? "error" : "success"}`}>{feedback}</p>
      )}
    </form>
  );
}
